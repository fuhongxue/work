/**
 * Created by wangzhigang on 15/9/22.
 */

var CLBackgroundLayer = cc.Layer.extend({
	ctor : function(){
		this._super();

		this.loadBg();
	},

	loadBg : function(){
		var node = new cc.Sprite(res.ui_chooselevel_bg);
		this.addChild(node);

		node.setPosition(GC.w2,GC.h2);
	}
});