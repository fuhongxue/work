

var GPDataManager = (function(){

	function _GPDataManager(){
		this.roleCollisionEffectJudge = function(hero,monster){
			var isHeroDeath = false;
			var isMonsterDeath = false;
			var monsterGold = 0;
			var actionType = -1;

			var mHp = monster.hp;
			var hHp = hero.hp;
			var hAttack = hero.getAttack();
			var mAttack = monster.getAttack();
			var mHpMax = monster.hpMax;
			var hHpMax = GameManager.getInstance().getCharacterData().hpMax;

			monsterGold = monster.gold;

			if (hHp - mAttack <= 0) {
				isHeroDeath = true;
			}



			if (mHp - hAttack <= 0) {
				isMonsterDeath = true;
			};

			var costHpRate = 0;
			if ((mHp - hAttack) < 0) {
				costHpRate = 1 + Math.abs((mHp - hAttack) / mHpMax) ;
			}else{
				costHpRate = 1 - (mHp - hAttack) / mHpMax;
			}

			if (costHpRate < GC.FIGHT_RULE[0][0]) {
				// cc.log("================0.8==================")
				actionType = 1;

				hero.tempSpeed = hero.speed;
			}else if (costHpRate >= GC.FIGHT_RULE[0][0] && costHpRate <= GC.FIGHT_RULE[0][1]) {
				// cc.log("================0.8 ~ 1.2==================")
				actionType = 2;
				if (!isHeroDeath) {
					var heroRate = 1 - (hHp - mAttack) / hHpMax;
					hero.tempSpeed = hero.speed*( 1-GC.FIGHT_RULE[1][3] * heroRate);
				};

			}else if (costHpRate > GC.FIGHT_RULE[0][1]) {
				// cc.log("================1.2==================")
				actionType = 3;
				if (!isHeroDeath) {
					var heroRate = 1 - (hHp - mAttack) / hHpMax;
					hero.tempSpeed = hero.speed*( 1-GC.FIGHT_RULE[1][3] * heroRate);

				};
			};

			return {
				"isHeroDeath" : isHeroDeath,
				"isMonsterDeath" : isMonsterDeath,
				"monsterGold" : monsterGold,
				"actionType" : actionType,
				"hAttack"       : hAttack,
				"mAttack"       : mAttack
			};
		}
	}

	var instance;

	var _static = {
		name : "EffctManager",

		getInstance: function(){
			if (instance === undefined) {
			    instance = new _GPDataManager();
			}
			return instance;
		}
	};
	return _static;
})();