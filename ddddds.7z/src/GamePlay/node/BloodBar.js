
/**
 * Created by wangzhigang on 15/10/26.
 */

var BloodBar = cc.Sprite.extend({
	ctor : function(){
		this._super(res.ui_hp_bg);

		this.loadHpBarBg();
		this.loadHpBar();
	},
	loadHpBarBg : function(){
		// var node = new cc.Sprite(res.ui_hp_bg);
		// this.addChild(node);
		this.setAnchorPoint(0,0);

		this.setPosition(0,GC.HP_BAR_HIGHT)
		this.setCascadeOpacityEnabled(true);
	},
	loadHpBar : function(){
		var node = new cc.Sprite(res.ui_hp_we);
		this.addChild(node);
		node.setAnchorPoint(0,0);
		node.setCascadeOpacityEnabled(true);

		// node.setPosition(0,GC.HP_BAR_HIGHT);

		this.hpBar = node;
	},
	setHpBar : function(percent){
		if(percent > 0){
			this.hpBar.setScaleX(percent);
		}else{
			this.hpBar.setScaleX(0);
		}
	},
	setMoveHpBar : function(percent){
		var action = cc.scaleTo(0.1,percent,1);
		this.hpBar.runAction(action);
	},
	getWidth : function(){
		return 42;
	}
});