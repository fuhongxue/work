/**
 * Created by wangzhigang on 15/8/28.
 */

var Monster = cc.Sprite.extend({
	level   : null,

	hpBar : null,

	originPosX : 0,
	hpMax : 0,
	hp  : 0,
	attack : 0,
	gold   : 0,

	isDeath : false,
	direction	: GC.CHARACTER_DIRECTION.LEFT,
	isIdle : false,
	hpNode : null,
	ctor : function(level){
		this._super(res["m" + GameManager.getInstance().getMonsterImageInfoByField(level-1,"img") + "_standby01"]);

		this.loadConfig(level);
		// this.loadHpBar();
	    this.loadAnimation();
	    

	    return true;
	},
	loadConfig : function(level) {
		this.level = level;
		var config =  GameManager.getInstance().getMonsterInfo()[this.level-1];

		this.hp     = config[0][0];
		this.hpMax  = this.hp;
		this.attack = config[0][1];
		this.gold   = config[1];


		this.isDeath = false;

		this.className = "Monster";
	},
	setOriginPosX : function(x) {
		this.originPosX = x;

	},
	loadAnimation : function() {
		this.stopActionByTag(998);

		var prefix =  "m" + GameManager.getInstance().getMonsterImageInfoByField(this.level-1,"img") + "_standby0" ;

		// cc.log("monsterPos prefix : " + prefix);
		this.setTexture(res[prefix + 1]);

		var animation = cc.Animation.create();  //利用动画保存每一帧的图片

		var len = 4;
		var value = Math.ceil(Math.random()*len)
		var arr = new Array(len);

		for (var i = len; i >= 1; i--) {
			if (i >= value) {
				arr[i-value] = res[prefix+ i];

			}else{
				arr[4-value + i] = res[prefix+ i];
			}
		};

		for (var i = 0; i < len; i++) {
			animation.addSpriteFrameWithFile(arr[i]);
		};


		animation.setDelayPerUnit(0.1);  //每一帧播放的间隔
		var animate = cc.animate(animation).repeatForever();
		animate.tag = 998;
		this.runAction(animate);
		// this.setAnchorPoint(0,0);

		var heroObj = GameManager.getInstance().getHeroObj();

		if (this.direction == GC.CHARACTER_DIRECTION.RIGHT) {
			this.setRotationY(0);
		}else{
			this.setRotationY(180);
		}
		
	},
	loadHitAnimation : function() {
		this.stopActionByTag(998);
		var prefix =  "m" + GameManager.getInstance().getMonsterImageInfoByField(this.level-1,"img") + "_hit01" ;
		this.setTexture(res[prefix]);

		var heroObj = GameManager.getInstance().getHeroObj();

		if (heroObj.direction == GC.CHARACTER_DIRECTION.RIGHT) {
			this.setRotationY(180);
		}else{
			this.setRotationY(0);
		}

	},
	loadHpBar : function() {
		var Bar = new cc.Node();

		var node = new cc.Sprite(res.ui_hp_bg);
		node.setAnchorPoint(0,0);
		Bar.addChild(node);

		var node = new cc.Sprite(res.ui_hp_enemy);
		node.setAnchorPoint(0,0);
		Bar.addChild(node)

		Bar.setPosition(this.getContentSize().width/2 - node.getContentSize().width/2,GC.HP_BAR_HIGHT);
		this.addChild(Bar)

		this.hpBar = node;
		this.hpBg = Bar
	},
	setHpBar : function() {
		var percent = this.hp/this.hpMax;
		// if(percent > 0){
		// 	this.hpBar.setScaleX(percent);
		// }else{
		// 	this.hpBar.setScaleX(0);
		// }

		this.hpNode.setHpBar(percent);
	},
	reset : function() {
		this.setVisible(true);
		this.hpNode.setVisible(true);
		this.setIsDeath(false);
		this.loadAnimation();
		this.isIdle = false;
	},
	setIsDeath : function(status) {
		this.isDeath = status;
	},
	getIsDeath : function() {
		return this.isDeath;
	},
	setDirection : function(dir) {
		this.direction = dir;
		this.loadAnimation();
	},
	getAttack : function() {
		return this.attack;
	},
	onHit : function(options,att,dir) {
		var isDeath = false;

		this.hp = this.hp - options.hAttack;

		if (options.isMonsterDeath) {
			isDeath = true;

			this.setIsDeath(true);
		}else{
			EffectManager.getInstance().playHitMonsterEffect();
		}

		this.loadHitAnimation();
		this.setHpBar();

		var heroObj = GameManager.getInstance().getHeroObj();

		if (options.actionType == 1) {
			this.stopActionByTag(10000);

			var action = cc.delayTime(GC.FIGHT_RULE[1][0][1]);
			var callBack = cc.callFunc(function(){
				this.loadAnimation();
			}.bind(this));

			var saction = cc.sequence(action,callBack)
			saction.tag = 10000;

			this.runAction(saction);

		}else if(options.actionType == 2){
			if (options.isMonsterDeath) {
				this.setVisible(false);
				this.hp = this.hpMax;
				this.setOpacity(255)
				this.isIdle = true;
				this.setHpBar();
				this.hpNode.setVisible(false);

			}

			this.stopActionByTag(10001);

			var action = cc.delayTime(GC.FIGHT_RULE[1][1][1]);
			var callBack = cc.callFunc(function(){
				this.loadAnimation();
				heroObj.collisionReduceSpeed();
			}.bind(this));

			var saction = cc.sequence(action,callBack)
			saction.tag = 10001;
			this.runAction(saction);
		}else if(options.actionType == 3){
			var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;

			var disX = GC.FIGHT_RULE[1][2][0]()
			var height = GC.FIGHT_RULE[1][2][2]()

			var action1 = cc.jumpBy(GC.FIGHT_RULE[1][2][1], cc.p( disX*dir, 0 ), height, 1); 

			var callBack = cc.callFunc(function(){
				this.loadAnimation();
				if (options.isMonsterDeath) {
					this.setVisible(false);
					this.hp = this.hpMax;
					this.setOpacity(255)
					this.isIdle = true;
					this.setHpBar();
					this.hpNode.setVisible(false);
					heroObj.collisionReduceSpeed();
				};
			}.bind(this));

			var action = cc.sequence(action1 , callBack);
			this.runAction(action);


			var action1 = cc.jumpBy(GC.FIGHT_RULE[1][2][1], cc.p( disX*dir, 0 ), height, 1); 
			this.hpNode.runAction(action1);
		}
	},
	getCollisionRect : function(){
		var monsterPos = this.getPosition();

		var tmp = this.direction == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;

		return cc.rect(
		    monsterPos.x + tmp*(this.getBoundingBox().width/2 - GameManager.getInstance().getMonsterImageInfoByField(this.level-1,"adjustWidth")),
		    monsterPos.y ,
		    1,
		    this.getBoundingBox().height);
	},
	setHpBarNode : function(i){
		this.hpNode = i;
	},
	resetHpBar : function(){
		this.hpNode.setPosition(this.x - this.hpNode.getWidth()*GC.SCALE_RATE/2,this.y +GC.HP_BAR_HIGHT)
	}

});