/**
 * Created by wangzhigang on 15/8/21.
 */

var GPBackgroundLayer = cc.Layer.extend({

    ctor:function () {
        this._super();

        this.loadBg();
        this.loadTopBg();

        this.loadParallaxNode();
        this.loadRoad();
        
        return true;
    },
    loadBg : function(){

        var mapInfo = GameManager.getInstance().mapInfo;
        
        if (mapInfo[0] != "type3") {
            var prefix = mapInfo[0] + "_" + mapInfo[1];

            var node = new cc.Sprite(res[prefix + "_bg1"]);
            this.addChild(node);

            node.setPosition(GC.w2, GC.h2);
            node.setScale(GC.SCALE_RATE);
        };
    },

    loadTopBg : function() {
        var node = new cc.Sprite(res.ui_top);
        this.addChild(node,200);
        node.setScale(GC.SCALE_RATE);
        node.setPosition(GC.w2, GC.h - node.getBoundingBox().height/2);

    },
    loadParallaxNode : function(){
        var node = new cc.ParallaxNode();
        this.addChild(node);
        this.parallaxNode = node;

        GameManager.getInstance().parallaxNode = node;
    },
    update : function(dt){
        var heroObj = GameManager.getInstance().getHeroObj();
        var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;

        var num = heroObj.getSpeed() * dt*dir;

        if (this.parallaxNode.x  - num > 0) {
            this.parallaxNode.x = 0
        }else{
            this.parallaxNode.x =  this.parallaxNode.x - num;
        }

        var roadVector = this.roadVector;

        this.bgRecycle(roadVector);
    },
    bgRecycle : function(vector){
        var heroObj = GameManager.getInstance().getHeroObj();

        for (var i = 0; i < vector.length; i++) {
            var node = vector[i]
            var nodeX = node.getParent().convertToWorldSpace(node.getPosition()).x

            if (node.loop == "multiple") {
                if(nodeX <= -node.getBoundingBox().width ){
                  node.setPositionX(node.getPositionX() + node.getBoundingBox().width*node.totalNum);
                }
                if(nodeX >= node.getBoundingBox().width*(node.totalNum - 1)) {
                  node.setPositionX(node.getPositionX() - node.getBoundingBox().width*node.totalNum);
                }  
            }else if (node.loop == "singleRepeat") {
                if(nodeX <= -node.getBoundingBox().width ){
                    node.setPositionX( node.getPositionX() + (GC.w + node.getBoundingBox().width));
                }
                if(nodeX >= GC.w) {
                    node.setPositionX(node.getPositionX() - (GC.w + node.getBoundingBox().width));
                }  
            };


        };
    },
    loadRoad : function() {
        this.roadVector = [];
        var mapInfo = GameManager.getInstance().mapInfo

        var prefix = mapInfo[0] + "_" + mapInfo[1];
        var forewordObj = BgParallax[mapInfo[0]]["backward"];

        for (var i = 0; i < forewordObj.length; i++) {
            var tnode = new cc.Node();
            var fieldObj = forewordObj[i];

            if (fieldObj.loop == "multiple") {
                for (var j = 0; j < fieldObj.amount; j++) {
                    var node = new cc.Sprite(res[prefix + "_" + fieldObj.name]);
                    node.setScale(GC.SCALE_RATE );
                    node.anchorX = 0;
                    node.anchorY = 0;

                    node.loop = "multiple"
                    node.x =  node.getBoundingBox().width*j;
                    node.y =  fieldObj.height;

                    node.field = fieldObj.name;
                    tnode.addChild(node);

                    node.totalNum = fieldObj.amount;
                    this.roadVector.push(node);

                    if(fieldObj.tree){

                        for (var k = 0; k < fieldObj.tree.length; k++) {
                            var treeInfo = fieldObj.tree[k];

                            if (treeInfo.pNode == j) {
                               var trnode = new cc.Sprite(res[prefix + "_" + treeInfo.name]);
                               trnode.setScale(treeInfo.scaleRate);
                               trnode.anchorX = 0;
                               trnode.anchorY = 0;                            

                               trnode.x =  treeInfo.x;
                               trnode.y =  treeInfo.y;

                               node.addChild(trnode); 
                            };
                        };
                    }
                };
            }else if (fieldObj.loop == "singleRepeat") {
                cc.log("forewordObj.loop ")

                var node = new cc.Sprite(res[prefix + "_" + fieldObj.name]);
                node.setScale(GC.SCALE_RATE );
                node.anchorX = 0;
                node.anchorY = 0;

                node.loop = "singleRepeat";
                node.x =  fieldObj.posX;
                node.y =  fieldObj.height;
                tnode.addChild(node,100);

                this.roadVector.push(node);

            };

            this.parallaxNode.addChild(tnode, -1, cc.p(fieldObj.ratio, 0), cc.p(0,0));

        };

    },
});