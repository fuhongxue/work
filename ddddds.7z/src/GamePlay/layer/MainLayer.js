/**
 * Created by wangzhigang on 15/4/20.
 */

 var GPMainLayer = cc.Layer.extend({
 	totalOffset     : null,
 	goldNode        : null,
 	temple          : null,
 	quitLayer       : null,
 	isUnlocked      : null,
 	curTemplePos    : 0,
 	curTempleIndex  : 0,
 	maskLayer       : null,
 	ctor:function() {
 		this._super();

 		// 加载[配置]
 		this.loadConfig();
 		this.loadTemple();
		this.loadGoldUI();
		this.loadHero();
		this.loadQuitBtn();
		this.loadShopBtn();
		this.loadBottomBg();

		this.showDPSAndHp();
 		// 绑定[事件][触摸]
 		this.bindTouchListener();
 		// 定时[更新游戏逻辑]
 		this.scheduleUpdate();

 		this.schedule(this.clockDPSAndHp, GC.HERO_HP_TIME);

 		return true;
 	},
 	loadBottomBg : function() {
 	    var node = new cc.Sprite(res.ui_top2);
 	    this.addChild(node,100);
 	    node.setScale(GC.SCALE_RATE);
 	    node.setPosition(GC.w2,node.getBoundingBox().height/2);
 	},
 	clockDPSAndHp : function(){
 		this.fHpMax.removeFromParent();
 		var fNode = Common.createFontNode(GameManager.getInstance().getCharacterData().attack,7);
 		fNode.anchorX = 0;
 		fNode.anchorY = 0;
 		fNode.x = 150;
 		fNode.y = GC.h-100;
 		this.addChild(fNode);
 		this.fHpMax = fNode;

 		this.fAttack.removeFromParent();

 		var fNode = Common.createFontNode(GameManager.getInstance().getCharacterData().hpMax,7);
 		fNode.anchorX = 0;
 		fNode.anchorY = 0;
 		fNode.x = 150;
 		fNode.y = GC.h-130;
 		this.addChild(fNode);
 		this.fAttack = fNode;
	},
 	showDPSAndHp : function(){
 		var node = new cc.Sprite(res["f07_dps"]);
 		node.x = 100;
 		node.y = GC.h-100;
 		this.addChild(node);
 		this.dps = node;

 		var fNode = Common.createFontNode(GameManager.getInstance().getCharacterData().attack,7);
 		fNode.anchorX = 0;
 		fNode.anchorY = 0;
 		fNode.x = 150;
 		fNode.y = GC.h-100;
 		this.addChild(fNode);
 		this.fHpMax = fNode;

 		var node = new cc.Sprite(res["f07_hp"]);
 		node.x = 100;
 		node.y = GC.h-130;
 		this.addChild(node);

 		var fNode = Common.createFontNode(GameManager.getInstance().getCharacterData().hpMax,7);
 		fNode.anchorX = 0;
 		fNode.anchorY = 0;
 		fNode.x = 150;
 		fNode.y = GC.h-130;
 		this.addChild(fNode);
 		this.fAttack = fNode;

 	},
 	loadConfig : function() {
 		this.runningMonstersVector = [];

 		var monsterGroupVector =  Common.deepCopy(GameManager.getInstance().getMonsterGroupVector());
 		var groupWidth = 0;
 		var monsterDataVector = [];

 		this.monsterDataVector = monsterDataVector;

		for (var i = 0; i < monsterGroupVector.length; i++) {
			var groupLen = monsterGroupVector[i].length;

			var isAllZero = false;
			while (!isAllZero) {
				var randNum = Math.ceil(Math.random() * (groupLen)) - 1;

				if (i == monsterGroupVector.length - 1) {
					randNum = Math.ceil(Math.random() * (groupLen - 1)) - 1;
				};

				if (monsterGroupVector[i][randNum] > 0) {
					monsterGroupVector[i][randNum] = monsterGroupVector[i][randNum] - 1;

					var level = randNum + 1;

					var data = {
						level: randNum + 1,
						pos: groupWidth,
						width: GameManager.getInstance().getMonsterImageInfoByField(level-1,"width")*GC.SCALE_RATE,

					}
					monsterDataVector.push(data);

					groupWidth = groupWidth + GameManager.getInstance().getMonsterImageInfoByField(level-1,"width")*GC.SCALE_RATE + GC.DISTANCE_BETTWEN_MONSTER;
				}
				isAllZero = true;

				for (var j = monsterGroupVector[i].length - 1; j >= 0; j--) {
					if (monsterGroupVector[i][j] != 0 && ((i != monsterGroupVector.length) && (j != monsterGroupVector[monsterGroupVector.length - 1].length - 1))) {
						isAllZero = false;
						break;
					};
				};
			}



			if (i < monsterGroupVector.length - 1) {
				var data = {
					level: -1, // -1 为寺庙
					pos: groupWidth,
					width: GC.TEMPLE_WIDTH * GC.SCALE_RATE,
				}
				monsterDataVector.push(data);

				groupWidth = groupWidth + GC.TEMPLE_WIDTH * GC.SCALE_RATE + GC.DISTANCE_BETTWEN_MONSTER;

			};

 			// 保证boss放于最后
 			if (i == monsterGroupVector.length-1) {

 				var bossScale = GameManager.getInstance().bossScale;
 				if (!bossScale) {bossScale = 1};
				var data = {
					level : groupLen,  
					pos   : groupWidth,
					width : GameManager.getInstance().getMonsterImageInfoByField(groupLen-1,"width")*GC.SCALE_RATE*bossScale,
				}
				monsterDataVector.push(data);
 			};
 		};

 	},
 	loadTemple : function(){
 		var node = new Temple();
 		this.addChild(node);	

 		node.setScale(GC.SCALE_RATE);
 		node.setPosition( -2*GC.w , GC.landHeight);
 		node.setAnchorPoint(0.5,0);

 		this.runningMonstersVector.push(node);

 		this.curTempleIndex = this.runningMonstersVector.length -1;
 	},
 	getIdleMonster : function(data){
 		var isFind = false;
 		for (var i = 0; i < this.runningMonstersVector.length; i++) {
 			var node = this.runningMonstersVector[i];
 			if(node.isIdle &&  node.level == data.level){
 				isFind = true;
 				node.isIdle = false;
 				if (node.className == "Monster") {
 					node.reset();
 					this.runningMonstersVector[i].setVisible(true);
 				}else{
 					node.setVisible(true)
 				}

 				data.tmpIndex = i;
 				return node;
 			}
 		};

 		if (data.level == -1){
 			// cc.log("-----------------------------------new temple------------------------")

 			// var node = new Temple();
 			// this.addChild(node);	

 			// node.setScale(GC.SCALE_RATE);
 			// node.setPosition( -2*GC.w , GC.landHeight);
 			// node.setAnchorPoint(0.5,0);

 			// this.runningMonstersVector.push(node);
 		}else {
 			// if (data.level == 5) {
 			// 	cc.log("-----------------------------------new Monster------------------------")

 			// };
 			var node = new Monster(data.level);
 			this.addChild(node);
 			node.setScale(GC.SCALE_RATE);
 			node.setAnchorPoint(0.5,0);
 			node.setPosition( GC.w , GC.landHeight);
 			this.runningMonstersVector.push(node);	


 			var hpBar = new BloodBar();
 			this.addChild(hpBar,4);
 			hpBar.setAnchorPoint(0,0);

 			hpBar.setPosition(node.x - hpBar.getWidth()*GC.SCALE_RATE/2 ,node.y+ GC.HP_BAR_HIGHT)
 			hpBar.setScale(GC.SCALE_RATE);

 			node.setHpBarNode(hpBar);

 			if (data.level == 5) {
 				if (GameManager.getInstance().bossScale) {
 					node.setScale(GC.SCALE_RATE*GameManager.getInstance().bossScale)
 				};
 			};

 			data.tmpIndex = this.runningMonstersVector.length-1;
 		}   
 		return node;
 	},
 	monstersRunning : function(dt){
		var heroObj = GameManager.getInstance().getHeroObj();
		var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;

		var parallaxNode = GameManager.getInstance().GPBackgroundLayer.parallaxNode;
		var moveDis = -parallaxNode.x;

		// 根据移动距离判断该出现的怪物
		for (var i = 0; i < this.monsterDataVector.length; i++) {
			var data = this.monsterDataVector[i];

			var overValue = data.pos + GC.w + data.width;

			if (moveDis <= overValue && moveDis > data.pos ) {
				if (!data.isInScreen) {
					var node = this.getIdleMonster(data);
					node.index = i;
					data.isInScreen = true;

					if (this.isMonsterBack) {
						if (heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT) {
							node.setPosition( -data.width/2 , GC.landHeight);
							if (node.direction) {
								node.setDirection(GC.CHARACTER_DIRECTION.RIGHT);
							};
						}else{
							node.setPosition( GC.w + data.width/2, GC.landHeight);
							if (node.direction) {
								node.setDirection(GC.CHARACTER_DIRECTION.LEFT);
							};
						}
					}else{
						if (this.DeathMoveDirection == "RIGHT" || (!this.DeathMoveDirection && heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT) ) {
							node.setPosition( GC.w + data.width/2, GC.landHeight);
							if (node.direction) {
								node.setDirection(GC.CHARACTER_DIRECTION.LEFT);
							};
						}else{
							node.setPosition( -data.width/2 , GC.landHeight);
							if (node.direction) {
								node.setDirection(GC.CHARACTER_DIRECTION.RIGHT);
							};
						}
					}

					if (node.className == "Temple") {
						if (node.index != this.curTempleIndex) {
							node.showLightTips(false);
						}else{
							node.showLightTips(true);
						}
					}
				}
			}else{
				data.isInScreen = false;
			}

		};


		for (var i = 0; i < this.runningMonstersVector.length; i++) {
			var node = this.runningMonstersVector[i];

			if ((node.x > (GC.w + node.getBoundingBox().width/2)) || (node.x < (-node.getBoundingBox().width/2))) {
				if (!node.isIdle ) {
					node.isIdle = true;
					node.setVisible(false);
					this.monsterDataVector[node.index].isInScreen = false;
					if (node.className != "Temple") {
						node.hpNode.setVisible(false);
					};
				};

			}else{
				if ( node.className == "Temple" || !node.getIsDeath()) {
					node.x = node.x - heroObj.getSpeed() *dt*dir;
					if (node.className != "Temple") {
						node.resetHpBar();
					};
				};
			}
		};

 	},
 	showMaskLayer : function(b){
 		if (!this.maskLayer) {
 			this.maskLayer = new MaskLayer();
 		}

 		this.maskLayer.setMask(b);
 	},
 	createGoldNode : function(value){
 		if (this.goldNode) {
 			this.goldNode.removeAllChildrenWithCleanup(true)
 			this.goldNode.removeFromParent(true);
 		};

 		var pNode = Common.createFontNode(value,3);

 		this.addChild(pNode);
 		pNode.setPosition(cc.p(GC.w2+30,GC.h-55));
 		pNode.setScale(4);

 		this.goldNode = pNode;
 	},
 	resetFontGold : function(){
 		this.createGoldNode(GameManager.getInstance().getGold());
 	},
 	loadGoldUI : function(){
 		var node = new cc.Sprite(res.ui_biggoldcoin);
 		this.addChild(node);
 		node.setScale(4);
 		node.setPosition(cc.p(GC.w2,GC.h-55));

 		this.resetFontGold();
 	},
 	loadQuitBtn : function(){

        var nodeNormal    = new cc.Sprite(res.btn_back01);
        var nodeSelected  = new cc.Sprite(res.btn_back02);
        var nodeDisabled  = new cc.Sprite(res.btn_back01);

        var node = new cc.MenuItemSprite(
        nodeNormal,
        nodeSelected,
        nodeDisabled,
        function(){
        	if (this.quitLayer) {
        		this.quitLayer.reload();
        	}else{
        		var layer = new GPQuitLayer();
        		this.addChild(layer,100)

        		this.quitLayer = layer;
        	}
    	}.bind(this));

        node.x = GC.w-node.getBoundingBox().width;
        node.y = GC.h - 50;

        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        menu.addChild(node);

 		this.addChild(menu);
 	},
 	loadShopBtn : function(){
        var nodeNormal    = new cc.Sprite(res.btn_sc01);
        var nodeSelected  = new cc.Sprite(res.btn_sc02);
        var nodeDisabled  = new cc.Sprite(res.btn_sc01);

        var node = new cc.MenuItemSprite(
        nodeNormal,
        nodeSelected,
        nodeDisabled,
        function(){

        }.bind(this));

        node.x = 50;
        node.y = GC.h - 50;

        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        menu.addChild(node);

 		this.addChild(menu);
 	},
 	loadPartner : function(isUnlock){
 		this.isUnlocked = isUnlock;

 		var heroObj = GameManager.getInstance().getHeroObj();

 		if (GameManager.getInstance().isPartnerUnlocked("tangseng") && !GameManager.getInstance().getCharacterVector()[1]) {
 			var node = new Partner(GC.PARTNER_TYPE.TANG_SENG);

 			if (!isUnlock) {
 				node.setPosition(heroObj.x - GC.PARTNER_DIS[0], GC.landHeight);
 			}else{
 				if (heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT) {
 					node.setPosition(0, GC.landHeight);
 				}else{
 					node.setPosition(GC.w, GC.landHeight);
 				}
 			}
 			node.setScale(GC.SCALE_RATE)
 			node.setAnchorPoint(0.5,0);
 			this.addChild(node,3);

 			GameManager.getInstance().getCharacterVector()[1] = (node);
 		};

 		if (GameManager.getInstance().isPartnerUnlocked("bajie") && !GameManager.getInstance().getCharacterVector()[2]) {
 			var node = new Partner(GC.PARTNER_TYPE.ZHU_BA_JIE);
 		
 			if (!isUnlock) {
 				node.setPosition(heroObj.x -GC.PARTNER_DIS[1], GC.landHeight);
 			}else{
 				if (heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT) {
 					node.setPosition(0, GC.landHeight);
 				}else{
 					node.setPosition(GC.w, GC.landHeight);
 				}
 			} 			
 			node.setScale(GC.SCALE_RATE)
 			node.setAnchorPoint(0.5,0);
 			this.addChild(node,2);
 			GameManager.getInstance().getCharacterVector()[2] = (node);
 		}

 		if (GameManager.getInstance().isPartnerUnlocked("shaseng") && !GameManager.getInstance().getCharacterVector()[3]) {
 			var node = new Partner(GC.PARTNER_TYPE.SHA_SENG);
 		
 			if (!isUnlock) {
 				node.setPosition(heroObj.x -GC.PARTNER_DIS[2], GC.landHeight);
 			}else{
 				if (heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT) {
 					node.setPosition(0, GC.landHeight);
 				}else{
 					node.setPosition(GC.w, GC.landHeight);
 				}
 			} 			
 			node.setScale(GC.SCALE_RATE)
 			node.setAnchorPoint(0.5,0);
 			this.addChild(node,1);
 			GameManager.getInstance().getCharacterVector()[3] = (node);
 		}
 	},
 	loadHero : function() {
 		var heroObj = new Hero();

 		heroObj.setPosition(GC.w2-300, GC.landHeight);
 		heroObj.setAnchorPoint(0.5,0);
 		this.addChild(heroObj,4);
 		GameManager.getInstance().setHeroObj(heroObj);
 		GameManager.getInstance().getCharacterVector()[0] = (heroObj);
 		heroObj.ignoreAnchorPointForPosition(false);

 		var hpBar = new BloodBar();
 		this.addChild(hpBar,4);
 		hpBar.setPosition(heroObj.x - heroObj.getBoundingBox().width/2,heroObj.y+ GC.HP_BAR_HIGHT)
 		hpBar.setScale(GC.SCALE_RATE);

 		heroObj.setHpBarNode(hpBar);

 		this.loadPartner();
 	},
 	bindTouchListener : function() {
 		var listener = cc.EventListener.create({
 		    event           : cc.EventListener.TOUCH_ONE_BY_ONE,
 		    target          : this,
 		    swallowTouches  : true,
 		    onTouchBegan    : this.onTouchBegan,
 		    onTouchMoved    : this.onTouchMoved,
 		    onTouchEnded    : this.onTouchEnded
 		});
 		cc.eventManager.addListener(listener, this);
 	},

 	// 事件[触摸开始]
 	onTouchBegan: function (touch, event) {
 		var target = this.target;

 		var location = touch.getLocation();
 		var p = GameManager.getInstance().getParallaxLayer();
 		var heroObj = GameManager.getInstance().getHeroObj();

 		heroObj.setIsSpeedReduce(false);

 		if(heroObj.getIsDeath()){
 			if (heroObj.isDeathAnimationFinished) {
 				heroObj.isDeathAnimationFinished = false;

 				var parallaxNode = GameManager.getInstance().GPBackgroundLayer.parallaxNode;
 				var moveDis = -parallaxNode.x;


 				target.isDeathClick = true;

 				target.DeathMoveDirection = "LEFT";

 				if (moveDis > target.curTemplePos) {
 					target.DeathMoveDirection = "LEFT";
 				}else{
 					target.DeathMoveDirection = "RIGHT";
 				}


 				var callBack = function(){
 					target.scheduleUpdate();
 				}

 				var cVector = GameManager.getInstance().getCharacterVector();
 				for (var i = 0; i < cVector.length; i++) {
 					cVector[i].deathFadeOut(callBack);
 				};
 			};
 		}else{
 			heroObj.setIsMove(true);
 			var cVector = GameManager.getInstance().getCharacterVector();
 			for (var i = 0; i < cVector.length; i++) {
 				cVector[i].loadAnimation();
 			};


 			var CenterX = heroObj.x;

 			if(location.x > CenterX){
 				heroObj.setDirection(GC.CHARACTER_DIRECTION.RIGHT);
 			}else {
 				heroObj.setDirection(GC.CHARACTER_DIRECTION.LEFT);
 			}

 			heroObj.resetSpeed();

 		}

 	    return true;
 	},

 	// 事件[触摸移动]
 	onTouchMoved: function (touch, event) {
 		var target = this.target;

 		var location = touch.getLocation();
 		var heroObj = GameManager.getInstance().getHeroObj();
 		var CenterX = heroObj.x ;

		if(location.x > CenterX){
			heroObj.setDirection(GC.CHARACTER_DIRECTION.RIGHT);
		}else {
			heroObj.setDirection(GC.CHARACTER_DIRECTION.LEFT);
		}	
 
 		
 	},

 	// 事件[触摸结束]
 	onTouchEnded: function (touch, event) {
 	    var target = this.target;
 	    var heroObj = GameManager.getInstance().getHeroObj();
 	    var p = GameManager.getInstance().getParallaxLayer();

 	    heroObj.setIsMove(false);

 	    if (!heroObj.getIsDeath()) {
 	    	EffectManager.getInstance().playBrakeEffect();
 	    };
 	    heroObj.setIsSpeedReduce(true);
 	},
 	GameSucceed : function(){
		GameManager.getInstance().unlockPartner();
		var curLevel = GameManager.getInstance().getCurLevel();
		if(GameManager.getInstance().getUnlockLevel() == curLevel ){
			GameManager.getInstance().setUnlockLevel(curLevel + 1);
		}
		GameManager.getInstance().setCurLevel(curLevel + 1);
		GameManager.getInstance().saveLocalData();

 		this.unscheduleUpdate();
 		var transitionScene = new cc.TransitionProgressInOut(1, new ChooseLevelScene());
 		cc.director.runScene(transitionScene);
 	},
 	// 回复血瓶判断
 	createBloodPot : function(monster){
 		var value = Common.randomInt(1,100);

 		var ret = -1;

 		var totalValue = 0;
 		for (var i = 0; i < GC.BLOOD_POT.length; i++) {
 		 	var item = GC.BLOOD_POT[i];

 		 	if ( i == 0 ) {
 		 		if (value <= 100*item[1]) {
 		 			ret = i;
 		 			break;
 		 		};
 		 	}else{
 		 		if (value > totalValue && value <= totalValue + 100*item[1]) {
 		 			ret = i;
 		 			break;
 		 		};
 		 	}
 		 	totalValue = totalValue + 100*item[1];
 		 }; 

 		 if (ret != -1) {
 		 	EffectManager.getInstance().playBloodPotEffect(ret,monster);
 		 };

 	},
 	checkMonsterCollision : function(){
 		var heroObj = GameManager.getInstance().getHeroObj();
 		var monsterVector = GameManager.getInstance().getMonsterVector();

 		var heroRect = heroObj.getCollisionRect();
 		var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;

 		var isIntersect = false;

		for (var i = 0; i < this.runningMonstersVector.length; i++) {
			var node = this.runningMonstersVector[i];
			if (  node.className == "Monster" && !node.getIsDeath() && !node.isIdle && !this.isMonsterBack)
			{
				var monsterRect = node.getCollisionRect();
				heroRect = heroObj.getCollisionRect();
				if(cc.rectIntersectsRect(heroRect,monsterRect)){
					var options = GPDataManager.getInstance().roleCollisionEffectJudge(heroObj,node);


					node.onHit(options);
					heroObj.onHit(options);

					EffectManager.getInstance().playCommonAttFontEffect(options.hAttack,node);

				    if (options.isMonsterDeath) {
			    		this.createBloodPot(node);

			    		EffectManager.getInstance().playMonsterDeathEffect();
			    		EffectManager.getInstance().playCreateAwardEffect(options.monsterGold,node);


			    		if (node.level == 5) {
			    			cc.log("gameOVER")
			    			this.GameSucceed();
			    		};

				    }
				    if (options.actionType == 1 || options.actionType == 2) {
				    	this.isMonsterBack = true;

				    	var backDis = 0;
				    	var backTime = 0;
				    	if (options.actionType == 1) {
				    		backDis = GC.FIGHT_RULE[1][0][0];
				    		backTime = GC.FIGHT_RULE[1][0][1];
				    	}else{
				    		backDis = GC.FIGHT_RULE[1][1][0];
				    		backTime = GC.FIGHT_RULE[1][1][1];
				    	}

				    	this.monsterMoveDis = backDis;
				    	this.monsterBackSpeed = backDis/backTime;
				    };

				    if (options.isHeroDeath) {
			    		var curGold = GameManager.getInstance().getGold();
			    		GameManager.getInstance().setGold( Math.floor( (1 - GC.LOSTMONEY_RATE)*curGold) );
			    		GameManager.getInstance().saveLocalData();

			    		this.resetFontGold();
			    		this.unscheduleUpdate();

			    		EffectManager.getInstance().playLostAwardEffect(Math.floor(curGold*GC.LOSTMONEY_RATE) );

			    		var cVector = GameManager.getInstance().getCharacterVector();
			    		for (var i = 1; i < cVector.length; i++) {
			    			cVector[i].loadDeathAnimaiton();
			    		};

			    		this.isMonsterBack = false;
				    };

				    break;
				}
			}else if( node.className == "Temple" && !node.isIdle){
				heroRect = heroObj.getTempleCollisionRect();
				var isIntersect = false;

				var nodePos = node.getPosition();
				var nodeRect = cc.rect(
				    nodePos.x -node.getBoundingBox().width/2,
				    nodePos.y ,
				    node.getBoundingBox().width,
				    node.getBoundingBox().height
				);

				if(cc.rectIntersectsRect(heroRect,nodeRect)){
					var index = this.runningMonstersVector[i].index;
					this.curTemplePos = this.monsterDataVector[index].pos + GC.TEMPLE_WIDTH*GC.SCALE_RATE/2+GC.w2;

					this.curTempleIndex = index;
					node.showLightTips(true);

					isIntersect = true;

				}
				node.showUpgradeSite(isIntersect);
				heroObj.setIsOnSite(isIntersect);
			}

			if (isIntersect) { isIntersect = false; break};
 		}
 	},
 	checkCollision : function(){
 		this.checkMonsterCollision();
 	},
 	// 唐僧 猪八戒 沙僧影子效果
 	partnerFollow  :function(dt){
 		var heroObj = GameManager.getInstance().getHeroObj();

		var cVector = GameManager.getInstance().getCharacterVector();
		var unlockNum = 0;
		for (var i = 0; i < cVector.length; i++) {
			var node = cVector[i];
			if(i == 0){
			}else{
				var pos = 0
				if (cVector[0].getDirection() == GC.CHARACTER_DIRECTION.RIGHT) {
					pos = heroObj.x - GC.PARTNER_DIS[i-1];
				}else{
					pos = heroObj.x +  GC.PARTNER_DIS[i-1];
				}

				if(node.getPositionX() != pos){

					var nodeDir = (node.getPositionX()>pos) ? -1 : 1;

					var direction = nodeDir==-1 ? GC.CHARACTER_DIRECTION.LEFT : GC.CHARACTER_DIRECTION.RIGHT;
					var speed = heroObj.getSpeed();
					if (speed == 0) {
						speed = GC.HERO_SPEED;
					};

					var dis = node.getPositionX() + speed * dt*nodeDir*0.5;

					if( nodeDir > 0 && dis > pos){
						dis = pos;
						node.setDirection(cVector[0].getDirection());

					}else if( nodeDir < 0 && dis < pos){
						dis = pos;
						node.setDirection(cVector[0].getDirection());

					}else{
						node.setDirection(direction);
					}
					node.setPositionX( dis);
				}else{
					unlockNum = unlockNum + 1;
				}
			}

			if (this.isUnlocked && unlockNum == cVector.length-1) {
				this.isUnlocked = false;
				this.showMaskLayer(false);
			};
		}
 	},
 	wukongRunning : function(dt){
 		var heroObj = GameManager.getInstance().getHeroObj();
 		var monsterVector = GameManager.getInstance().getMonsterVector();
 		var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;

 		var parallaxNode = GameManager.getInstance().GPBackgroundLayer.parallaxNode;
 		var moveDis = -parallaxNode.x;

 		if(heroObj.getIsMove() || heroObj.getIsDeath()){
 			var num =  heroObj.getSpeed() * dt*dir*0.5;

 			if (heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT) {
 				if ( (heroObj.getPositionX() + num) > GC.w2) {
 					heroObj.x = GC.w2
 				}else{
 					heroObj.x = heroObj.getPositionX() + num;
 				}
 			};


 			if (heroObj.getDirection() == GC.CHARACTER_DIRECTION.LEFT) {
 				var limitNum = GC.w2
 				if (moveDis <= 0 ) {
 					limitNum = 0
 				}
 				if ( (heroObj.getPositionX() + num) < limitNum) {
 					heroObj.x = limitNum
 				}else{
 					heroObj.x = heroObj.getPositionX() + num;
 				}
 			};

 			if (heroObj.x < GC.w2 && moveDis <= 0) {
 				this.isMonsterCanRun = false
 			}else{
 				this.isMonsterCanRun = true
 			}

 			heroObj.resetHpBar();
 		}
 	},
 	resetMonstersDirection : function(){
 		var heroObj = GameManager.getInstance().getHeroObj();

 		for (var i = 0; i < this.runningMonstersVector.length; i++) {
 			var node = this.runningMonstersVector[i];
			if (!node.isIdle && node.className == "Monster" ) {
				if(node.getPositionX() < heroObj.getPositionX()){
					node.setDirection(GC.CHARACTER_DIRECTION.RIGHT);
				}else{
					node.setDirection(GC.CHARACTER_DIRECTION.LEFT);
				}
			};
 		};
 	},
 	HeroRevive : function(){
 		var heroObj = GameManager.getInstance().getHeroObj();

 		heroObj.reset();
 		this.resetMonstersDirection();
 		this.isDeathClick = false;

 		var cVector = GameManager.getInstance().getCharacterVector();
 		for (var i = 0; i < cVector.length; i++) {
 			cVector[i].deathFadeIn();
 		};

 		this.DeathMoveDirection = null;
 	},
 	// 更新[游戏逻辑]
 	update : function(dt){
 		var heroObj = GameManager.getInstance().getHeroObj();

 		if (heroObj.getIsMove() || heroObj.getIsSpeedReduce() ) {
 			heroObj.setSpeed(dt);
 		};

 		if (this.isMonsterBack) {
 			heroObj.setIsSpeedReduce(false);

 			dt = -Math.abs(dt);
 			heroObj.resetSpeed(this.monsterBackSpeed);

 			this.monsterMoveDis = this.monsterMoveDis - Math.abs(heroObj.getSpeed()*dt);
 			if (this.monsterMoveDis < 0) {
 				this.isMonsterBack = false;
 				cc.log("false======")

 				return
 			};
 		};


 		//检测碰撞
 		if (!heroObj.getIsDeath() ) {
 			this.checkCollision();
		}
 		// 唐僧 猪八戒 沙僧影子效果
 		if(heroObj.getIsMove() || this.isUnlocked || heroObj.getIsSpeedReduce()){
 			this.partnerFollow(dt);
 		}
 		// 悟空奔跑
 		if (!this.isMonsterBack) {
 			this.wukongRunning(dt);
 		}

 		if(this.isMonsterCanRun && (heroObj.getIsMove() || heroObj.getIsDeath() || heroObj.getIsSpeedReduce() || this.isMonsterBack  ) ){
 			if (heroObj.getIsDeath() && this.isDeathClick) {
 				var parallaxNode = GameManager.getInstance().GPBackgroundLayer.parallaxNode;
 				var moveDis = -parallaxNode.x;


 				if ( (this.DeathMoveDirection == "LEFT" && heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT)|| (this.DeathMoveDirection == "RIGHT" && heroObj.getDirection() == GC.CHARACTER_DIRECTION.LEFT) ) {
 					dt = - Math.abs(dt);
 				}; 

 				heroObj.resetSpeed(GC.HERO_SPEED);

 				if (this.DeathMoveDirection == "LEFT") {
 					if (moveDis <= this.curTemplePos) {
 						this.HeroRevive();
 					};
 				}else{
 					if (moveDis >= this.curTemplePos) {
 						this.HeroRevive();
 					};
 				}

 			};

 			// 前景视差
 			GameManager.getInstance().foreParallaxLayer.update(dt);
 			// 背景视差
 			GameManager.getInstance().GPBackgroundLayer.update(dt);
 			// 怪物与寺庙移动
 			this.monstersRunning(dt);
 			//特效移动
 			if (!this.isMonsterBack) {	
 				EffectManager.getInstance().update(dt);
 			}
 		}

 	}
 });