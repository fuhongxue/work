/**
 * loadd by wangzhigang on 15/9/15.
 */

 var TV_PN_RES = [
 	{name: "f05006",attr : "f07_hp", bg: "i01_05",tag : 1,cName : "tangseng"},
 	{name: "f05007",attr : "f07_dps", bg: "i01_06",tag : 2,cName : "bajie"},
 	{name: "f05008",attr : "f07_hp", bg: "i01_07",tag : 3,cName : "shaseng"},

 ];

 var TV_PN_TAG = {
 	BG             : 126,
 	MENUITEM 	   : 124,
 	MENU     	   : 125,
 	FONT_LV        : 128,
 	FONT_GOLD 	   : 129,
 	FONT_ADDATTR   : 130,
 	NAME		   : 123
 };

 var GPPartnerTableView = cc.TableView.extend({
 	// cellNum : 2,
 	ctor : function(){
 		this._super(this,cc.size(580/4, 300));
 		this.loadConfig();

 	},
 	loadConfig : function(){
 		this.setDirection(cc.SCROLLVIEW_DIRECTION_HORIZONTAL);
 		this.x = -70;
 		this.y = -35;
 		this.reloadData();

 	},
 	numberOfCellsInTableView:function (table) {
 		// return this.cellNum ;
 	    return GameManager.getInstance().getUnlockPartnerNum();
 	},
 	tableCellSizeForIndex:function (table, idx) {
 	    return cc.size(160/4, 300);
 	},
 	loadIcon : function(cell,idx){

 		var node = cell.getChildByTag(TV_PN_TAG.BG);

 		if (!node) {

 			var node = new cc.Sprite(res[TV_PN_RES[idx].bg]);
 			node.anchorX = 0;
 			node.anchorY = 0;
 			node.x = 2;
 			node.y = 30;
 			cell.addChild(node);
 			node.tag = TV_PN_TAG.BG;
 		}else{

 			var icon = cell.getChildByTag(TV_PN_TAG.BG);
 			icon.setTexture(res[TV_PN_RES[idx].bg]);
 		}

 	},
 	loadMenuItem : function(cell,idx){

 		var node = cell.getChildByTag(TV_PN_TAG.MENU);

 		if (!node) {

 			var nodeNormal    = new cc.Sprite(res.ui_btn_zdxf_02);
 			var nodeSelected  = new cc.Sprite(res.ui_btn_zdxf_01);
 			var nodeDisabled  = new cc.Sprite(res.ui_btn_zdxf_02);

 			var node
 			node= new cc.MenuItemSprite(
 			nodeNormal,
 			nodeSelected,
 			nodeDisabled,
 			function(){
 				this.onUpgradeItem(cell,node.idx);
 			}.bind(this));

 			node.idx = idx;
 			node.x = 17;
 			node.y = 17;
 			node.setScale(1/GC.SCALE_RATE);

 			node.tag = TV_PN_TAG.MENUITEM;

 			var menu = new cc.Menu();
 			menu.setPosition(0, 0);
 			menu.addChild(node);
 			cell.addChild(menu);

 			menu.setSwallowTouches(false);
 			menu.tag = TV_PN_TAG.MENU;

 		}else{
 			var menu = cell.getChildByTag(TV_PN_TAG.MENU);
 			var menuItem = menu.getChildByTag(TV_PN_TAG.MENUITEM);


 			menuItem.idx = idx;
 		}

 	},
 	loadFontLv : function(cell,idx,isClean){

 		var menu = cell.getChildByTag(TV_PN_TAG.MENU);
 		var menuItem = menu.getChildByTag(TV_PN_TAG.MENUITEM);

 		var node = menuItem.getChildByTag(TV_PN_TAG.FONT_LV);

 		function clean(){
 			menuItem.fLv.removeFromParent();
 			var value = GameManager.getInstance().getCharacterLevel(TV_PN_RES[idx].tag);
 			var fNode = Common.createFontNode(value,10);
 			fNode.anchorX = 0;
 			fNode.anchorY = 0;
 			fNode.x = 60;
 			fNode.y = 110;
 			menuItem.addChild(fNode);
 			menuItem.fLv = fNode;
 			fNode.tag = TV_PN_TAG.FONT_LV;
 		}

 		if (isClean) {
 			clean();

 			return;
 		}

 		if (!node) {
 			var node= new cc.Sprite(res.f10_lv);
 			node.anchorX = 0;
 			node.anchorY = 0;
 			node.x = 10;
 			node.y = 95;
 			menuItem.addChild(node);

 			menuItem.Lv = node;


 			var value = GameManager.getInstance().getCharacterLevel(TV_PN_RES[idx].tag);
 			var fNode = Common.createFontNode(value,10);
 			fNode.anchorX = 0;
 			fNode.anchorY = 0;
 			fNode.x = 60;
 			fNode.y = 110;
 			menuItem.addChild(fNode);
 			menuItem.fLv = fNode;
 			fNode.tag = TV_PN_TAG.FONT_LV;
 		}else{
 			clean();
 		}
 	},
 	loadFontGold : function(cell,idx,isClean){
 		var menu = cell.getChildByTag(TV_PN_TAG.MENU);
 		var menuItem = menu.getChildByTag(TV_PN_TAG.MENUITEM);
 		var value = GameManager.getInstance().getCharacterNeedGold(TV_PN_RES[idx].tag);
 		var gold = GameManager.getInstance().getGold();

 		var node = menuItem.getChildByTag(TV_PN_TAG.FONT_GOLD);


 		function clean(){
 			menuItem.fGold.removeFromParent();
 			var fNode = Common.createFontNode(value,3);
 			fNode.anchorX = 0;
 			fNode.anchorY = 0;
 			fNode.x = 40;
 			fNode.y = 55;
 			fNode.setScale(2)
 			menuItem.addChild(fNode,1);
 			menuItem.fGold = fNode;
 			fNode.tag = TV_PN_TAG.FONT_GOLD;
 		}

 		if (isClean) {
 			clean();

 			return;
 		}
 		if (!node) {
	 		var node = new cc.Sprite(res.ui_gold2020);
	 		node.anchorX = 0;
	 		node.anchorY = 0;
	 		node.x = 5;
	 		node.y = 45;
	 		menuItem.addChild(node,1);

	 		menuItem.goldIcon = node;

			var fNode = Common.createFontNode(value,3);
			fNode.anchorX = 0;
			fNode.anchorY = 0;
			fNode.x = 40;
			fNode.y = 55;
			fNode.setScale(2)
			menuItem.addChild(fNode,1);

			menuItem.fGold = fNode;
			fNode.tag = TV_PN_TAG.FONT_GOLD;
 		}else{
 			clean();
 		}

 	},
 	loadFontAttr : function(cell,idx,isClean){
 		var menu = cell.getChildByTag(TV_PN_TAG.MENU);
 		var menuItem = menu.getChildByTag(TV_PN_TAG.MENUITEM);
 		var value = GameManager.getInstance().getCharacterAddAttr(TV_PN_RES[idx].tag);

 		var node = menuItem.getChildByTag(TV_PN_TAG.FONT_ADDATTR);


 		function clean(){
 			menuItem.fAttr.removeFromParent();
 			var value = GameManager.getInstance().getCharacterAddAttr(TV_PN_RES[idx].tag);
 			var fNode = Common.createFontNode(value,7);
 			fNode.anchorX = 0;
 			fNode.anchorY = 0;
 			fNode.x = 80;
 			fNode.y = 25;
 			menuItem.addChild(fNode,1);
 			menuItem.fAttr = fNode;
 			fNode.tag = TV_PN_TAG.FONT_ADDATTR;

 			menuItem.dps.setTexture(res[TV_PN_RES[idx].attr]);
 		}

 		if (isClean) {
 			clean();

 			return;
 		}

 		if (!node) {
 			var node = new cc.Sprite(res[TV_PN_RES[idx].attr]);
 			node.x = 30;
 			node.y = 25;
 			menuItem.addChild(node,1);
 			menuItem.dps = node;

 			var plus= new cc.Sprite(res.f07_plus);
 			plus.x = 65;
 			plus.y = 25;
 			menuItem.plus = plus;

 			menuItem.addChild(plus,1);

 			var fNode = Common.createFontNode(value,7);
 			fNode.anchorX = 0;
 			fNode.anchorY = 0;
 			fNode.x = 80;
 			fNode.y = 25;
 			menuItem.addChild(fNode,1);
 			menuItem.fAttr = fNode;
 			fNode.tag = TV_PN_TAG.FONT_ADDATTR;
 		}else{
 			clean();
 		}

 	},
 	loadFontName : function(cell,idx){
 		var node = cell.getChildByTag(TV_PN_TAG.NAME);

 		if (!node) {
	    	var node = new cc.Sprite(res[TV_PN_RES[idx].name]);
	    	node.anchorX = 0;
	    	node.anchorY = 0;
			node.x = 5;
			node.y = 52;
	    	node.setScale(1/4);
	    	node.tag = TV_PN_TAG.NAME;
	    	cell.addChild(node,2);
 		}else{
 			var node = cell.getChildByTag(TV_PN_TAG.NAME);
 			node.setTexture(res[TV_PN_RES[idx].name]);
 		}
 	},
	onUpgradeItem : function(cell,idx){
		var value = GameManager.getInstance().getCharacterNeedGold(TV_PN_RES[idx].tag);
		var gold = GameManager.getInstance().getGold();

	   	var menu = cell.getChildByTag(TV_PN_TAG.MENU);
	   	var menuItem = menu.getChildByTag(TV_PN_TAG.MENUITEM);
	   	if (GameManager.getInstance().getPartnerUnlockedStatus(TV_PN_RES[idx].cName) == 0){

	   	}else if(GameManager.getInstance().getPartnerUnlockedStatus(TV_PN_RES[idx].cName) == 1) {
	   		GameManager.getInstance().GPMainLayer.showMaskLayer(true);

	   		GameManager.getInstance().setPartnerUnlockedStatus(TV_PN_RES[idx].cName,2);
	   		GameManager.getInstance().saveLocalData();

	   		this.setUIStatus(cell,idx);
	   		GameManager.getInstance().GPMainLayer.loadPartner(true);

	   		this.reloadData();
	   	}else{
	   		if (gold >= value) {
	   			// 数据处理
	   			var lv = GameManager.getInstance().getCharacterLevel(TV_PN_RES[idx].tag);
	   			GameManager.getInstance().setCharacterLevel(TV_PN_RES[idx].tag,(lv+1));
	   			GameManager.getInstance().resetRoleData();
	   			GameManager.getInstance().setGold(gold - value);
	   			GameManager.getInstance().saveLocalData();

	   			// if (TV_PN_RES[idx].tag == 1 || TV_PN_RES[idx].tag == 3) {
	   				var heroObj = GameManager.getInstance().getHeroObj();
	   				heroObj.addHp(GameManager.getInstance().getCharacterData().hpMax*GC.UPGRADE_HP_RATE);
	   			// };



	   			EffectManager.getInstance().playLevelUpEffect();

	   			GameManager.getInstance().GPMainLayer.resetFontGold();

	   			this.loadFontGold(cell,idx,true);
	   			this.loadFontAttr(cell,idx,true);
	   			this.loadFontLv(cell,idx,true);
	   			this.reloadData();

	   		}else{
	   			cc.log("gold less")
	   		}
	   	}

	   	if (GameManager.getInstance().GPUpgradeSiteLayer) {
	   		if (GameManager.getInstance().getPartnerUnlockedStatus(TV_PN_RES[idx].cName) > 0) {
	   			GameManager.getInstance().GPUpgradeSiteLayer.showTips();
	   		};
	   	};

	},
	setUIStatus : function(cell,idx){
		var menu = cell.getChildByTag(TV_PN_TAG.MENU);
		var menuItem = menu.getChildByTag(TV_PN_TAG.MENUITEM);

		if (GameManager.getInstance().getPartnerUnlockedStatus(TV_PN_RES[idx].cName) == 0){
			menuItem.setNormalImage(new cc.Sprite(res.ui_btn_unjs));
			menuItem.setSelectedImage(new cc.Sprite(res.ui_btn_unjs));

			menuItem.fGold.setVisible(false);
			menuItem.fLv.setVisible(false);
			menuItem.Lv.setVisible(false);
			menuItem.goldIcon.setVisible(false);
			menuItem.dps.setVisible(false);
			menuItem.plus.setVisible(false);
			menuItem.fAttr.setVisible(false);
		}else if(GameManager.getInstance().getPartnerUnlockedStatus(TV_PN_RES[idx].cName) == 1) {
			menuItem.setNormalImage(new cc.Sprite(res.ui_btn_js_01));
			menuItem.setSelectedImage(new cc.Sprite(res.ui_btn_js_02));

			menuItem.fGold.setVisible(false);
			menuItem.fLv.setVisible(false);
			menuItem.Lv.setVisible(false);
			menuItem.goldIcon.setVisible(false);
			menuItem.dps.setVisible(false);
			menuItem.plus.setVisible(false);
			menuItem.fAttr.setVisible(false);

		}else{
			var value = GameManager.getInstance().getCharacterNeedGold(TV_PN_RES[idx].tag);
			var gold = GameManager.getInstance().getGold();

			if (gold >= value) {
				menuItem.setNormalImage(new cc.Sprite(res.ui_btn_zdxf_01));
				menuItem.setSelectedImage(new cc.Sprite(res.ui_btn_zdxf_02));
			}else{
				menuItem.setNormalImage(new cc.Sprite(res.ui_btn_unzdxf));
				menuItem.setSelectedImage(new cc.Sprite(res.ui_btn_unzdxf));
			}

			menuItem.fGold.setVisible(true);
			menuItem.fLv.setVisible(true);
			menuItem.Lv.setVisible(true);
			menuItem.goldIcon.setVisible(true);
			menuItem.dps.setVisible(true);
			menuItem.plus.setVisible(true);
			menuItem.fAttr.setVisible(true);
		}

	},
 	tableCellAtIndex:function (table, idx) {
 	    var cell = table.dequeueCell();

 	    if (!cell) {
 	        cell = new CustomTableViewCell();
 	        cell.setCascadeOpacityEnabled(true);
 	    }

	    this.loadIcon(cell,idx);
	    this.loadMenuItem(cell,idx);
	    this.loadFontLv(cell,idx);
	    this.loadFontGold(cell,idx);
	    this.loadFontAttr(cell,idx);
	    this.loadFontName(cell,idx);
	    this.setUIStatus(cell,idx);
 	    return cell;
 	},

 });