/**
 * Created by wangzhigang on 15/8/20.
 */

var GC = GC || {};

GC.init = function(){
	cc.log("init")
	GC.winSize = cc.director.getWinSize();
	GC.w = GC.winSize.width;
	GC.h = GC.winSize.height;
	GC.w2 = GC.w / 2;
	GC.h2 = GC.h / 2;
}

GC.winSize  = null;
GC.w        = 0;
GC.h        = 0;
GC.w2       = 0;
GC.h2       = 0;

GC.landHeight = 150;

GC.touchDistance = 300;

GC.CHARACTER_DIRECTION = {
	RIGHT : 1,
	LEFT  : 2
};

GC.DISTANCE_BETTWEN_MONSTER = 100;
GC.TEMP_WIDTH = 200;

GC.SCALE_RATE = 4

GC.HP_BAR_HIGHT = -30

GC.PARTNER_TYPE = {
	TANG_SENG  : 2,
	ZHU_BA_JIE : 3,
	SHA_SENG   : 4,
}

//回移最大距离
GC.RECOIL_DISTANCE = 300

//往前移动的时间
GC.RECOIL_TIME1 = 0.4
//往回移动的时间
GC.RECOIL_TIME2 = 0.4


GC.PARTNER_DIS = [
	120,
	270,
	370
]

GC.WEAPON_EFFECT_TIME = 0.025
GC.START_CHARATER_EFFECT_TIME = 0.1
GC.MONSTER_EFFECT_TIME = 0.025

GC.TEMPLE_WIDTH = 133;
