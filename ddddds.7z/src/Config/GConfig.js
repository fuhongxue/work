


GC.HERO_SPEED = 1000;       //英雄最大速度
GC.HERO_HP_RATE = 0.001       //回血百分比
GC.HERO_HP_TIME = 0.1      //每次回血间隔
GC.UPGRADE_HP_RATE = 0.8    //每次英雄升级回血百分比 0.5即50%=======
GC.LOSTMONEY_RATE = 0.2     //死后数值：损失当前金钱总量的20%



GC.HERO_START_SPEED = 500; // 英雄初始速度
GC.HERO_ACCELERATED_SPEED = GC.HERO_SPEED/3; //英雄加速度(几秒加到最大速度)


GC.HERO_REDUCE_SPEED = 10000; // 英雄减速过程中速度减少的量

GC.CREATE_AWARD_EFFECT = {
	
	A1_TIME : function(){   return 0.5;                             },
	A1_X    : function(){   return 10 + 500*Math.random();          },
	A1_H    : function(){	return 20  + 250*Math.random();         },
	A1_NUM  : function(){	return 1;                               },

	A2_TIME : function(){	return 0.4;                             },
	A2_X    : function(){	return 40 + 100*Math.random();          },
	A2_H    : function(){	return 20  + 50*Math.random();          },
	A2_NUM  : function(){	return 1 + Math.floor(3*Math.random()); },
};


GC.CREATE_BLOODPOT_EFFECT = {
	
	A1_TIME : function(){   return 0.5;                             },
	A1_X    : function(){   return 10 + 100*Math.random();          },
	A1_H    : function(){	return 20  + 250*Math.random();         },
	A1_NUM  : function(){	return 1;                               },

	A2_TIME : function(){	return 0.4;                             },
	A2_X    : function(){	return 40 + 50*Math.random();          },
	A2_H    : function(){	return 20  + 50*Math.random();          },
	A2_NUM  : function(){	return 1 + Math.floor(3*Math.random()); },
};



// 攻击力浮动范围：90%-110%（取整）
GC.ATTACK_RATE = [0.9,1.1];  

// 站点回复血量百分比
GC.HERO_SITE_HP_RATE = 0.01; 

// 血瓶掉落规则
GC.BLOOD_POT = [
	// 回复血量百分比，掉率
	[0.3,0.05],
	[0.5,0.05],
];


GC.FIGHT_RULE = [
	// 概率参数
	[0.7,1.3],
	[
		// 小于80%
		[
			//怪物没死 后退距离 
			250,
			//怪物没死 后退距离对应完成的时间
			0.3,
			// 悟空y轴移动幅度
			20,
		],
		// 80%-130%
		[
			// 怪物后退距离
			15,
			//怪物后退距离对应完成的时间
			0.05,
		],
		// 大于130%
		[
			// 怪物后退距离
			function(){
				return 10 + Math.random()*200;
			},
			//怪物后退距离对应完成的时间
			0.5,
			// 怪物Y轴高度
			function(){
				return 10 + Math.random()*200;
			},
		],
		//减速的系数
		0,
	]

]