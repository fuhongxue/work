/**
 * Created by wangzhigang on 15/8/28.
 */

 var Level46 = {
 	// 地图类型 该类型下的第几套图
 	mapInfo : ["type2","01"],
 	temple  : "t02",
 	groups : [
 		//1,2,3,4级怪以及boss数量
		[2,2,0,0,0],
		[4,3,0,0,0],
		[2,3,3,0,0],
		[2,3,6,0,0],
		[0,3,5,3,0],
		[0,2,4,5,0],
		[0,2,3,7,1],

 	],
 	monster : [
		{hp : 223,attack : 8,gold : 9,image : 21},
		{hp : 230,attack : 9,gold : 10,image : 22},
		{hp : 235,attack : 9,gold : 11,image : 23},
		{hp : 241,attack : 10,gold : 12,image : 24},

 		// BOSS
		{hp : 500,attack : 30,gold : 48,image : 27},

	],
 }