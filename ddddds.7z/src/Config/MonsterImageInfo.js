

var MonsterImageInfo = [
	// 0
	{},
	{
		img : "0001",       // 图片名称
		adjustWidth : 17*4,  // 棒子深入距离
		width : 34,         // 图片大小
	},
	// 1
	{
		img : "0002",
		adjustWidth : 16*4,
		width : 36,         // 图片大小
	},
	// 2
	{
		img : "0003",
		adjustWidth : 28*4,
		width : 50,         // 图片大小
	},
	// 3
	{
		img : "0004",
		adjustWidth : 16*4,
		width : 47,         // 图片大小
	},
	// 4
	{
		img : "0005",
		adjustWidth : 22*4,
		width : 33,         // 图片大小
	},
	// 5
	{
		img : "0006",
		adjustWidth : 12*4,
		width : 57,         // 图片大小
	},
	// 6
	{
		img : "0007",
		adjustWidth : 57*4,
		width : 89,         // 图片大小
	},
	// 7
	{
		img : "0008",
		adjustWidth : 32*4,
		width : 65,         // 图片大小
	},
	// 8
	{
		img : "0009",
		adjustWidth : 38*4,
		width : 89,         // 图片大小
	},
	// 9
	{
		img : "0010",
		adjustWidth : 75*4,
		width : 75,         // 图片大小
	},
	// 10
	{
		img : "0011",
		adjustWidth : 35*4,
		width : 92,         // 图片大小
	},
	// 11
	{
		img : "0012",
		adjustWidth : 25*4,
		width : 72,         // 图片大小
	},
    // 下面是车迟国-----------
	{
		img : "0013",
		adjustWidth : 20*4,
		width : 33,         // 图片大小
	},
	{
		img : "0014",
		adjustWidth : 32*4,
		width : 59,         // 图片大小
	},
	{
		img : "0015",
		adjustWidth : 18*4,
		width : 38,         // 图片大小
	},
	{
		img : "0016",
		adjustWidth : 26*4,
		width : 50,         // 图片大小
	},
	{
		img : "0017",
		adjustWidth : 13*4,
		width : 27,         // 图片大小
	},
	{
		img : "0018",
		adjustWidth : 16*4,
		width : 31,         // 图片大小
	},
	{
		img : "0019",
		adjustWidth : 17*4,
		width : 35,         // 图片大小
	},
	{
		img : "0020",
		adjustWidth : 15*4,
		width : 36,         // 图片大小
	},
		{
		img : "0021",
		adjustWidth : 9*4,
		width : 22,         // 图片大小
	},
		{
		img : "0022",
		adjustWidth : 16*4,
		width : 33,         // 图片大小
	},
		{
		img : "0023",
		adjustWidth : 10*4,
		width : 25,         // 图片大小
	},
		{
		img : "0024",
		adjustWidth : 22*4,
		width : 49,         // 图片大小
	},
		{
		img : "0025",
		adjustWidth : 31*4,
		width : 54,         // 图片大小
	},
		{
		img : "0026",
		adjustWidth : 21*4,
		width : 42,         // 图片大小
	},
		{
		img : "0027",
		adjustWidth : 14*4,
		width : 36,         // 图片大小
	},
	// 以下是火焰山怪物----------
		{
		img : "0028",
		adjustWidth : 25*4,
		width : 72,         // 图片大小
	},
		{
		img : "0029",
		adjustWidth : 25*4,
		width : 72,         // 图片大小
	},
		{
		img : "0030",
		adjustWidth : 25*4,
		width : 72,         // 图片大小
	},
		{
		img : "0030",
		adjustWidth : 25*4,
		width : 72,         // 图片大小
	},
	{
		img : "0031",
		adjustWidth : 25*4,
		width : 72,         // 图片大小
	},
	{
		img : "0032",
		adjustWidth : 25*4,
		width : 72,         // 图片大小
	},
	{
		img : "0033",
		adjustWidth : 25*4,
		width : 72,         // 图片大小
	},
	{
		img : "0034",
		adjustWidth : 25*4,
		width : 72,         // 图片大小
	},
	{
		img : "0035",
		adjustWidth : 25*4,
		width : 72,         // 图片大小
	},
	{
		img : "0036",
		adjustWidth : 25*4,
		width : 72,         // 图片大小
	},
	{
		img : "0037",
		adjustWidth : 25*4,
		width : 72,         // 图片大小
	},
	{
		img : "0038",
		adjustWidth : 25*4,
		width : 72,         // 图片大小
	},
	{
		img : "0039",
		adjustWidth : 25*4,
		width : 72,         // 图片大小
	},
	{
		img : "0040",
		adjustWidth : 25*4,
		width : 72,         // 图片大小
	},
	{
		img : "0041",
		adjustWidth : 25*4,
		width : 72,         // 图片大小
	},
	{
		img : "0042",
		adjustWidth : 25*4,
		width : 72,         // 图片大小
	},
	{
		img : "0043",
		adjustWidth : 25*4,
		width : 72,         // 图片大小
	},
	{
		img : "0044",
		adjustWidth : 25*4,
		width : 72,         // 图片大小
	},
	{
		img : "0045",
		adjustWidth : 25*4,
		width : 72,         // 图片大小
	},
	{
		img : "0046",
		adjustWidth : 25*4,
		width : 72,         // 图片大小
	},
	{
		img : "0047",
		adjustWidth : 25*4,
		width : 72,         // 图片大小
	},
	{
		img : "0048",
		adjustWidth : 25*4,
		width : 72,         // 图片大小
	},
	{
		img : "0049",
		adjustWidth : 25*4,
		width : 72,         // 图片大小
	},
	{
		img : "0050",
		adjustWidth : 25*4,
		width : 72,         // 图片大小
	},
	{
		img : "0051",
		adjustWidth : 25*4,
		width : 72,         // 图片大小
	},
	{
		img : "0052",
		adjustWidth : 25*4,
		width : 72,         // 图片大小
	},
	{
		img : "0053",
		adjustWidth : 25*4,
		width : 72,         // 图片大小
	},
	{
		img : "0054",
		adjustWidth : 25*4,
		width : 72,         // 图片大小
	},
	{
		img : "0055",
		adjustWidth : 25*4,
		width : 72,         // 图片大小
	},
	{
		img : "0056",
		adjustWidth : 25*4,
		width : 72,         // 图片大小
	},
	{
		img : "0057",
		adjustWidth : 25*4,
		width : 72,         // 图片大小
	},
	{
		img : "0058",
		adjustWidth : 25*4,
		width : 72,         // 图片大小
	},
	{
		img : "0059",
		adjustWidth : 25*4,
		width : 72,         // 图片大小
	},
	{
		img : "0060",
		adjustWidth : 25*4,
		width : 72,         // 图片大小
	},
	{
		img : "0061",
		adjustWidth : 25*4,
		width : 72,         // 图片大小
	},
	{
		img : "0062",
		adjustWidth : 25*4,
		width : 72,         // 图片大小
	},
	{
		img : "0063",
		adjustWidth : 25*4,
		width : 72,         // 图片大小
	},
	{
		img : "0064",
		adjustWidth : 25*4,
		width : 72,         // 图片大小
	},
	{
		img : "0065",
		adjustWidth : 25*4,
		width : 72,         // 图片大小
	},
	{
		img : "0066",
		adjustWidth : 25*4,
		width : 72,         // 图片大小
	},
	{
		img : "0067",
		adjustWidth : 25*4,
		width : 72,         // 图片大小
	},
	{
		img : "0068",
		adjustWidth : 25*4,
		width : 72,         // 图片大小
	},
]

