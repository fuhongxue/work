

var MaskLayer = cc.LayerColor.extend({
	isMask : true,
	ctor : function(){
		this._super(cc.color(255, 255, 0, 0));

		var listener = cc.EventListener.create({
		    event           : cc.EventListener.TOUCH_ONE_BY_ONE,
		    target          : this,
		    swallowTouches  : true,
		    onTouchBegan    : this.onTouchBegan,
		});
		cc.eventManager.addListener(listener, this);

		cc.director.getRunningScene().addChild(this,1000);
	},
	onTouchBegan: function (touch, event) {
		var target = this.target;

		if (!target.isMask) {
			return false;
		};

		return true;
	},
	setMask : function(i){
		this.isMask = i;
	}

});