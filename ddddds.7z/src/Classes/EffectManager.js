
/**
 * Created by wangzhigang on 15/9/11.
 */

 var EffectManager = (function(){
 	function _EffectManager(){
 		this.init = function(){
 			this.AwardEffArr = [];
 			this.bloodPotArr = [];
 			if (this.fontNode) {
 				this.fontNode.removeFromParent();
 			};
 			this.fontNode = new cc.Node();

 		};
 		this.update = function(dt,isEffectMove){
 			var heroObj = GameManager.getInstance().getHeroObj();
 			var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;

 			var arr = this.AwardEffArr;

 		// 	var heroRect = heroObj.getAwardCollisionRect();
			// for (var i = arr.length - 1; i >= 0; i--) {
			// 	var node = arr[i]

			// 	if ( !node.isfei && !node.isIdle) {
		 // 			var nodePos = node.getParent().convertToWorldSpace(node.getPosition())

			// 		var nodeRect = cc.rect(
			// 		    nodePos.x ,
			// 		    nodePos.y ,
			// 		    node.getBoundingBox().width,
			// 		    node.getBoundingBox().height
			// 		);

		 // 			if(cc.rectIntersectsRect(heroRect,nodeRect)){
		 // 				EffectManager.getInstance().playEatAwardEffect(node);
		 // 				EffectManager.getInstance().playGetAwardEffect(node);
		 // 				break;
			// 		};
			// 	};
			// };

 			// if (isEffectMove) {
 				var width  = heroObj.getPositionX() + 5;

 				var arr = this.AwardEffArr
	 			for (var i = arr.length - 1; i >= 0; i--) {
	 				var node = arr[i]

	 				if (!node.isfei && !node.isIdle) {
	 					if (node.isFinishAnimation) {
	 						var pos1 = node.x
	 						node.x = node.x - heroObj.getSpeed() *dt*dir;
	 						var pos2 = node.x

	 						if ((pos1 <= width && pos2 >= width ) || (pos1 >= width && pos2 <= width)) {
	 							EffectManager.getInstance().playEatAwardEffect(node);
	 							EffectManager.getInstance().playGetAwardEffect(node);
	 						};
	 					}else{
	 						// node.x = node.x - heroObj.getSpeed() *dt*dir*0.05;
	 					}
	 				};

	 			};


	 			var arr = this.bloodPotArr;
	 			for (var i = 0; i < arr.length; i++) {
	 				var node = arr[i];
	 				if (node.isFinishAnimation  && !node.isIdle) {
	 					var pos1 = node.x
	 					node.x = node.x - heroObj.getSpeed() *dt*dir;
	 					var pos2 = node.x

	 					if ( (pos1 < width && pos2 >= width) || (pos1 > width && pos2 <= width ) ) {
	 						node.isIdle = true;
	 						node.setVisible(false);
	 						heroObj.addHp(GC.BLOOD_POT[node.index][0]*GameManager.getInstance().getCharacterData().hpMax);
	 					};
	 				}else{
	 					// node.x = node.x - heroObj.getSpeed() *dt*dir*0.05;
	 				}

	 			};

	 			// cc.log("barr num : " + arr.length)
				this.fontNode.x = this.fontNode.x - heroObj.getSpeed()*dt*dir*0.3;
 			// };

 		};
 		this.playCommonAttFontEffect = function(value,monster){
 			var heroObj = GameManager.getInstance().getHeroObj();
 			var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;

 			var node = Common.createFontNode(value,1);
 			node.setScale(GC.SCALE_RATE*0.01)

 			var action5 = cc.scaleTo(0.1,GC.SCALE_RATE*0.8);
 			var action1 = cc.moveBy(0.1,cc.p(0,5));

 			var action2 = cc.fadeOut(2);
 			var action3 = cc.moveBy(2,cc.p(0,100));

 			var callBack = cc.callFunc(function(){
 				this.removeAllChildrenWithCleanup(true)
 				this.removeFromParent(true);
 			}.bind(node));

 			node.setCascadeOpacityEnabled(true);

 			node.runAction(cc.sequence(cc.sequence(action1,action5),cc.spawn(action2,action3) ,callBack));

 			var pos = this.fontNode.convertToNodeSpace(cc.p(monster.getPositionX() + monster.getBoundingBox().width/2,monster.getPositionY()+ monster.getBoundingBox().height/2 ));
 			// pos.x = pos.x + 20*GC.SCALE_RATE*dir;
 			node.setPosition(cc.p(pos.x,pos.y));

 			this.fontNode.addChild(node);
 			if (!this.fontNode.getParent()) {
 				GameManager.getInstance().GPMainLayer.addChild(this.fontNode, 5);
 			};
 		};
 		this.playHitMonsterEffect = function(){
 			var heroObj = GameManager.getInstance().getHeroObj();
 			var weapon = heroObj.getWeapon();
 			var node = Common.createAnimateNode(8,"efhita");

 			posX = (heroObj.getContentSize().width+weapon.getContentSize().width)

 			heroObj.addChild(node);
 			node.setPosition(cc.p(posX,15));
 		};
 		this.playMonsterDeathEffect = function(){
 			var heroObj = GameManager.getInstance().getHeroObj();
 			var weapon = heroObj.getWeapon();

 			var heroObj = GameManager.getInstance().getHeroObj();
 			var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;


 			var node = Common.createAnimateNode(8,"efdeidboom");

 			var pos = GameManager.getInstance().GPMainLayer.convertToNodeSpace(cc.p(heroObj.getPositionX(),heroObj.getPositionY()+ heroObj.getBoundingBox().height/2 ));
 			pos.x = pos.x + 70*GC.SCALE_RATE*dir

 			node.setPosition(cc.p(pos.x,pos.y));
 			node.setScale(GC.SCALE_RATE)

 			node.x = node.x - GameManager.getInstance().effectParallax.getPositionX();

 			var pnode = new cc.Node();
 			pnode.addChild(node);
 			GameManager.getInstance().effectParallax.addChild(pnode, 5, cc.p(1, 0), cc.p(0,0));
 		};
 		//===================== Award =======================
 		this.recycleAwardToTemple  = function(){
 			var arr = this.AwardEffArr;

 			for (var i = arr.length - 1; i >= 0; i--) {
 				var node = arr[i]

 				if (!node.isfei) {
 					if (node.isFinishAnimation) {

 						EffectManager.getInstance().playGetAwardEffect(node);
 					}
 				};

 			};

 			for (var i = 0; i < this.bloodPotArr.length; i++) {
 				var node = this.bloodPotArr[i];

 				node.isIdle = true;
 				node.setVisible(false);
 			};
 		};
 		this.playEatAwardEffect = function(awardNode){
 			var heroObj = GameManager.getInstance().getHeroObj();

 			var node = Common.createAnimateNode(6,"eat_moneyb");
 			node.setAnchorPoint(0.5, 0)
 			GameManager.getInstance().GPMainLayer.addChild(node, 5);

 			// node.setPosition(cc.p(heroObj.x,heroObj.y));
 			node.setPosition(awardNode.getPosition());
 			node.setScale(GC.SCALE_RATE);
 		};
 		this.calculateAwardNum = function(goldNum){

 			var monsterInfo = GameManager.getInstance().getMonsterInfo();
 			var baseNum = monsterInfo[0][2];

 			var jinNum = Math.floor(goldNum/(6*baseNum));
 			var yinNum = Math.floor( (goldNum - jinNum*(6*baseNum))/(3*baseNum) );
 			var tongNum = Math.floor( (goldNum - yinNum*(3*baseNum) - jinNum*(6*baseNum))/(baseNum) );
 			var lastNum = goldNum - tongNum*baseNum - yinNum*(3*baseNum) - jinNum*(6*baseNum);


 			if (lastNum != 0) {
 				tongNum += 1;
 			};

 			return [jinNum,yinNum,tongNum,[baseNum,lastNum]];
 		},
 		this.loadAwardAction = function(node,monster){
 			var heroObj = GameManager.getInstance().getHeroObj();
 			var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;

			var a1_time = GC.CREATE_AWARD_EFFECT.A1_TIME();
			var a1_x    = GC.CREATE_AWARD_EFFECT.A1_X();
			var a1_h    = GC.CREATE_AWARD_EFFECT.A1_H();
			var a1_num  = GC.CREATE_AWARD_EFFECT.A1_NUM();
			var a2_time = GC.CREATE_AWARD_EFFECT.A2_TIME();
			var a2_x    = GC.CREATE_AWARD_EFFECT.A2_X();
			var a2_h    = GC.CREATE_AWARD_EFFECT.A2_H();
			var a2_num  = GC.CREATE_AWARD_EFFECT.A2_NUM();


			var action1 = cc.jumpBy(a1_time, cc.p( a1_x*dir, -(monster.getBoundingBox().height/2) ), a1_h, a1_num); 
			var action2 = cc.jumpBy(a2_time, cc.p( a2_x*dir, 0 ), a2_h, a2_num); 

			var callBack = cc.callFunc(function(){
				this.isFinishAnimation = true;
			}.bind(node));
			node.isFinishAnimation = false;
			var action = cc.sequence(action1,action2,callBack)
			// action.tag = 10000;

			node.runAction(action);
 		},
 		this.getIdleAward = function(type){
 			var arr = this.AwardEffArr;
 			for (var i = arr.length - 1; i >= 0; i--) {
 				var node = arr[i]

 				if (node.isIdle && node.type == type) {
 					node.isIdle = false;
 					node.setVisible(true);
 					return node;
 				};
 			};

 			var resName = "";
 			if (type == "jin") {
 				resName = "ui_coin_gold";
 			}else if(type == "yin"){	
 				resName = "ui_coin_silver";
 			}else if (type == "tong") {
 				resName = "ui_coin_copper";
 			};
 			var node = Common.createAnimateNode(12,resName,true)
 			node.type = type;
 			node.isIdle = false;
 			GameManager.getInstance().GPMainLayer.addChild(node, 5);
 			this.AwardEffArr.push(node);

 			return node;
 		},
 		this.getAwardGoldValue = function(type,baseArr,i,Num){
 			var baseValue = baseArr[0];
 			var lastNum = baseArr[1];

 			var value = 0;
 			if (type == "jin") {
 				value = baseValue * 6;
 			}else if(type == "yin"){	
 				value = baseValue * 3;
 			}else if (type == "tong") {
 				value = baseValue ;

 				if (i == Num -1 && lastNum != 0) {
 					value = lastNum;
 				};
 			};

 			return value;
 		},
 		this.loadAwardNode = function(type,Num,baseArr,pos,callBack){
 			for (var i = 0; i < Num; i++) {
 				var node = this.getIdleAward(type);

 				node.goldValue = this.getAwardGoldValue(type,baseArr,i,Num);
 				node.anchorY = 0;
 				node.setPosition(cc.p(pos.x,pos.y));
 				node.setScale(GC.SCALE_RATE);


 				callBack(node);
 			};
 		},
 		// 怪物死亡，金币飞溅特效
 		this.playCreateAwardEffect = function(goldNum,monster){

 			var numArr = this.calculateAwardNum(goldNum);
 			var self = this;
 			var pos = GameManager.getInstance().GPMainLayer.convertToNodeSpace(cc.p(monster.getPositionX() + monster.getBoundingBox().width/2,monster.getPositionY()+ monster.getBoundingBox().height/2 ));

 			function callBack(node){
 				self.loadAwardAction(node,monster);
 			}

 			this.loadAwardNode("jin",numArr[0],numArr[3],pos,callBack);
 			this.loadAwardNode("yin",numArr[1],numArr[3],pos,callBack);
 			this.loadAwardNode("tong",numArr[2],numArr[3],pos,callBack);
 		};
 		// 碰撞得到金币特效
 		this.playGetAwardEffect = function(node){
 			node.isFinishAnimation = false;
 			node.isfei = true

 			var pos = GameManager.getInstance().GPMainLayer.convertToWorldSpace(cc.p(GC.w2,GC.h-70));


 			var action1 = cc.jumpTo(0.5, pos, -100, 1); 
 			var callBack = cc.callFunc(function(){
 				this.setVisible(false);
 				this.isIdle = true;
 				node.isfei = false

 				GameManager.getInstance().setGold(GameManager.getInstance().getGold() + node.goldValue);
 				GameManager.getInstance().saveLocalData();
 				GameManager.getInstance().GPMainLayer.resetFontGold();


 			}.bind(node));
 			node.isIdle = false;
 			node.runAction(cc.sequence(action1,callBack));
 		};
 		this.loadDeathGoldAction = function(node,monster){
 			var heroObj = GameManager.getInstance().getHeroObj();
 			var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;

			var a1_time = GC.CREATE_AWARD_EFFECT.A1_TIME();
			var a1_x    = GC.CREATE_AWARD_EFFECT.A1_X();
			var a1_h    = GC.CREATE_AWARD_EFFECT.A1_H();
			var a1_num  = GC.CREATE_AWARD_EFFECT.A1_NUM();
			var a2_time = GC.CREATE_AWARD_EFFECT.A2_TIME();
			var a2_x    = GC.CREATE_AWARD_EFFECT.A2_X();
			var a2_h    = GC.CREATE_AWARD_EFFECT.A2_H();
			var a2_num  = GC.CREATE_AWARD_EFFECT.A2_NUM();


			if (Math.ceil(Math.random()*2) == 1) {
				dir = 1;
			}else{
				dir = -1;
			}

			var action1 = cc.jumpBy(a1_time, cc.p( a1_x*dir, -(monster.getBoundingBox().height/2) ), a1_h, a1_num); 
			var action2 = cc.jumpBy(a2_time, cc.p( a2_x*dir, 0 ), a2_h, a2_num); 
			var action3 = cc.fadeOut(a2_time);

			var callBack = cc.callFunc(function(){
				this.setVisible(false);
				this.setOpacity(255)
				this.isIdle = true
			}.bind(node));

			node.runAction(cc.sequence(action1, cc.spawn(action2,action3),callBack ));
 		}
 		// 死亡丢失金币特效
 		this.playLostAwardEffect = function(goldNum){
 			var heroObj = GameManager.getInstance().getHeroObj();

 			var numArr = this.calculateAwardNum(goldNum);

 			var self = this;
 			var pos = GameManager.getInstance().GPMainLayer.convertToNodeSpace(cc.p(heroObj.getPositionX(),heroObj.getPositionY() + heroObj.getBoundingBox().height/2 ));
 			function callBack(node){
 				self.loadDeathGoldAction(node,heroObj);
 			}

 			this.loadAwardNode("jin",numArr[0],numArr[3],pos,callBack);
 			this.loadAwardNode("yin",numArr[1],numArr[3],pos,callBack);
 			this.loadAwardNode("tong",numArr[2],numArr[3],pos,callBack);
 		};
 		//===================== Award =======================
 		// 刹车特效
 		this.playBrakeEffect = function(){
 			var heroObj = GameManager.getInstance().getHeroObj();

 			var node = Common.createAnimateNode(8,"ef_brake_smoke");
 			node.anchorY = 0;
 			node.anchorX = 1/5;
 			node.x = 23;

 			node.setScale(heroObj.getSpeedRate());
 			heroObj.addChild(node);
 		};
 		// 英雄升级动画
 		this.playLevelUpEffect = function(){
 			var heroObj = GameManager.getInstance().getHeroObj();

 			var node = Common.createAnimateNode(15,"ef_levelup_");
 			heroObj.addChild(node);
 			node.setAnchorPoint(0.5,0);
 			node.setPosition(20,-5)
 		};
 		this.getIdleBloodPot = function(index){
 			for (var i = 0; i < this.bloodPotArr.length; i++) {
 				var node = this.bloodPotArr[i];

 				if (node.isIdle && node.index == index) {
 					node.isIdle = false;
 					node.setVisible(true);
 					return node;
 				};
 			};

 			var resName = ""
 			if (index == 0) {
 				resName = "Potion_small";
 			}else if(index == 1){
 				resName = "Potion_big";
 			} 


 			var node = new cc.Sprite(res[resName]);
 			node.isIdle = false;
 			node.index = index;
 			GameManager.getInstance().GPMainLayer.addChild(node, 5);

 			this.bloodPotArr.push(node);

 			return node;
 		};
 		this.loadBloodPotAction = function(node,monster){
 			var heroObj = GameManager.getInstance().getHeroObj();
 			var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;

			var a1_time = GC.CREATE_BLOODPOT_EFFECT.A1_TIME();
			var a1_x    = GC.CREATE_BLOODPOT_EFFECT.A1_X();
			var a1_h    = GC.CREATE_BLOODPOT_EFFECT.A1_H();
			var a1_num  = GC.CREATE_BLOODPOT_EFFECT.A1_NUM();
			var a2_time = GC.CREATE_BLOODPOT_EFFECT.A2_TIME();
			var a2_x    = GC.CREATE_BLOODPOT_EFFECT.A2_X();
			var a2_h    = GC.CREATE_BLOODPOT_EFFECT.A2_H();
			var a2_num  = GC.CREATE_BLOODPOT_EFFECT.A2_NUM();


			var action1 = cc.jumpBy(a1_time, cc.p( a1_x*dir, -(monster.getBoundingBox().height/2) ), a1_h, a1_num); 
			var action2 = cc.jumpBy(a2_time, cc.p( a2_x*dir, 0 ), a2_h, a2_num); 

			var callBack = cc.callFunc(function(){
				this.isFinishAnimation = true;
			}.bind(node));
			node.isFinishAnimation = false;
			var action = cc.sequence(action1,action2,callBack)
			// action.tag = 10000;

			node.runAction(action);
 		}
 		// 血瓶动画
 		this.playBloodPotEffect = function(index,monster){
 			var node = this.getIdleBloodPot(index);
 			var pos = GameManager.getInstance().GPMainLayer.convertToNodeSpace(cc.p(monster.getPositionX() + monster.getBoundingBox().width/2,monster.getPositionY()+ monster.getBoundingBox().height/2 ));
 			node.setPosition(pos);
 			node.anchorY = 0;
 			node.setScale(GC.SCALE_RATE/2);

 			this.loadBloodPotAction(node,monster);
 		};
 	}

 	var instance;

 	var _static = {
 		name : "EffctManager",

 		getInstance: function(){
 			if (instance === undefined) {
 			    instance = new _EffectManager();
 			}
 			return instance;
 		}
 	};
 	return _static;
 })();