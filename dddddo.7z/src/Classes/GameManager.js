/**
 * Created by wangzhigang on 15/4/19.
 */

// 游戏管理对象，单例类
var GameManager = (function () {

    function _GameManager() {
	
        // 英雄对象
        this.heroObj = null;
        this.parallaxLayer = null;
        this.characterVector = [];


        // this.Tree2 = null;
        //二维数组 第一维表示第几波 第二维表示具体对象
        this.monsterVector = [];  
        //阶段间怪物的距离
        this.monsterDisVector = [];

        //配置信息
        this.monsterGroupInfo = [];
        this.monsterInfo = [];
        this.characterInfo = [];

        //角色对象信息 
        this.characterData = {
            // hp : 0,
            hpMax : 0,
            attack : 0,
            // needGold : 0,
        };

        // 游戏本地数据存储字段
        this.localData = {
            // 角色等级，依次分别为 悟空，唐僧，八戒，沙僧
            characterLevel : [0,0,0,0],
            // 游戏金币
            gold : 0,
            // 当前停留在哪一个关卡
            curLevel : 1, 
            // 已解锁到哪一个关卡     
            unlockLevel : 1,   

            //角色伙伴解锁状态： 0: 未解锁 1：已解锁，未上阵 2：已上阵
            partnerUnlockStatus : {
                "bajie"     : 0,
                "tangseng"  : 0,
                "shaseng"   : 0,
            },   
        };

        this.clear = function(){
            this.monsterVector = [];
            this.characterVector = [];
        };

        //========[localstorage]===========
        this.saveLocalData = function(){
            var localData = JSON.stringify(this.localData);  
            cc.sys.localStorage.setItem("localData", localData);  
        };
        this.loadLocalStorage = function(){
            var localData = cc.sys.localStorage.getItem("localData");  

            if (localData == null || localData == "") {
                this.saveLocalData();
                this.localData = JSON.parse(cc.sys.localStorage.getItem("localData"));
            }else{
                this.localData = JSON.parse(localData);
            }
        };
        this.getCharacterLevel = function(id){
            return this.localData.characterLevel[id];
        },
        this.setCharacterLevel = function(id,value){
            this.localData.characterLevel[id] = value;
        },
        this.resetRoleData = function(){
            this.characterData.hpMax = 0;
            this.characterData.attack = 0;

            for (var i = 0; i < this.characterInfo.length; i++) {
                var info = this.characterInfo[i];
                var level = this.localData.characterLevel[i];
                var config = info.config;
                var field = info.field;

                if(i > 0 && this.localData.partnerUnlockStatus[info.cName] != 2){
                    continue;
                }

                if (info.baseHp) {
                    this.characterData.hpMax = this.characterData.hpMax + info.baseHp;
                };

                for (var j = 0; j <  field.length; j++) {
                    if(field[j] == "hp"){
                        this.characterData.hpMax     = this.characterData.hpMax + config[level][j];
                    }else if(field[j] == "attack"){
                        this.characterData.attack = this.characterData.attack +  config[level][j];
                    }
                };

            };
        },
        this.getCurLevel = function(){
            return this.localData.curLevel;
        },
        this.setCurLevel = function(v){
            this.localData.curLevel = v;
        },
        this.getUnlockLevel = function(){
            return this.localData.unlockLevel;
        },
        this.setUnlockLevel = function(v){
            this.localData.unlockLevel = v;
        },
        this.getUnlockPartnerNum = function(){
            var num = 0;
            var partnerUnlockStatus = this.localData.partnerUnlockStatus;

             for(var p in partnerUnlockStatus){ 
                if (partnerUnlockStatus[p] >= 1 ) {
                    num += 1;
                };
             }

             return num;
        },
        this.isPartnerUnlocked = function(v){
            return this.localData.partnerUnlockStatus[v] == 2 ? true : false;
        },
        this.unlockPartner = function(){
            var curLevel = this.localData.curLevel;
            for (var i = 0; i < this.characterInfo.length; i++) {
                var info = this.characterInfo[i];
                if (info.unlockLevel && info.unlockLevel == curLevel) {
                    this.localData.partnerUnlockStatus[info.cName] = 1;
                };
            }
        },
        //========[localstorage]===========

        // ==============[getter && setter]==============
        this.setHeroObj = function(heroObj) {
           this.heroObj = heroObj;
        };
        this.getHeroObj = function() {
             return this.heroObj;
        };
        this.setParallaxLayer = function(obj) {
            this.parallaxLayer = obj;
        };
        this.getParallaxLayer = function() {
            return this.parallaxLayer;
        };
        this.getMonsterVector = function() {
            return this.monsterVector;
        };
        this.getMonsterGroupVector = function() {
            return this.monsterGroupInfo;
        };
        this.setMonsterDisVector = function(obj) {
            this.monsterDisVector = obj;
        };
        this.getMonsterDisVector = function() {
            return this.monsterDisVector;
        };
        this.getCharacterInfo = function() {
            return this.characterInfo;
        };
        this.getMonsterInfo = function() {
            return this.monsterInfo;
        };
        this.getCharacterData = function(){
            return this.characterData;
        };
        this.getCharacterVector = function() {
            return this.characterVector;
        };
        this.getGold = function(){
            return this.localData.gold;
        };
        this.setGold = function(value){
            this.localData.gold = value;
        };
        this.getCharacterNeedGold = function(id){
            var level = this.localData.characterLevel[id];
            var config = this.characterInfo[id]["config"];
            return config[level + 1] ? config[level + 1][1] : 0;
        };
        this.getCharacterAddAttr = function(id){
            var level = this.localData.characterLevel[id];
            var info = this.characterInfo[id];
            var config = info.config;

            return config[level+1] ? (config[level+1][0] - config[level][0]) : 0;
        },
        this.getCharacterLv = function(id){
            return this.localData.characterLevel[id];
        },
        this.getBgPath = function(){
            var mapInfo = GameManager.getInstance().mapInfo
            var prefix = mapInfo[0] + "_" + mapInfo[1];
            return prefix;
        };

	}

	//实例容器
    var instance;

    var _static = {
        name: 'GameManager',
        //获取实例的方法
        //返回Singleton的实例
        getInstance: function () {
            if (instance === undefined) {
                instance = new _GameManager();
            }
            return instance;
        }
    };
    return _static;
})();