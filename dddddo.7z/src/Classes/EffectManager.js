
/**
 * Created by wangzhigang on 15/9/11.
 */

 var EffectManager = (function(){
 	function _EffectManager(){
 		this.playCommonAttFontEffect = function(value,pos){
 			var heroObj = GameManager.getInstance().getHeroObj();
 			var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;

 			var node = Common.createFontNode(value,1);

 			var action1 = cc.moveBy(0.5,cc.p(0,50));
 			var action2 = cc.fadeOut(0.5);
 			var action3 = cc.moveBy(1,cc.p(0,80));
 			var callBack = cc.callFunc(function(){
 				this.removeAllChildrenWithCleanup(true)
 				this. removeFromParent(true);
 			}.bind(node));

 			node.setCascadeOpacityEnabled(true);


 			node.runAction(cc.sequence(action1,cc.spawn(action2,action3) ,callBack));


 			var pos = GameManager.getInstance().GPMainLayer.convertToNodeSpace(cc.p(heroObj.getPositionX() + heroObj.getBoundingBox().width/2,heroObj.getPositionY()+ heroObj.getBoundingBox().height/2 ));
 			// pos.x = pos.x + 100*GC.SCALE_RATE*dir

 			node.setPosition(cc.p(pos.x,pos.y));
 			node.setScale(GC.SCALE_RATE)

 			node.x = node.x - GameManager.getInstance().effectParallax.getPositionX();

 			var pnode = new cc.Node();
 			pnode.addChild(node);
 			GameManager.getInstance().effectParallax.addChild(pnode, 5, cc.p(1, 0), cc.p(0,0));

 		};
 		this.playHitMonsterEffect = function(){
 			var heroObj = GameManager.getInstance().getHeroObj();
 			var weapon = heroObj.getWeapon();

 			var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;

 			var node = Common.createAnimateNode(8,"efhita0");
 			var posX = 0;
 			if(heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ){
 				posX = (heroObj.getContentSize().width+weapon.getContentSize().width)*dir
 			}else{
 				posX = (weapon.getContentSize().width)*dir
 			}

 			heroObj.addChild(node);
 			node.setPosition(cc.p(posX,15));
 		};
 		this.playMonsterDeathEffect = function(){
 			var heroObj = GameManager.getInstance().getHeroObj();
 			var weapon = heroObj.getWeapon();

 			var heroObj = GameManager.getInstance().getHeroObj();
 			var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;


 			var node = Common.createAnimateNode(8,"efdeidboom0");

 			var pos = GameManager.getInstance().GPMainLayer.convertToNodeSpace(cc.p(heroObj.getPositionX() + heroObj.getBoundingBox().width/2,heroObj.getPositionY()+ heroObj.getBoundingBox().height/2 ));
 			pos.x = pos.x + 100*GC.SCALE_RATE*dir

 			node.setPosition(cc.p(pos.x,pos.y));
 			node.setScale(GC.SCALE_RATE)

 			node.x = node.x - GameManager.getInstance().effectParallax.getPositionX();

 			var pnode = new cc.Node();
 			pnode.addChild(node);
 			GameManager.getInstance().effectParallax.addChild(pnode, 5, cc.p(1, 0), cc.p(0,0));
 		};
 		this.playEatMoneyEffect = function(){
 			var heroObj = GameManager.getInstance().getHeroObj();
 			var weapon = heroObj.getWeapon();

 			var heroObj = GameManager.getInstance().getHeroObj();
 			var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;


 			var node = Common.createAnimateNode(6,"eat_moneyb0");
 			var posX = 0;
 			if(heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ){
 				posX = (heroObj.getContentSize().width+weapon.getContentSize().width + 20)*dir
 			}else{
 				posX = (weapon.getContentSize().width + 20)*dir
 			}

 			heroObj.addChild(node);
 			node.setPosition(cc.p(posX,15));

 		};
 	}

 	var instance;

 	var _static = {
 		name : "EffctManager",

 		getInstance: function(){
 			if (instance === undefined) {
 			    instance = new _EffectManager();
 			}
 			return instance;
 		}
 	};
 	return _static;
 })();