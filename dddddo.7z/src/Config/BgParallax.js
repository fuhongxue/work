/**
 * Created by wangzhigang on 15/9/17.
 */


 var BgParallax = {
 	type1 : {
 		foreword : [
	 		{
	 			name : "cr1",
	 			ratio : 0.8,
	 			loop : "sigle",
	 			posVector : [2500,2800,4000],
	 		},
	 		{
	 			name : "cr2",
	 			ratio : 1.0,
	 			loop : "sigle",
	 			posVector : [2000,2500,3000,4000],
	 		},
 		],
 		backward : [

	 		{
	 			name : "sky1",
	 			ratio : 0.6,
	 			loop : "multiple",
	 			amount :  4,
	 			height  : 320,
	 		},
	 		{
	 			name : "sky2",
	 			ratio : 0.8,
	 			loop : "multiple",
	 			amount :  5,
	 			height  : 380,
	 		},
	 		{
	 			name : "sky3",
	 			ratio : 1.0,
	 			loop : "multiple",
	 			amount :  6,
	 			height  : 460,
	 		},
 			{
	 			name : "ground3",
	 			ratio : 0.6,
	 			loop : "multiple",
	 			amount :  6,
	 			height  : 260,
	 			tree : [
	 				{
	 					name  : "tree4",
	 					pNode : 0,
	 					x : 10,
	 					y : 5,
	 					scaleRate : 0.25,
	 				},
	 				{
	 					name  : "reed2",
	 					pNode : 0,
	 					x : 30,
	 					y : 5,
	 					scaleRate : 1,
	 				},
	 				{
	 					name  : "tree4",
	 					pNode : 1,
	 					x : 10,
	 					y : 15,
	 					scaleRate : 0.25,
	 				},
	 				{
	 					name  : "tree4",
	 					pNode : 2,
	 					x : 10,
	 					y : 10,
	 					scaleRate : 0.25,
	 				},
	 				{
	 					name  : "tree4",
	 					pNode : 3,
	 					x : 10,
	 					y : 10,
	 					scaleRate : 0.25,
	 				},
	 			]
 			},
 			{
	 			name : "ground2",
	 			ratio : 0.8,
	 			loop : "multiple",
	 			amount :  5,
	 			height  : 220,
	 			tree : [
	 				{
	 					name  : "tree3",
	 					pNode : 0,
	 					x : 10,
	 					y : 5,
	 					scaleRate : 0.5,
	 				},
	 				{
	 					name  : "reed2",
	 					pNode : 0,
	 					x : 30,
	 					y : 5,
	 					scaleRate : 1,
	 				},
	 				{
	 					name  : "tree3",
	 					pNode : 1,
	 					x : 10,
	 					y : 15,
	 					scaleRate : 0.5,
	 				},
	 				{
	 					name  : "tree3",
	 					pNode : 2,
	 					x : 10,
	 					y : 10,
	 					scaleRate : 0.5,
	 				},
	 				{
	 					name  : "tree3",
	 					pNode : 3,
	 					x : 10,
	 					y : 10,
	 					scaleRate : 0.5,
	 				},
	 			]
 			},
	 		{
	 			name : "ground1",
	 			ratio : 1.0,
	 			loop : "multiple",
	 			amount :  4,
	 			height  : 150,
	 			tree : [
	 				{
	 					name  : "tree2",
	 					pNode : 0,
	 					x : 10,
	 					y : 5,
	 					scaleRate : 1,
	 				},
	 				{
	 					name  : "reed2",
	 					pNode : 0,
	 					x : 30,
	 					y : 5,
	 					scaleRate : 1,
	 				},
	 				{
	 					name  : "tree2",
	 					pNode : 1,
	 					x : 10,
	 					y : 15,
	 					scaleRate : 1,
	 				},
	 				{
	 					name  : "tree2",
	 					pNode : 2,
	 					x : 10,
	 					y : 10,
	 					scaleRate : 1,
	 				},
	 				{
	 					name  : "tree2",
	 					pNode : 3,
	 					x : 10,
	 					y : 10,
	 					scaleRate : 1,
	 				},
	 			]
	 		},

	 		{
	 			name : "road1",
	 			ratio : 1.2,
	 			loop : "multiple",
	 			amount :  4,
	 			height  : 100,
	 		},

 		],

 		
 	}
 }