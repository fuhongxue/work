

GC.HERO_SPEED = 1000;     //英雄最大速度
GC.HERO_HP_RATE = 0.01    //回血百分比
GC.HERO_HP_TIME = 1       //每次回血间隔
GC.UPGRADE_HP_RATE = 0.8  //每次英雄升级回血百分比 0.5即50%=======