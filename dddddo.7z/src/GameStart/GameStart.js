/**
 * Created by wangzhigang on 15/9/16.
 */

 var GameStartLayer = cc.Layer.extend({
     backgroundLayer : null,
     mainLayar : null,
     ctor:function () {
         this._super();
         this.loadBackground();
         this.loadMainLayer();
         return true;
     },
     loadBackground : function(){
         this.backgroundLayer = new GSBackgroundLayer();
         this.addChild(this.backgroundLayer);
     },
     loadMainLayer : function(){
         this.mainLayar = new GSMainLayer();
         this.addChild(this.mainLayar);
     }
 });

 var GameStartScene = cc.Scene.extend({
     onEnter:function () {
         this._super();
         var layer = new GameStartLayer();
         this.addChild(layer);

         
     }
 });