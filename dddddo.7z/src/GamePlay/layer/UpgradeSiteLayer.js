
/**
 * Created by wangzhigang on 15/4/20.
 */

 var CustomTableViewCell = cc.TableViewCell.extend({
     draw:function (ctx) {
         this._super(ctx);
     }
 });

 var GPUpgradeSiteLayer = cc.Layer.extend({
 	background : null,
 	wukongItem : null,
 	partnerItem : null,
 	menu        : null,
 	tvWukong    : null,
 	tvPartner   : null,
 	isShow      : false,
 	ctor : function(){
 		this._super();
 		this.loadConfig();
 		this.loadBg();
 		this.loadGradientUI();
 		this.loadWukongItem();
 		this.loadPartnerItem();
 		this.loadWukongTableView();

 	},
 	loadConfig : function(){
 		var node = new cc.Node();
 		this.addChild(node)
 		node.setCascadeOpacityEnabled(true);

 		this.effUINode = node;
 	},
 	addBgListener : function(){
 		var listener = cc.EventListener.create({
 		    event           : cc.EventListener.TOUCH_ONE_BY_ONE,
 		    // target          : this.background,
 		    swallowTouches  : true,
 		    onTouchBegan    : this.onTouchBegan,
 		    // onTouchMoved    : this.onTouchMoved,
 		    // onTouchEnded    : this.onTouchEnded
 		});
 		cc.eventManager.addListener(listener, this.background);
 	},
 	loadBg : function(){
 		var node = new cc.Sprite(res.ui_zdbg_02);
 		node.setAnchorPoint(0.5,0.5);
 		this.effUINode.addChild(node);
 		node.setScale(1/GC.SCALE_RATE);

 		this.background = node;

 		var menu = new cc.Menu();
 		this.effUINode.addChild(menu,1);
 		menu.setPosition(0, 0);

 		this.menu = menu;
 		this.menu.x = -50

 		this.addBgListener();
 	},
 	loadGradientUI : function(){
 		var node = new cc.Sprite(res.ui_zd_01);
 		this.effUINode.addChild(node,1);

 		node.setPosition(cc.p(-68,0))
 		node.setScale(1/GC.SCALE_RATE);

 		var node = new cc.Sprite(res.ui_zd_02);
 		this.effUINode.addChild(node,1);

 		node.setPosition(cc.p(72,0))
 		node.setScale(1/GC.SCALE_RATE);
 	},
 	onTouchBegan: function (touch, event) {
 		var target = event.getCurrentTarget();

 		var locationInNode = target.convertToNodeSpace(touch.getLocation());
 		var s = target.getContentSize();
 		var rect = cc.rect(0, 0, s.width, s.height);
 		if (cc.rectContainsPoint(rect, locationInNode)) {
 		    return true;
 		}

		return false
	},
 	loadWukongItem : function(){
 		var nodeNormal    = new cc.Sprite(res.ui_btn_wk02);
 		var nodeSelected  = new cc.Sprite(res.ui_btn_wk01);
 		var nodeDisabled  = new cc.Sprite(res.ui_btn_wk02);

 		var node = new cc.MenuItemSprite(
 		    nodeNormal,
 		    nodeSelected,
 		    nodeDisabled,
 		    function(){
 		    	this.wukongItem.selected();
 		    	this.partnerItem.unselected();
 		    	this.tvPartner.getContainer().setVisible(false);
 		    	this.tvWukong.getContainer().setVisible(true);
 		    	this.tvPartner.setTouchEnabled(false);
 		    	this.tvWukong.setTouchEnabled(true);

 		    	this.tvWukong.reloadData();

 		    }.bind(this));
 		node.setPosition(this.background.getContentSize().width/2/4+8, this.background.getContentSize().height/2/4-20);
 		node.setScale(1/GC.SCALE_RATE)
 		node.selected()

 		this.menu.addChild(node)

 		this.wukongItem = node;
 	},
 	loadPartnerItem : function() {
 		var nodeNormal    = new cc.Sprite(res.ui_btn_hb02);
 		var nodeSelected  = new cc.Sprite(res.ui_btn_hb01);
 		var nodeDisabled  = new cc.Sprite(res.ui_btn_hb02);

 		var node = new cc.MenuItemSprite(
 		    nodeNormal,
 		    nodeSelected,
 		    nodeDisabled,
 		    function(){
 		    	this.partnerItem.selected();
 		    	this.wukongItem.unselected();

 		    	this.tvPartner.getContainer().setVisible(true);
 		    	this.tvWukong.getContainer().setVisible(false);
 		    	this.tvPartner.setTouchEnabled(true);
 		    	this.tvWukong.setTouchEnabled(false);

 		    	this.tvPartner.reloadData();

 		    }.bind(this));
 		node.setPosition(this.background.getContentSize().width/2/4+8, this.background.getContentSize().height/2/4-50);
 		node.setScale(1/GC.SCALE_RATE)
 		this.menu.addChild(node)
 		this.partnerItem = node;

 	},
 	loadWukongTableView : function(){
 		var node = new GPWukongTableView();
 		this.effUINode.addChild(node,3);
 		this.tvWukong = node;
 		node.setCascadeOpacityEnabled(true);

 		var node = new GPPartnerTableView();
 		this.effUINode.addChild(node,3);
 		this.tvPartner = node;
 		node.setCascadeOpacityEnabled(true);


 		this.tvPartner.getContainer().setVisible(false);
 		this.tvPartner.setTouchEnabled(false);

 		this.tvWukong.getContainer().setCascadeOpacityEnabled(true);
 		this.tvPartner.getContainer().setCascadeOpacityEnabled(true);

 		this.setVisible(false);
 		cc.eventManager.removeListeners(this.background);  
 	},
 	showEff : function(isIntersect){
 		var heroObj = GameManager.getInstance().getHeroObj();

 		if(!isIntersect){
 			if (this.isShow == true) {
 				this.isShow = (false);

 				var action2 = cc.fadeOut(0.5);
 				var action3 = cc.moveBy(0.5,cc.p(0,-10));

 				var action5 = cc.moveBy(0.5,cc.p(-50,0));

 				this.effUINode.runAction(cc.sequence(cc.spawn(action2,action3)));
 				this.menu.runAction(cc.sequence(cc.spawn(action5)));
 				cc.eventManager.removeListeners(this.background);  

 			}
 		}else{
 			if (this.isShow == false) {

 				this.effUINode.y = -10;
 				this.isShow = (true);

	 			var action2 = cc.fadeIn(0.5);
	 			var action3 = cc.moveBy(0.5,cc.p(0,10));
				var action5 = cc.moveBy(0.5,cc.p(50,0));
 				this.effUINode.runAction(cc.sequence(cc.spawn(action2,action3)));
 				this.menu.runAction(cc.sequence(cc.spawn(action5)));

 				this.addBgListener();
 			};

 			if (this.isVisible() == false) {
 				this.setVisible(true);
 			};
 		}


 	},

});