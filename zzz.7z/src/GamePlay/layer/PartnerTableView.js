/**
 * Created by wangzhigang on 15/9/15.
 */

 var TV_PN_RES = [
 	{name: "f05006",attr : "f07_hp", bg: "i01_05",tag : 1},
 	{name: "f05007",attr : "f07_dps", bg: "i01_06",tag : 2},
 	{name: "f05008",attr : "f07_hp", bg: "i01_07",tag : 3},

 ];

 var TV_PN_TAG = {
 	BG : 126,

 };

 var GPPartnerTableView = cc.TableView.extend({

 	ctor : function(){
 		this._super(this,cc.size(580/4, 300));
 		this.loadConfig();

 	},
 	loadConfig : function(){
 		this.setDirection(cc.SCROLLVIEW_DIRECTION_HORIZONTAL);
 		this.x = -70;
 		this.y = -35;
 		this.reloadData();

 	},
 	numberOfCellsInTableView:function (table) {
 	    return 3;
 	},
 	tableCellSizeForIndex:function (table, idx) {
 	    return cc.size(160/4, 300);
 	},
 	createIcon : function(cell){

 		var sprite = cell.getChildByTag(123);

 		 var sprite = new cc.Sprite(res[TV_PN_RES[idx].bg]);
 		 sprite.anchorX = 0;
 		 sprite.anchorY = 0;
 		 sprite.x = 2;
 		 sprite.y = 30;
 		 cell.addChild(sprite);
 		 sprite.tag = 126;
 	},
 	tableCellAtIndex:function (table, idx) {
 	    var cell = table.dequeueCell();
 	    var label;

 	    if (!cell) {
 	        cell = new CustomTableViewCell();

 	       //  var sprite = new cc.Sprite(res[TV_PN_RES[idx].bg]);
 	       //  sprite.anchorX = 0;
 	       //  sprite.anchorY = 0;
 	       //  sprite.x = 2;
 	       //  sprite.y = 30;
 	       //  cell.addChild(sprite);
 	       //  sprite.tag = 126;

 	       //  var nodeNormal    = new cc.Sprite(res.ui_btn_zdxf_02);
 	       //  var nodeSelected  = new cc.Sprite(res.ui_btn_zdxf_01);
 	       //  var nodeDisabled  = new cc.Sprite(res.ui_btn_zdxf_02);

 	       //  var mnode
 	       //  mnode= new cc.MenuItemSprite(
	        //     nodeNormal,
	        //     nodeSelected,
	        //     nodeDisabled,
	        //     function(){
	        //     	var idx = mnode.idx;

	        //     	var value = GameManager.getInstance().getCharacterNeedGold(TV_PN_RES[idx].tag);
	        //     	var gold = GameManager.getInstance().getGold();
	        //     	if (gold >= value) {

	        //     		// 数据处理
	        //     		var lv = GameManager.getInstance().getCharacterLevel(TV_PN_RES[idx].tag);
	        //     		GameManager.getInstance().setCharacterLevel(TV_PN_RES[idx].tag,(lv+1));
	        //     		GameManager.getInstance().resetRoleData();
	        //     		GameManager.getInstance().saveLocalData();

	        //     		mnode.fGold.removeFromParent();
	        //     		var value = GameManager.getInstance().getCharacterNeedGold(TV_PN_RES[idx].tag);
	        //     		var gold = GameManager.getInstance().getGold();
	        //     		if (gold >= value) {
	        //     			mnode.unselected();
	        //     		}else{
	        //     			mnode.unselected();
	        //     		}

	        //     		var fNode = Common.createFontNode(value,3);
	        //     		fNode.anchorX = 0;
	        //     		fNode.anchorY = 0;
	        //     		fNode.x = 40;
	        //     		fNode.y = 55;
	        //     		fNode.setScale(2)
	        //     		mnode.addChild(fNode);
	        //     		mnode.fGold = fNode;

	        //     		mnode.fAttr.removeFromParent();
	        //     		var value = GameManager.getInstance().getCharacterAddAttr(TV_PN_RES[idx].tag);
	        //     		var fNode = Common.createFontNode(value,7);
	        //     		fNode.anchorX = 0;
	        //     		fNode.anchorY = 0;
	        //     		fNode.x = 80;
	        //     		fNode.y = 25;
	        //     		mnode.addChild(fNode);
	        //     		mnode.fAttr = fNode;

	        //     		mnode.fLv.removeFromParent();
	        //     		var value = GameManager.getInstance().getCharacterLv(TV_PN_RES[idx].tag);
	        //     		var fNode = Common.createFontNode(value,10);
	        //     		fNode.anchorX = 0;
	        //     		fNode.anchorY = 0;
	        //     		fNode.x = 60;
	        //     		fNode.y = 110;
	        //     		mnode.addChild(fNode);
	        //     		mnode.fLv = fNode;
	        //     	}else{
	        //     		cc.log("gold less")
	        //     	}
         //    	}.bind(mnode));

 	       //  mnode.x = 2+ sprite.getContentSize().width/2;
 	       //  mnode.y = 17;
 	       //  mnode.setScale(1/GC.SCALE_RATE);


 	       //  mnode.tag = 124;
 	       //  mnode.idx = idx;

 	       //  var menu = new cc.Menu();
 	       //  menu.setPosition(0, 0);
 	       //  menu.addChild(mnode);
	       	// cell.addChild(menu);

	       	// menu.setSwallowTouches(false);
	       	// menu.tag = 125;

	       	// var node= new cc.Sprite(res.f10_lv);
	       	// node.anchorX = 0;
	       	// node.anchorY = 0;
	       	// node.x = 10;
	       	// node.y = 95;
	       	// mnode.addChild(node);

	       	// var value = GameManager.getInstance().getCharacterLv(TV_PN_RES[idx].tag);
	       	// var fNode = Common.createFontNode(value,10);
	       	// fNode.anchorX = 0;
	       	// fNode.anchorY = 0;
	       	// fNode.x = 60;
	       	// fNode.y = 110;
	       	// mnode.addChild(fNode);
	       	// mnode.fLv = fNode;


 	       //  var value = GameManager.getInstance().getCharacterNeedGold(TV_PN_RES[idx].tag);
 	       //  var fNode = Common.createFontNode(value,3);
 	       //  fNode.anchorX = 0;
 	       //  fNode.anchorY = 0;
 	       //  fNode.x = 40;
 	       //  fNode.y = 55;
 	       //  fNode.setScale(2)
 	       //  mnode.addChild(fNode);

 	       //  mnode.fGold = fNode;


 	       //  var gold = GameManager.getInstance().getGold();
 	       //  if (gold >= value) {
 	       //  	mnode.unselected();
 	       //  }else{
 	       //  	mnode.unselected();
 	       //  }

 	       //  var gold = new cc.Sprite(res.ui_gold2020);
 	       //  gold.anchorX = 0;
 	       //  gold.anchorY = 0;
 	       //  gold.x = 5;
 	       //  gold.y = 45;
 	       //  mnode.addChild(gold);

 	       //  var dps = new cc.Sprite(res[TV_PN_RES[idx].attr]);
 	       //  dps.x = 30;
 	       //  dps.y = 25;
 	       //  mnode.addChild(dps);
 	       //  mnode.dps = dps;

 	       //  var plus= new cc.Sprite(res.f07_plus);
 	       //  plus.x = 65;
 	       //  plus.y = 25;
 	       //  mnode.addChild(plus);

 	       //  var value = GameManager.getInstance().getCharacterAddAttr(TV_PN_RES[idx].tag);
 
 	       //  var fNode = Common.createFontNode(value,7);
 	       //  fNode.anchorX = 0;
 	       //  fNode.anchorY = 0;
 	       //  fNode.x = 80;
 	       //  fNode.y = 25;
 	       //  mnode.addChild(fNode);
 	       //  mnode.fAttr = fNode;

	       	// var sprite = new cc.Sprite(res[TV_PN_RES[idx].name]);
	       	// sprite.anchorX = 0;
	       	// sprite.anchorY = 0;
       		// sprite.x = 5;
       		// sprite.y = 52;
	       	// sprite.setScale(1/4);
	       	// sprite.tag = 123;
	       	// cell.addChild(sprite,2);

 	    }else{
	    	// var sprite = cell.getChildByTag(123);
	    	// sprite.setTexture(res[TV_PN_RES[idx].name]);

	    	// var menu = cell.getChildByTag(125);
	    	// var mnode = menu.getChildByTag(124);
	    	// mnode.idx = idx;

	    	// mnode.fGold.removeFromParent();
	    	// var value = GameManager.getInstance().getCharacterNeedGold(TV_PN_RES[idx].tag);
	    	// var fNode = Common.createFontNode(value,3);
	    	// fNode.anchorX = 0;
	    	// fNode.anchorY = 0;
	    	// fNode.x = 40;
	    	// fNode.y = 55;
	    	// fNode.setScale(2)
	    	// mnode.addChild(fNode);
	    	// mnode.fGold = fNode;

	    	// mnode.fAttr.removeFromParent();
	    	// var value = GameManager.getInstance().getCharacterAddAttr(TV_PN_RES[idx].tag);
	    	// var fNode = Common.createFontNode(value,7);
	    	// fNode.anchorX = 0;
	    	// fNode.anchorY = 0;
	    	// fNode.x = 80;
	    	// fNode.y = 25;
	    	// mnode.addChild(fNode);
	    	// mnode.fAttr = fNode;

	    	// mnode.fLv.removeFromParent();
	    	// var value = GameManager.getInstance().getCharacterLv(TV_PN_RES[idx].tag);
	    	// var fNode = Common.createFontNode(value,10);
	    	// fNode.anchorX = 0;
	    	// fNode.anchorY = 0;
	    	// fNode.x = 60;
	    	// fNode.y = 110;
	    	// mnode.addChild(fNode);
	    	// mnode.fLv = fNode;


	    	// mnode.dps.setTexture(res[TV_PN_RES[idx].attr]);

	    	// var bg = cell.getChildByTag(126);
	    	// bg.setTexture(res[TV_PN_RES[idx].bg]);

	    }

	    createIcon(cell);

 	    return cell;
 	},
 	tableCellTouched:function (table, cell) {
 	    cc.log("cell touched at index: " + cell.getIdx());
 	},
 });