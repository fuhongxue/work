/**
 * Created by wangzhigang on 15/9/17.
 */

var GPForeParallaxLayer = cc.Layer.extend({
	parallaxNode : null,
	treeVector : [],
	ctor:function () {
		this._super();
		this.loadParallaxNode();
		this.loadBg();
	},
	loadBg : function(){
		var mapInfo = GameManager.getInstance().mapInfo

		var prefix = mapInfo[0] + "_" + mapInfo[1];
		var forewordObj = BgParallax[mapInfo[0]]["foreword"];

		var tnode = new cc.Node();

		for (var i = 0; i < forewordObj.length; i++) {
			var fieldObj = forewordObj[i];

			var node = new cc.Sprite(res[prefix + "_" + fieldObj.name]);
			node.setScale(GC.SCALE_RATE );
			node.anchorX = 0.5;
			node.anchorY = 0;

			node.curPosIndex = -1;
			node.posVector = fieldObj.posVector;
			node.field = fieldObj.name;
			tnode.addChild(node);

			this.treeVector.push(node);
		};
		this.parallaxNode.addChild(tnode, -1, cc.p(fieldObj.ratio, 0), cc.p(-GC.w,0));
	},
	loadParallaxNode : function(){
		var node = new cc.ParallaxNode();
		this.addChild(node);
		this.parallaxNode = node;
	},
	update : function(dt){
		var heroObj = GameManager.getInstance().getHeroObj();
		var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;
		this.parallaxNode.x = this.parallaxNode.x  -  heroObj.getSpeed() * dt*dir;

		var pPosx = -this.parallaxNode.x;
        for ( i = 0, len = this.treeVector.length; i< len; i++){
        	var node = this.treeVector[i];
    		var posVector = node.posVector;

    		var nodeX = node.getParent().convertToWorldSpace(node.getPosition()).x

    		if (nodeX <= GC.w+node.getBoundingBox().width/2 && nodeX >= -node.getBoundingBox().width/2) {
    		}else{
    			var index = -1;
    			for (var j = 0; j < posVector.length; j++) {
    				var vPosx = posVector[j];

    				if (pPosx <= vPosx) {
    					index = j;
    					break;
    				};
    			};
		

    			if(index == 0){
    				if ( pPosx+ (GC.w2 + node.getBoundingBox().width/2)  >= posVector[index] ) {

						var pos = node.getParent().convertToNodeSpace(cc.p(GC.w+node.getBoundingBox().width/2,0));
						node.setPositionX(pos.x);;
    				}

    			}else if(index == -1){
    				if (pPosx - (GC.w2 + node.getBoundingBox().width/2) <= posVector[posVector.length-1]) {    	
						var pos = node.getParent().convertToNodeSpace(cc.p(-node.getBoundingBox().width/2,0));
						node.setPositionX(pos.x);
    				};
    			}else{
    				if ( pPosx+ (GC.w2 + node.getBoundingBox().width/2)  >= posVector[index] ) {
		

						var pos = node.getParent().convertToNodeSpace(cc.p(GC.w+node.getBoundingBox().width/2,0));
						node.setPositionX(pos.x);
    				}else if (pPosx - (GC.w2 + node.getBoundingBox().width/2) <= posVector[index -1]) {   
		 					
						var pos = node.getParent().convertToNodeSpace(cc.p(-node.getBoundingBox().width/2,0));
						node.setPositionX(pos.x);
    				};
    			}
    		}
        }
    	
	}

});