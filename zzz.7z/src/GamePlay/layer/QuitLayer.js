/**
 * Created by wangzhigang on 15/9/16.
 */


 var GPQuitLayer = cc.Layer.extend({
 	maskLayer : null,
 	maskListener : null,
 	ctor:function() {
 		this._super();
 		this.loadMaskLayer();
 		this.loadMaskListener();
 		this.loadBg();
 		this.loadCancleBtn();
 		this.loadContinueBtn();
 		this.loadQuitBtn();
	},
	loadMaskLayer : function(){
		var node = new cc.LayerColor(cc.color(0, 0, 0, 138), GC.w, GC.h);
		this.addChild(node,0);
		node.x = 0;
		node.y = 0;
		node.setScale(GC.SCALE_RATE);

		this.maskLayer = node;
	},
	loadMaskListener : function(){
		var listener = cc.EventListener.create({
		    event           : cc.EventListener.TOUCH_ONE_BY_ONE,
		    swallowTouches  : true,
		    onTouchBegan    : function(){
		    	return true;
		    },
		});
		cc.eventManager.addListener(listener, this.maskLayer);
		this.maskListener = listener;
	},
	loadBg : function(){
		var node = new cc.Sprite(res.ui_tanchuangbg);
		this.addChild(node,0);
		node.x = GC.w2;
		node.y = GC.h2;
	},
	loadCancleBtn : function(){
		var nodeNormal    = new cc.Sprite(res.btn_x01);
		var nodeSelected  = new cc.Sprite(res.btn_x02);
		var nodeDisabled  = new cc.Sprite(res.btn_x01);

		var node = new cc.MenuItemSprite(
		nodeNormal,
		nodeSelected,
		nodeDisabled,
		function(){
			this.setVisible(false);
			cc.eventManager.removeListener(this.maskListener);			
		}.bind(this));

		node.x = 780;
		node.y = 430;

		var menu = new cc.Menu();
		menu.setPosition(0, 0);
		menu.addChild(node);
		this.addChild(menu);
	},
	loadContinueBtn : function(){
		var nodeNormal    = new cc.Sprite(res.btn_jx01);
		var nodeSelected  = new cc.Sprite(res.btn_jx02);
		var nodeDisabled  = new cc.Sprite(res.btn_jx01);

		var node = new cc.MenuItemSprite(
		nodeNormal,
		nodeSelected,
		nodeDisabled,
		function(){
			this.setVisible(false);
			cc.eventManager.removeListener(this.maskListener);			
		}.bind(this));

		node.x = GC.w2;
		node.y = GC.h2+50;

		var menu = new cc.Menu();
		menu.setPosition(0, 0);
		menu.addChild(node);
		this.addChild(menu);
	},
	loadQuitBtn : function(){
		var nodeNormal    = new cc.Sprite(res.btn_tc01);
		var nodeSelected  = new cc.Sprite(res.btn_tc02);
		var nodeDisabled  = new cc.Sprite(res.btn_tc01);

		var node = new cc.MenuItemSprite(
		nodeNormal,
		nodeSelected,
		nodeDisabled,
		function(){
			 cc.director.runScene(new GameStartScene());
		}.bind(this));

		node.x = GC.w2;
		node.y = GC.h2-50;

		var menu = new cc.Menu();
		menu.setPosition(0, 0);
		menu.addChild(node);
		this.addChild(menu);
	},
	reload : function(){
		this.setVisible(true);
		cc.eventManager.addListener(this.maskListener, this.maskLayer);
	}	
}); 