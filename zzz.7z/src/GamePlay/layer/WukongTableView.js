/**
 * Created by wangzhigang on 15/9/15.
 */

var TV_WU_RES = [
	{name: "f05005",attr : "f07_hp", bg: "i01_01", type : "wukong"},
	{name: "f05003",attr : "f07_dps", bg: "i01_skilljdy", type : "jdy"},
	{name: "f05004",attr : "f07_hp", bg: "i01_skilldtyb", type : "jgb"},
	{name: "f05002",attr : "f07_hp", bg: "i01_07", type : "fs"},

];

var GPWukongTableView = cc.TableView.extend({

	ctor : function(){
		this._super(this,cc.size(580/4, 300));
		this.loadConfig();

	},
	loadConfig : function(){
		this.setDirection(cc.SCROLLVIEW_DIRECTION_HORIZONTAL);
		this.x = -70;
		this.y = -35;
		this.reloadData();

	},
	numberOfCellsInTableView:function (table) {
	    return 4;
	},
	tableCellSizeForIndex:function (table, idx) {
	    return cc.size(160/4, 300);
	},
	tableCellAtIndex:function (table, idx) {
	    var cell = table.dequeueCell();
	    var label;
	    if (!cell) {
	        cell = new CustomTableViewCell();

	        var sprite = new cc.Sprite(res[TV_WU_RES[idx].bg]);
	        sprite.anchorX = 0;
	        sprite.anchorY = 0;
	        sprite.x = 2;
	        sprite.y = 30;
	        cell.addChild(sprite);
	        sprite.tag = 126;

	        var nodeNormal    = new cc.Sprite(res.ui_btn_zdxf_02);
	        var nodeSelected  = new cc.Sprite(res.ui_btn_zdxf_01);
	        var nodeDisabled  = new cc.Sprite(res.ui_btn_zdxf_02);
	        
	        var mnode
	        var mnode = new cc.MenuItemSprite(
            nodeNormal,
            nodeSelected,
            nodeDisabled,
            function(){
				cc.log("good")
        	}.bind(this));
	        mnode.x = 2+ sprite.getContentSize().width/2;
	        mnode.y = 17;

	        mnode.setScale(1/GC.SCALE_RATE);
	        mnode.tag = 124;

	        var menu = new cc.Menu();
	        menu.setPosition(0, 0);
	        menu.addChild(mnode);
       		cell.addChild(menu);
       		menu.tag = 125;

       		menu.setSwallowTouches(false);

       		var gold = new cc.Sprite(res.ui_gold2020);
       		gold.anchorX = 0;
       		gold.anchorY = 0;
       		gold.x = 5;
       		gold.y = 45;
       		mnode.addChild(gold);

       		var dps = new cc.Sprite(res[TV_WU_RES[idx].attr]);
       		dps.x = 30;
       		dps.y = 25;
       		mnode.addChild(dps);
       		mnode.dps = dps;

       		var plus= new cc.Sprite(res.f07_plus);
       		plus.x = 65;
       		plus.y = 25;
       		mnode.addChild(plus);


       		var value = GameManager.getInstance().getCharacterNeedGold(0);
       		var fNode = Common.createFontNode(value,3);
       		fNode.anchorX = 0;
       		fNode.anchorY = 0;
       		fNode.x = 40;
       		fNode.y = 55;
       		fNode.setScale(2)
       		mnode.addChild(fNode);

       		mnode.fGold = fNode;


       		var value = GameManager.getInstance().getCharacterNeedGold(0);
       		value = 100
       		var fNode = Common.createFontNode(value,7);
       		fNode.anchorX = 0;
       		fNode.anchorY = 0;
       		fNode.x = 80;
       		fNode.y = 25;
       		mnode.addChild(fNode);

       		var sprite = new cc.Sprite(res[TV_WU_RES[idx].name]);
       		sprite.anchorX = 0;
       		sprite.anchorY = 0;
       		sprite.x = 5;
       		sprite.y = 52;
       		sprite.setScale(1/4);
       		sprite.tag = 123;
       		cell.addChild(sprite);

	    }else{
	    	sprite = cell.getChildByTag(123);
	    	sprite.setTexture(res[TV_WU_RES[idx].name]);

	    	var bg = cell.getChildByTag(126);
	    	bg.setTexture(res[TV_WU_RES[idx].bg]);

	    	var menu = cell.getChildByTag(125);
	    	var mnode = menu.getChildByTag(124);

	    	mnode.fGold.removeFromParent();
	    	var value = GameManager.getInstance().getCharacterNeedGold(0);
	    	var fNode = Common.createFontNode(value,3);
	    	fNode.anchorX = 0;
	    	fNode.anchorY = 0;
	    	fNode.x = 40;
	    	fNode.y = 55;
	    	fNode.setScale(2)
	    	mnode.addChild(fNode);
	    	mnode.fGold = fNode;
	    }

	    return cell;
	},
});