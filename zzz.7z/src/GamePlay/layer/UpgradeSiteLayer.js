
/**
 * Created by wangzhigang on 15/4/20.
 */

 var CustomTableViewCell = cc.TableViewCell.extend({
     draw:function (ctx) {
         this._super(ctx);
     }
 });

 var GPUpgradeSiteLayer = cc.Layer.extend({
 	background : null,
 	wukongItem : null,
 	partnerItem : null,
 	menu        : null,
 	tvWukong    : null,
 	tvPartner   : null,
 	ctor : function(){
 		this._super();
 		this.loadConfig();
 		this.loadBg();
 		this.loadGradientUI();
 		this.loadWukongItem();
 		this.loadPartnerItem();
 		this.loadWukongTableView();

 	},
 	loadConfig : function(){

 	},
 	loadBg : function(){
 		var node = new cc.Sprite(res.ui_zdbg_02);
 		node.setAnchorPoint(0.5,0.5);
 		this.addChild(node);

 		this.background = node;

 		var menu = new cc.Menu();
 		this.addChild(menu,1);
 		menu.setPosition(0, 0);

 		this.menu = menu;


 		var listener = cc.EventListener.create({
 		    event           : cc.EventListener.TOUCH_ONE_BY_ONE,
 		    // target          : this.background,
 		    swallowTouches  : true,
 		    onTouchBegan    : this.onTouchBegan,
 		    // onTouchMoved    : this.onTouchMoved,
 		    // onTouchEnded    : this.onTouchEnded
 		});
 		cc.eventManager.addListener(listener, this.background);
 	},
 	loadGradientUI : function(){
 		var node = new cc.Sprite(res.ui_zd_01);
 		this.addChild(node,1);

 		node.setPosition(cc.p(-68,0))
 		node.setScale(1/GC.SCALE_RATE);

 		var node = new cc.Sprite(res.ui_zd_02);
 		this.addChild(node,1);

 		node.setPosition(cc.p(72,0))
 		node.setScale(1/GC.SCALE_RATE);
 	},
 	onTouchBegan: function (touch, event) {
 		var target = event.getCurrentTarget();

 		var locationInNode = target.convertToNodeSpace(touch.getLocation());
 		var s = target.getContentSize();
 		var rect = cc.rect(0, 0, s.width, s.height);
 		if (cc.rectContainsPoint(rect, locationInNode)) {
 		    return true;
 		}

		return false
	},
 	loadWukongItem : function(){
 		var nodeNormal    = new cc.Sprite(res.ui_btn_hbwk_02);
 		var nodeSelected  = new cc.Sprite(res.ui_btn_hbwk_01);
 		var nodeDisabled  = new cc.Sprite(res.ui_btn_hbwk_02);

 		var node = new cc.MenuItemSprite(
 		    nodeNormal,
 		    nodeSelected,
 		    nodeDisabled,
 		    function(){
 		    	this.wukongItem.selected();
 		    	this.partnerItem.unselected();
 		    	this.tvPartner.getContainer().setVisible(false);
 		    	this.tvWukong.getContainer().setVisible(true);
 		    	this.tvPartner.setTouchEnabled(false);
 		    	this.tvWukong.setTouchEnabled(true);

 		    }.bind(this));
 		node.setPosition(this.background.getContentSize().width/2+8, this.background.getContentSize().height/2-20);

 		node.selected()

 		this.menu.addChild(node)

 		this.wukongItem = node;
 	},
 	loadPartnerItem : function() {
 		// var self = this;

 		var nodeNormal    = new cc.Sprite(res.ui_btn_hbwk_02);
 		var nodeSelected  = new cc.Sprite(res.ui_btn_hbwk_01);
 		var nodeDisabled  = new cc.Sprite(res.ui_btn_hbwk_02);

 		var node = new cc.MenuItemSprite(
 		    nodeNormal,
 		    nodeSelected,
 		    nodeDisabled,
 		    function(){
 		    	this.partnerItem.selected();
 		    	this.wukongItem.unselected();

 		    	this.tvPartner.getContainer().setVisible(true);
 		    	this.tvWukong.getContainer().setVisible(false);
 		    	this.tvPartner.setTouchEnabled(true);
 		    	this.tvWukong.setTouchEnabled(false);

 		    }.bind(this));
 		node.setPosition(this.background.getContentSize().width/2+8, this.background.getContentSize().height/2-50);

 		this.menu.addChild(node)
 		this.partnerItem = node;
 	},
 	loadWukongTableView : function(){
 		var node = new GPWukongTableView();
 		this.addChild(node);
 		this.tvWukong = node;

 		var node = new GPPartnerTableView();
 		this.addChild(node);
 		this.tvPartner = node;

 		this.tvPartner.getContainer().setVisible(false);
 		this.tvPartner.setTouchEnabled(false);
 	},


});