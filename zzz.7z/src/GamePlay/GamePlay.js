/**
 * Created by wangzhigang on 15/4/20.
 */


var GamePlayLayer = cc.Layer.extend({
    backgroundLayer : null,
    mainLayar : null,
    foreParallaxLayer : null,
    ctor:function () {
        this._super();
        new LevelLoader(1);

        this.loadBackground();
        this.loadMainLayer();
        this.loadForeParallax();
        return true;
    },
    loadBackground : function(){
        this.backgroundLayer = new GPBackgroundLayer();
        this.addChild(this.backgroundLayer);

        GameManager.getInstance().GPBackgroundLayer= this.backgroundLayer;
    },
    loadMainLayer : function(){
        this.mainLayar = new GPMainLayer();
        this.addChild(this.mainLayar);

        GameManager.getInstance().GPMainLayer = this.mainLayar;
    },
    loadForeParallax : function(){
        this.foreParallaxLayer = new GPForeParallaxLayer();
        this.addChild(this.foreParallaxLayer);

        GameManager.getInstance().foreParallaxLayer = this.foreParallaxLayer;

    },

});

var GamePlayScene = cc.Scene.extend({
    onEnter:function () {
        this._super();
        var layer = new GamePlayLayer();
        this.addChild(layer);

        
    }
});