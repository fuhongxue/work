

var Common = {
	createAnimateNode : function (frameNum,prefix,isRepeated,delayPerUnit){
		var delay = delayPerUnit ? delayPerUnit : GC.WEAPON_EFFECT_TIME;

		var node = new cc.Sprite();

		var animation = cc.Animation.create();  //利用动画保存每一帧的图片

		for (var i = 1; i <= frameNum; i++) {
			animation.addSpriteFrameWithFile(res[prefix + i ]);
		};

		animation.setDelayPerUnit(delay);  //每一帧播放的间隔
		var animate = cc.animate(animation);
		var callBack = cc.callFunc(function(){
			this.removeAllChildrenWithCleanup(true)
			this.removeFromParent(true);
		}.bind(node));
		if (!isRepeated) {
			node.runAction(cc.sequence(animate,callBack));
		}else{
			node.runAction(animate.repeatForever());
		}

		return node;
	},
	createFontNode : function(value,type){
		if (type < 10 ) {type = "0"+type};
		var pNode = new cc.Node();
		var node
		var strValue = value.toString();
		for (var i = 0; i < strValue.length; i++) {
			if (strValue[i] == '.') {
				 node = new cc.Sprite(res["f"+type.toString()+"_dot"]);
			}else{
				 node = new cc.Sprite(res["f"+ type.toString() + "_"+ strValue[i]]);
			};
			if (type == 7) {
				node.setPositionX(15*i)
			}else{
				node.setPositionX(8*i)
			}

			pNode.addChild(node);
		};

		return pNode;
	},
	registerFunction : function(){
		cc.Menu.prototype.setSwallowTouches = function(b){
			this._touchListener.setSwallowTouches(b);
		}
	},
};