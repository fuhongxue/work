/**
 * Created by wangzhigang on 15/9/15.
 */

var TV_WU_RES = [
	"f05005",
	"f05003",
	"f05004",
	"f05002",
];

var GPWukongTableView = cc.TableView.extend({

	ctor : function(){
		this._super(this,cc.size(580/4, 300));
		this.loadConfig();

	},
	loadConfig : function(){
		this.setDirection(cc.SCROLLVIEW_DIRECTION_HORIZONTAL);
		this.x = -70;
		this.y = -35;
		this.reloadData();

	},
	numberOfCellsInTableView:function (table) {
	    return 4;
	},
	tableCellSizeForIndex:function (table, idx) {
	    return cc.size(160/4, 300);
	},
	tableCellAtIndex:function (table, idx) {
		
	    // var strValue = idx.toFixed(0);
	    var cell = table.dequeueCell();
	    var label;
	    if (!cell) {
	        cell = new CustomTableViewCell();

	        var sprite = new cc.Sprite(res.i01_01);
	        sprite.anchorX = 0;
	        sprite.anchorY = 0;
	        sprite.x = 2;
	        sprite.y = 30;
	        cell.addChild(sprite);


	        var nodeNormal    = new cc.Sprite(res.ui_btn_zdxf_01);
	        var nodeSelected  = new cc.Sprite(res.ui_btn_zdxf_02);
	        var nodeDisabled  = new cc.Sprite(res.ui_btn_zdxf_01);

	        var node = new cc.MenuItemSprite(
            nodeNormal,
            nodeSelected,
            nodeDisabled,
            function(){
				cc.log("good")
        	}.bind(this));

	        node.x = 2+ sprite.getContentSize().width/2;
	        node.y = 17;

	        node.setScale(1/GC.SCALE_RATE);

	        var menu = new cc.Menu();
	        menu.setPosition(0, 0);
	        menu.addChild(node);
       		cell.addChild(menu);

       		menu.setSwallowTouches(false);

       		var gold = new cc.Sprite(res.ui_gold2020);
       		gold.anchorX = 0;
       		gold.anchorY = 0;
       		gold.x = 5;
       		gold.y = 45;
       		node.addChild(gold);


       		var value = GameManager.getInstance().getHeroNeedGold();
       		value = 12465
       		var fNode = Common.createFontNode(value,3);
       		fNode.anchorX = 0;
       		fNode.anchorY = 0;
       		fNode.x = 30;
       		fNode.y = 55;
       		fNode.setScale(2)
       		node.addChild(fNode);


       		var dps = new cc.Sprite(res.f07_dps);
       		dps.x = 30;
       		dps.y = 25;
       		node.addChild(dps);

       		var plus= new cc.Sprite(res.f07_plus);
       		plus.x = 65;
       		plus.y = 25;
       		node.addChild(plus);

       		var value = GameManager.getInstance().getHeroNeedGold();
       		value = 100
       		var fNode = Common.createFontNode(value,7);
       		fNode.anchorX = 0;
       		fNode.anchorY = 0;
       		fNode.x = 80;
       		fNode.y = 25;
       		node.addChild(fNode);

       		var sprite = new cc.Sprite(res[TV_WU_RES[idx]]);
       		sprite.anchorX = 0;
       		sprite.anchorY = 0;
       		sprite.x = 5;
       		sprite.y = 52;
       		sprite.setScale(1/4);
       		sprite.tag = 123;
       		cell.addChild(sprite);

	    }else{
	    	sprite = cell.getChildByTag(123);
	    	sprite.setTexture(res[TV_WU_RES[idx]]);
	    }

	    return cell;
	},
});