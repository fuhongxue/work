/**
 * Created by wangzhigang on 15/9/17.
 */

var GPForeParallaxLayer = cc.Layer.extend({
	parallaxNode : null,
	treeVector : [],
	ctor:function () {
		this._super();
		this.loadParallaxNode();
		this.loadBg();
	},
	loadBg : function(){
		var mapInfo = GameManager.getInstance().mapInfo

		var prefix = mapInfo[0] + "_" + mapInfo[1];
		var forewordObj = BgParallax[mapInfo[0]]["foreword"];

		var tnode = new cc.Node();

		for (var i = 0; i < forewordObj.length; i++) {
			var fieldObj = forewordObj[i];

			var node = new cc.Sprite(res[prefix + "_" + fieldObj.name]);
			node.setScale(GC.SCALE_RATE );
			node.anchorX = 0.5;
			node.anchorY = 0;

			node.curPosIndex = -1;
			node.posVector = fieldObj.posVector;
			node.field = fieldObj.name;
			tnode.addChild(node);

			this.treeVector.push(node);
		};
		this.parallaxNode.addChild(tnode, -1, cc.p(fieldObj.ratio, 0), cc.p(-GC.w,0));
	},
	loadParallaxNode : function(){
		var node = new cc.ParallaxNode();
		this.addChild(node);
		this.parallaxNode = node;
	},
	update : function(dt){
		var heroObj = GameManager.getInstance().getHeroObj();
		var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;
		this.parallaxNode.x = this.parallaxNode.x  -  heroObj.getSpeed() * dt*dir;

		var pPosx = -this.parallaxNode.x;
        for ( i = 0, len = this.treeVector.length; i< len; i++){
        	var node = this.treeVector[i];
    		var posVector = node.posVector;

			if ( pPosx >= posVector[0] && node.curPosIndex == -1 ) {

				node.curPosIndex = 0;

				var pos = node.getParent().convertToNodeSpace(cc.p(GC.w+node.getBoundingBox().width/2,0));
				node.setPositionX(pos.x);;
			}else if(heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT && (node.curPosIndex+1)<=(posVector.length - 1) && pPosx >= posVector[node.curPosIndex+1]){
				cc.log("pPosx: " +pPosx )


				node.curPosIndex = node.curPosIndex + 1;

				var pos = node.getParent().convertToNodeSpace(cc.p(GC.w+node.getBoundingBox().width/2,0));
				node.setPositionX(pos.x);;
			}else if(heroObj.getDirection() == GC.CHARACTER_DIRECTION.LEFT && node.curPosIndex >-1 && pPosx <= posVector[node.curPosIndex] ){
				cc.log("pPosx: " +pPosx )


					node.curPosIndex = node.curPosIndex - 1;

					var pos = node.getParent().convertToNodeSpace(cc.p(-node.getBoundingBox().width/2,0));
					node.setPositionX(pos.x);
			}

        }
    	
	}

});