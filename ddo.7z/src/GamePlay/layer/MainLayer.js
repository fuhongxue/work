/**
 * Created by wangzhigang on 15/4/20.
 */

 var GPMainLayer = cc.Layer.extend({
 	gameManager     : null,     // 对象[游戏管理者]
 	totalOffset     : null,
 	temple          : null,
 	goldNode        : null,
 	upgradeSite     : null,
 	quitLayer       : null,
 	ctor:function() {
 		this._super();

 		this.temple = new cc.Node();
 		this.addChild(this.temple);

 		// 加载[配置]
 		this.loadConfig();
 		// this.loadTiledMap();
 		this.loadGoldUI();
 		this.loadMonster();
 		this.loadHero();
 		this.loadQuitBtn();
 		this.loadShopBtn();

 		// 绑定[事件][触摸]
 		this.bindTouchListener();
 		// 定时[更新游戏逻辑]
 		this.scheduleUpdate();

 		return true;
 	},

 	loadConfig : function() {
 		// 配置[游戏管理对象]
 		this.gameManager = GameManager.getInstance(); 	

 		this.totalOffset = 0;

 		// var node = new cc.Node();

 		// var layer = new GPUpgradeSiteLayer();

 		// layer.setPosition(cc.p(GC.w2/4,GC.h2/4));
 		// node.addChild(layer);

 		// node.setScale(4)

 		// this.addChild(node)

 	},
 	createGoldNode : function(value){
 		if (this.goldNode) {
 			this.goldNode.removeAllChildrenWithCleanup(true)
 			this.goldNode.removeFromParent(true);
 		};

 		var pNode = Common.createFontNode(value,3);

 		this.addChild(pNode)
 		pNode.setPosition(cc.p(GC.w2-70,GC.h-55));
 		pNode.setScale(4);

 		this.goldNode = pNode;
 	},
 	loadGoldUI : function(){
 		var node = new cc.Sprite(res.ui_biggoldcoin);
 		this.addChild(node);
 		node.setScale(4);
 		node.setPosition(cc.p(GC.w2-100,GC.h-55));

 		this.createGoldNode(0);
 	},
 	loadQuitBtn : function(){

        var nodeNormal    = new cc.Sprite(res.btn_back01);
        var nodeSelected  = new cc.Sprite(res.btn_back02);
        var nodeDisabled  = new cc.Sprite(res.btn_back01);

        var node = new cc.MenuItemSprite(
        nodeNormal,
        nodeSelected,
        nodeDisabled,
        function(){
        	if (this.quitLayer) {
        		cc.log("add Layer")
        		this.quitLayer.reload();
        	}else{
        		var layer = new GPQuitLayer();
        		this.addChild(layer)

        		this.quitLayer = layer;
        	}
    	}.bind(this));

        node.x = GC.w-node.getBoundingBox().width;
        node.y = GC.h - 50;

        // node.setScale(1/GC.SCALE_RATE);

        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        menu.addChild(node);

 		this.addChild(menu);
 	},
 	loadShopBtn : function(){
        var nodeNormal    = new cc.Sprite(res.btn_sc01);
        var nodeSelected  = new cc.Sprite(res.btn_sc02);
        var nodeDisabled  = new cc.Sprite(res.btn_sc01);

        var node = new cc.MenuItemSprite(
        nodeNormal,
        nodeSelected,
        nodeDisabled,
        function(){
			cc.log("loadShopBtn")
    	}.bind(this));

        node.x = 50;
        node.y = GC.h - 50;

        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        menu.addChild(node);

 		this.addChild(menu);
 	},
 	loadMonster : function() {
 		var monsterGroupVector = this.gameManager.getMonsterGroupVector();
 		var monsterVector = this.gameManager.getMonsterVector();

 		var groupWidth = 0;
 		for (var i = 0; i < monsterGroupVector.length; i++) {
 			monsterVector[i] = [];
 			for (var j = 0; j < monsterGroupVector[i].length; j++) {
 				var value = monsterGroupVector[i][j];


 				for(var k = 0; k < value; k++){

					var level = j + 1;
					var node = new Monster(level);

					this.addChild(node);

					node.setAnchorPoint(0,0);
					node.setPosition( GC.w  + groupWidth, GC.landHeight);
					groupWidth = groupWidth + node.getBoundingBox().width + GC.DISTANCE_BETTWEN_MONSTER;

					monsterVector[i].push(node);

					// if( (i == monsterGroupVector.length-1) && (j == monsterGroupVector[i].length-1) && (k == value-1)){
						this.endPos = node;
					// }
 				}

 				if(j == monsterGroupVector[i].length - 1){
 					if(i <  monsterGroupVector.length-1){
 						var node = new cc.Sprite(res.temple);
 						node.setScale(GC.SCALE_RATE);
 						this.temple.addChild(node,-1-i);
 						node.setAnchorPoint(0,0);
 						node.tag = i
 						node.setPosition( GC.w  + groupWidth  , GC.landHeight);

 						groupWidth = groupWidth + node.getBoundingBox().width+ GC.DISTANCE_BETTWEN_MONSTER;

 						if (i==0) {
 							var layer = new GPUpgradeSiteLayer();
 							node.addChild(layer);

 							layer.setPosition(cc.p(node.getContentSize().width/2,65));
 							layer.originX = layer.getPositionX();
 							this.upgradeSite = layer;
 						};
 					}

 				}
 			};

 		};

 	},
 	loadHero : function() {
 		var posX = 0;

 		var heroObj = new Hero();

 		heroObj.setPosition(GC.w2-300, GC.landHeight);
 		heroObj.setAnchorPoint(0,0);
 		this.addChild(heroObj);


 		GameManager.getInstance().setHeroObj(heroObj);
 		GameManager.getInstance().getCharacterVector().push(heroObj);

 		var node = new Partner(GC.PARTNER_TYPE.TANG_SENG);

 		node.setPosition(GC.PARTNER_DIS.RIGHT[0], 0);
 		node.setAnchorPoint(0,0);
 		heroObj.addChild(node,-2);
 		GameManager.getInstance().getCharacterVector().push(node);


 		var node = new Partner(GC.PARTNER_TYPE.ZHU_BA_JIE);

 		node.setPosition(GC.PARTNER_DIS.RIGHT[1], 0);
 		node.setAnchorPoint(0,0);
 		heroObj.addChild(node,-3);
 		GameManager.getInstance().getCharacterVector().push(node);


 		var node = new Partner(GC.PARTNER_TYPE.SHA_SENG);

 		node.setPosition(GC.PARTNER_DIS.RIGHT[2], 0);
 		node.setAnchorPoint(0,0);
 		heroObj.addChild(node,-4);
 		GameManager.getInstance().getCharacterVector().push(node);

 	},
 	bindTouchListener : function() {
 		var listener = cc.EventListener.create({
 		    event           : cc.EventListener.TOUCH_ONE_BY_ONE,
 		    target          : this,
 		    swallowTouches  : true,
 		    onTouchBegan    : this.onTouchBegan,
 		    onTouchMoved    : this.onTouchMoved,
 		    onTouchEnded    : this.onTouchEnded
 		});
 		cc.eventManager.addListener(listener, this);
 	},

 	// 事件[触摸开始]
 	onTouchBegan: function (touch, event) {
 		var location = touch.getLocation();

 		var heroObj = GameManager.getInstance().getHeroObj();

 		heroObj.setIsMove(true);
 		var CenterX = heroObj.x + heroObj.getBoundingBox().width/2;

 		if(location.x > CenterX){

 			heroObj.setDirection(GC.CHARACTER_DIRECTION.RIGHT);
 		}else {

 			heroObj.setDirection(GC.CHARACTER_DIRECTION.LEFT);

 		}
 		var dis = Math.abs(location.x - CenterX);
 		var percent = (dis > GC.touchDistance  ? GC.touchDistance  : dis) /GC.touchDistance ;

 		heroObj.setSpeed(percent);

 	    return true;
 	},

 	// 事件[触摸移动]
 	onTouchMoved: function (touch, event) {
 		var location = touch.getLocation();
 		var heroObj = GameManager.getInstance().getHeroObj();
 		var CenterX = heroObj.x + heroObj.getBoundingBox().width/2;

 		var dis = Math.abs(location.x - CenterX);
 		var percent = (dis >  GC.touchDistance  ?  GC.touchDistance  : dis) / GC.touchDistance ;


 		heroObj.setSpeed(percent);

 		if(location.x > CenterX){

 			heroObj.setDirection(GC.CHARACTER_DIRECTION.RIGHT);
 		}else {

 			heroObj.setDirection(GC.CHARACTER_DIRECTION.LEFT);

 		}
 	},

 	// 事件[触摸结束]
 	onTouchEnded: function (touch, event) {
 	    var target = this.target;
 	    var heroObj = GameManager.getInstance().getHeroObj();
 	    var p = GameManager.getInstance().getParallaxLayer();
 	    var monsterVector = GameManager.getInstance().getMonsterVector();

 	    heroObj.setIsMove(false);

 	    function func_a(obj){
 	    	var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? -1 : 1;

 	    	var moveDis  = GC.RECOIL_DISTANCE;
 	    	if(dir == -1){
 	    		if(this.totalOffset < GC.RECOIL_DISTANCE){
 	    			moveDis = this.totalOffset - GC.w2;
 	    		}
	 	    	
 	    	}

 	    	var moveNum = dir*moveDis*heroObj.getSpeed()/GC.HERO_SPEED
 	    	if(p.getPositionX() + moveNum > 0){
 	    		moveNum = -p.getPositionX()
 	    		cc.log("monsterdddddd")
 	    	}


 	    	var action1 = cc.moveBy(GC.RECOIL_TIME1,cc.p(moveNum,0));
 	    	// action1.easing(cc.easeExponentialOut());
 	    	action1.easing(cc.easeSineOut());

 	    	 
 	    	var callBack = cc.callFunc(function(){
 	    		// if(p.getPositionX() <= 0){
 	    		// 	var action2 = cc.moveBy(GC.RECOIL_TIME2,GC.w2 - heroObj.getPositionX(),0)
 	    		// 	// action2.easing(cc.easeExponentialOut());
 	    		// 	action2.easing(cc.easeSineOut());

 	    		// 	this.runAction(action2);
 	    		// }

 	    	}.bind(obj));

 	    	var action = cc.sequence(action1,callBack);

 	    	obj.runAction(action);
 	    }

 	    // cc.log("this.totalOffset  "  + target.totalOffset )

 	    if(target.totalOffset > 0 ){
	 	//     func_a(heroObj);

	 	//     for (var i = 0; i < monsterVector.length; i++){
	 	//     	for (var j = 0; j < monsterVector[i].length; j++) {
	 	//     		 var monster = monsterVector[i][j];
	 	//     		 func_a(monster);
	 	//     	}
			// }
			// func_a(target.temple);
			// func_a(p);
 	    }

 	},
 	//我方角色与怪物的碰撞检测
 	checkMonsterCollision : function(){
 		var heroObj = GameManager.getInstance().getHeroObj();
 		var monsterVector = GameManager.getInstance().getMonsterVector();

 		var heroRect = heroObj.getCollisionRect();

 		var isIntersect = false;

 		for (var j = 0; j < monsterVector.length; j++){

 			for (var k = 0; k < monsterVector[j].length; k++){
 				var monster = monsterVector[j][k];

 				if (!monster.getIsDeath())
 				{
 					var monsterRect = monster.getCollisionRect();

 					var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;


 					if(cc.rectIntersectsRect(heroRect,monsterRect)){
 					    // cc.log("Intersect!");

 					    var m = monster;

 					    var isDeath = monster.onHit(heroObj.getAttack(),dir);
 					    heroObj.onHit(m.getAttack(),monster.getIsDeath());
 					    isIntersect = true;

 					    EffectManager.getInstance().playCommonAttFontEffect(heroObj.getAttack(),monster);


 					   EffectManager.getInstance().playHitMonsterEffect();
 					   // EffectManager.getInstance().playEatMoneyEffect();

 					   if (isDeath) {
	 					   	this.createGoldNode(GameManager.getInstance().getGold());
 					   };
 					   break
 					}
 				}
 			}

 			if (isIntersect) { isIntersect = false; break};

 		}
 	},
 	checkTempleCollision : function(){
 		var heroObj = GameManager.getInstance().getHeroObj();
 		var monsterGroupVector = this.gameManager.getMonsterGroupVector();
 		var isIntersect = false;
 		for (var i = 0; i < monsterGroupVector.length-1; i++) {
 			var node = this.temple.getChildByTag(i);

 			var heroRect = heroObj.getCollisionRect();

 			// var nodePos = node.getPosition();
 			var nodePos = node.getParent().convertToWorldSpace(node.getPosition())

			var nodeRect = cc.rect(
			    nodePos.x ,
			    nodePos.y ,
			    node.getBoundingBox().width,
			    node.getBoundingBox().height
			);

 			if(cc.rectIntersectsRect(heroRect,nodeRect)){
 				// cc.log("Intersect")
 				isIntersect = true;
 				this.upgradeSite.setPositionX(this.upgradeSite.originX + ((node.getPositionX() - this.temple.getChildByTag(0).getPositionX())/GC.SCALE_RATE));

 				break
			}
		}

		if(!isIntersect){
			this.upgradeSite.setVisible(false);
		}else{
			this.upgradeSite.setVisible(true);
		}
 	},
 	checkCollision : function(){
 		this.checkMonsterCollision();
 		this.checkTempleCollision();
 	},
 	// 唐僧 猪八戒 沙僧影子效果
 	partnerFollow  :function(dt){
 		var heroObj = GameManager.getInstance().getHeroObj();

 		if(heroObj.getIsMove() ){
 			var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;

			var cVector = GameManager.getInstance().getCharacterVector();

			for (var i = 0; i < cVector.length; i++) {
				var node = cVector[i];
				if(i == 0){
				}else{
					if(!node.isDone){
						var tmp = cVector[0].getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? "RIGHT": "LEFT";
						var pos = GC.PARTNER_DIS[tmp][i-1]

						if(node.getPositionX() != pos){
							var nodeDir = (node.getPositionX()>pos) ? -1 : 1;

							var direction = nodeDir==-1 ? GC.CHARACTER_DIRECTION.LEFT : GC.CHARACTER_DIRECTION.RIGHT;

							var dis = node.getPositionX() + heroObj.getSpeed() * dt*nodeDir*0.5;
							if( nodeDir > 0 && dis > pos){
								dis = pos;
								node.setDirection(cVector[0].getDirection());

							}else if( nodeDir < 0 && dis < pos){
								dis = pos;
								node.setDirection(cVector[0].getDirection());

							}else{
								node.setDirection(direction);
							}
							node.setPositionX( dis);
						}
					}
				}
			}
 		}
 	},
 	wukongRunning : function(dt){
 		var heroObj = GameManager.getInstance().getHeroObj();
 		var monsterVector = GameManager.getInstance().getMonsterVector();
 		var begin_h2mPosx = monsterVector[0][0].convertToNodeSpace(heroObj.getPosition()).x ;
 		var end_h2mPosx = this.endPos.convertToNodeSpace(heroObj.getPosition()).x ;

 		if(heroObj.getIsMove()){

 			if(heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT && heroObj.getPositionX() < GC.w2 || heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT && heroObj.getPositionX() <= GC.w - heroObj.getBoundingBox().width && end_h2mPosx*4 >= 0  || heroObj.getDirection() == GC.CHARACTER_DIRECTION.LEFT && heroObj.getPositionX() > GC.w2 || heroObj.getDirection() == GC.CHARACTER_DIRECTION.LEFT && monsterVector[0][0].getPositionX() >=GC.w && heroObj.getPositionX() > 0 ){
 				var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;

 				var posX =  heroObj.getPositionX() +  heroObj.getSpeed() * dt*dir*0.5;

 				if(posX < 0 ){
 					posX = 0
 				}

 				heroObj.setPositionX(posX);
 			}
 		
 		}
 	},
 	templeMoving : function(dt){
 		var heroObj = GameManager.getInstance().getHeroObj();

 		var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;
 		this.temple.setPositionX(this.temple.getPositionX() - heroObj.getSpeed() * dt*dir);
 	},
 	monstersRunning : function(dt){
 		var heroObj = GameManager.getInstance().getHeroObj();
 		var monsterVector = GameManager.getInstance().getMonsterVector();

		var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;
		for (var j = 0; j < monsterVector.length; j++){
			for (var k = 0; k < monsterVector[j].length; k++){
				var monster = monsterVector[j][k];
				monster.setPositionX( monster.getPositionX() -  heroObj.getSpeed() *dt*dir);

				if(monster.getPositionX() >= (GC.w ) || monster.getPositionX() <= -monster.getBoundingBox().width ){
					if(monster.isVisible() == false) {
						if(monster.getPositionX() < heroObj.getPositionX()){
							monster.setDirection(GC.CHARACTER_DIRECTION.RIGHT);
						}else{
							monster.setDirection(GC.CHARACTER_DIRECTION.LEFT);
						}

						monster.reset();
					}	
				}
			}

		}
 					
 	},
 	skyAndGroundRecycle : function(){

 		function recycle(obj){
 			var heroObj = GameManager.getInstance().getHeroObj();

 			for (var i = 0; i < obj.length; i++) {
 				var node = obj[i]
 				var nodeX = node.getParent().convertToWorldSpace(node.getPosition()).x

 				if(heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT){

 					if(nodeX <= -node.getBoundingBox().width ){
 						node.setPositionX(node.getPositionX() + node.getBoundingBox().width*node.totalNum);
 					}
 				}else{
 					if(nodeX >= node.getBoundingBox().width*(node.totalNum - 1)) {
 						node.setPositionX(node.getPositionX() - node.getBoundingBox().width*node.totalNum);
 					}
 				}

 			};
 		}


 		var sky = GameManager.getInstance().getSky();
 		var ground = GameManager.getInstance().getGround();

 		recycle(sky);
 		recycle(ground);
 	},
 	bgTreeRecycle : function(){
 		var heroObj = GameManager.getInstance().getHeroObj();

 		var tree2Vector = GameManager.getInstance().getTree2Vector();

 		for (var i = 0; i < tree2Vector.length; i++) {
 			var treex = tree2Vector[i].getParent().convertToWorldSpace(tree2Vector[i].getPosition()).x ;

 			if(heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT){
 				if(treex <= -tree2Vector[i].getBoundingBox().width/2 ){
 					var pos = tree2Vector[i].getParent().convertToNodeSpace(cc.p(GC.w,0));
 					tree2Vector[i].setPositionX(pos.x+tree2Vector[i].getBoundingBox().width/2);
 				}
 			}else{
 				if(treex >= GC.w + tree2Vector[i].getBoundingBox().width/2 ){
 					var pos = tree2Vector[i].getParent().convertToNodeSpace(cc.p(0,0));
 					tree2Vector[i].setPositionX(pos.x-tree2Vector[i].getBoundingBox().width/2);
 				}
 			}
 		}
 	},
 	backgroudMoving : function(dt){
 		var heroObj = GameManager.getInstance().getHeroObj();
 		var p = GameManager.getInstance().getParallaxLayer();

 		var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;
 		p.setPositionX( p.getPositionX()-  heroObj.getSpeed() *dt*dir);
 		if(p.getPositionX() > 0){
 			p.setPositionX(0);
 		}
 	},
 	monsterRunningAndBgMoving : function(dt){
 		var heroObj = GameManager.getInstance().getHeroObj();
 		var monsterVector = GameManager.getInstance().getMonsterVector();

 		var begin_h2mPosx = monsterVector[0][0].convertToNodeSpace(heroObj.getPosition()).x ;
 		var end_h2mPosx = this.endPos.convertToNodeSpace(heroObj.getPosition()).x ;

 		if(heroObj.getIsMove() &&  ( (heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT && begin_h2mPosx*4 >= -GC.w2-200 && end_h2mPosx*4 <= GC.w2 ) || (heroObj.getDirection() == GC.CHARACTER_DIRECTION.LEFT && monsterVector[0][0].getPositionX() <GC.w) ) ){

 			// 寺庙的移动
 			this.templeMoving(dt);
 			//怪物的移动
 			this.monstersRunning(dt);
 			//背景层天空和地板的循环利用
 			this.skyAndGroundRecycle();
			//背景视差移动
			this.backgroudMoving(dt);
			//背景树的循环
			this.bgTreeRecycle();
			// 前景视差
			GameManager.getInstance().foreParallaxLayer.update(dt);

			var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;
			this.totalOffset = this.totalOffset  +  heroObj.getSpeed() * dt*dir;
 		}
 	},
 	// 更新[游戏逻辑]
 	update : function(dt){
 		//检测碰撞
 		this.checkCollision();
 		// 唐僧 猪八戒 沙僧影子效果
 		this.partnerFollow(dt);
 		// 悟空奔跑
 		this.wukongRunning(dt);
 		// 怪物奔跑以及背景移动
 		this.monsterRunningAndBgMoving(dt);

 	}
 });