/**
 * Created by wangzhigang on 15/8/28.
 */

var Monster = cc.Sprite.extend({
	level   : null,

	hpBar : null,

	originPosX : 0,
	offsetX1 : 0,
	hpMax : 0,
	hp  : 0,
	attack : 0,
	gold   : 0,

	isDeath : false,
	direction	: GC.CHARACTER_DIRECTION.LEFT,
	ctor : function(level){
		this._super(res["mst01_lv" + level + "_l_standby01"]);

		this.loadConfig(level);
		this.loadHpBar();
	    this.loadAnimation();
	    

	    return true;
	},
	loadConfig : function(level) {
		this.level = level;
		var config =  GameManager.getInstance().getMonsterInfo()[this.level - 1];

		this.hp     =   config.hp;
		this.hpMax   = this.hp;
		this.attack = config.attack;
		this.gold   = config.gold;


		this.isDeath = false;
		this.setScale(GC.SCALE_RATE);


	},
	setOriginPosX : function(x) {
		this.originPosX = x;

	},
	loadAnimation : function() {
		this.stopActionByTag(998);


		var dir = this.direction == GC.CHARACTER_DIRECTION.RIGHT ? "r" : "l";
		var prefix =  "mst01_lv" + this.level + "_"+ dir + "_standby0" ;
		this.setTexture(res[prefix + 1]);


		var animation = cc.Animation.create();  //利用动画保存每一帧的图片


		for (var i = 1; i <= 4; i++) {
			animation.addSpriteFrameWithFile(res[prefix+ i]);
		};

		animation.setDelayPerUnit(0.1);  //每一帧播放的间隔
		var animate = cc.animate(animation).repeatForever();
		animate.tag = 998;
		this.runAction(animate);
		this.setAnchorPoint(0,0);
		
	},
	loadHitAnimation : function() {
		this.stopActionByTag(998);
		var dir = this.direction == GC.CHARACTER_DIRECTION.RIGHT ? "r" : "l";
		var prefix =  "mst01_lv" + this.level + "_"+ dir + "_hit01" ;
		this.setTexture(res[prefix]);

	},
	loadHpBar : function() {
		var Bar = new cc.Node();

		var node = new cc.Sprite(res.ui_hp_bg);
		node.setAnchorPoint(0,0);
		Bar.addChild(node);

		var node = new cc.Sprite(res.ui_hp_enemy);
		node.setAnchorPoint(0,0);
		Bar.addChild(node)

		Bar.setPosition(this.getContentSize().width/2 - node.getContentSize().width/2,GC.HP_BAR_HIGHT);
		this.addChild(Bar)

		this.hpBar = node;
		this.hpBg = Bar
	},
	setHpBar : function() {
		var percent = this.hp/this.hpMax;
		if(percent > 0){
			this.hpBar.setScaleX(percent);
		}else{
			this.hpBar.setScaleX(0);
		}
	},
	reset : function() {
		this.setVisible(true);
		this.setIsDeath(false);
		this.setPositionX(this.getPositionX()-this.offsetX1);
		this.offsetX1 = 0;
		this.loadAnimation();
	},
	setIsDeath : function(status) {
		this.isDeath = status;
	},
	getIsDeath : function() {
		return this.isDeath;
	},
	setDirection : function(dir) {
		if(this.direction != dir){
			this.direction = dir;
			this.loadAnimation();
		}
	},
	getAttack : function() {
		return this.attack;
	},
	onHit : function(att,dir) {
		var isDeath = false;

		this.hp = this.hp - att;

		if(this.hp <= 0){
			isDeath = true;
			GameManager.getInstance().addGold(this.gold);

			EffectManager.getInstance().playMonsterDeathEffect();

			this.setIsDeath(true);
			this.setHpBar();

			this.offsetX1 = this.offsetX1 + dir*100;
			this.loadHitAnimation();

			var move = cc.moveBy(0.05,cc.p(100*dir,0));
			var callBack = cc.callFunc(function(){
				this.setVisible(false);
				this.hp = this.hpMax;

				this.setHpBar();
			}.bind(this));

			var action = cc.sequence(move, callBack);
			this.runAction(action);
		}else{
			this.stopActionByTag(10000);

			this.setHpBar();
			this.loadHitAnimation();

			var action = cc.delayTime(0.1);

			var callBack = cc.callFunc(function(){
				this.loadAnimation();
			}.bind(this));

			var saction = cc.sequence(action,callBack)
			saction.tag = 10000;

			this.runAction(saction);

		}
		return isDeath;
	},
	getCollisionRect : function(){
		var monsterPos = this.getPosition();

		return cc.rect(
		    monsterPos.x ,
		    monsterPos.y ,
		    this.getBoundingBox().width,
		    this.getBoundingBox().height);
	}

});