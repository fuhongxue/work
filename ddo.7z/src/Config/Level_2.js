/**
 * Created by wangzhigang on 15/8/28.
 */

 var Level2 = {
 	groups : [
 		//1,2,3,4级怪以及boss数量
	 	[4,0,0,0,0], 
	 	[5,2,0,0,0],
	 	[5,3,0,0,0],
	 	[4,3,4,0,0],
	 	[2,3,3,3,0],
	 	[2,2,3,4,0],
	 	[2,2,4,4,1],

 	],
 	monster : [
 		{
 			hp  : 1,
 			attack : 1,
 			gold   : 1
 		},
 		{
 			hp  : 2,
 			attack : 1,
 			gold   : 2
 		},
 		{
 			hp  : 9,
 			attack : 2,
 			gold   : 3
 		},
 		{
 			hp  : 12,
 			attack : 2,
 			gold   : 4
 		},
 		// BOSS
 		{
 			hp  : 25,
 			attack : 4,
 			gold   : 12
 		},
 	]
 }
