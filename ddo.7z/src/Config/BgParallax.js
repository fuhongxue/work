/**
 * Created by wangzhigang on 15/9/17.
 */

 /*
  * type: foreword backward
  * loop: time sigle multiple
  * loopValue: 0.5 
 */

 var BgParallax = {
 	type1 : {
 		foreword : [
	 		// {
	 		// 	name : "ctr1",
	 		// 	ratio : 0.8,
	 		// 	loop : "sigle",
	 		// 	posVector : [1000,2500,4000],
	 		// },
	 		{
	 			name : "cr2",
	 			ratio : 1.0,
	 			loop : "sigle",
	 			posVector : [1000,5500,7500,8500],
	 		},
 		],
 		backward : [
	 		// {
	 		// 	name : "ground1"
	 		// 	loop : "multiple",
	 		// 	amount :  10,
	 		// },
	 		{
	 			name : "road1",
	 			ratio : 1.0,
	 			loop : "multiple",
	 			amount :  10,
	 		},
 		],

 		
 	}
 }