
/**
 * Created by wangzhigang on 15/9/11.
 */

 var EffectManager = (function(){
 	function _EffectManager(){
 		this.playCommonAttFontEffect = function(value){
 			var pNode = Common.createFontNode(value,1);

 			GameManager.getInstance().GPMainLayer.addChild(pNode);

 			var action1 = cc.moveBy(0.5,cc.p(0,50));
 			var action2 = cc.fadeOut(0.5);
 			var action3 = cc.moveBy(1,cc.p(0,80));
 			var callBack = cc.callFunc(function(){
 				this.removeAllChildrenWithCleanup(true)
 				this. removeFromParent(true);
 			}.bind(pNode));

 			// pNode.setCascadeColorEnabled(true);
 			pNode.setCascadeOpacityEnabled(true);
 			pNode.setPosition(cc.p(GC.w2,GC.h2));
 			pNode.setScale(4);
 			pNode.runAction(cc.sequence(action1,cc.spawn(action2,action3) ,callBack));
 		};
 		// this.playWeaponEffect = function(){
 		// 	var heroObj = GameManager.getInstance().getHeroObj();
 		// 	var weapon = heroObj.getWeapon();

 		// 	var heroObj = GameManager.getInstance().getHeroObj();
 		// 	var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;

 		// 	var node = Common.createAnimateNode(5,"Attaca0");
 		// 	var posX = 0;
 		// 	if(heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ){
 		// 		posX = (heroObj.getContentSize().width+weapon.getContentSize().width)*dir
 		// 	}else{
 		// 		posX = (weapon.getContentSize().width)*dir
 		// 	}

 		// 	heroObj.addChild(node);
 		// 	node.setPosition(cc.p(posX,15));

 		// 	node.setRotation(180)

 		// };
 		this.playHitMonsterEffect = function(){
 			var heroObj = GameManager.getInstance().getHeroObj();
 			var weapon = heroObj.getWeapon();

 			var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;

 			var node = Common.createAnimateNode(8,"efhita0");
 			var posX = 0;
 			if(heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ){
 				posX = (heroObj.getContentSize().width+weapon.getContentSize().width)*dir
 			}else{
 				posX = (weapon.getContentSize().width)*dir
 			}

 			heroObj.addChild(node);
 			node.setPosition(cc.p(posX,15));
 		};
 		this.playMonsterDeathEffect = function(){
 			var heroObj = GameManager.getInstance().getHeroObj();
 			var weapon = heroObj.getWeapon();

 			var heroObj = GameManager.getInstance().getHeroObj();
 			var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;


 			var node = Common.createAnimateNode(8,"efdeidboom0");
 			var posX = 0;
 			if(heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ){
 				posX = (heroObj.getContentSize().width+weapon.getContentSize().width + 20)*dir
 			}else{
 				posX = (weapon.getContentSize().width + 20)*dir
 			}

 			heroObj.addChild(node);
 			node.setPosition(cc.p(posX,15));
 		};
 		this.playEatMoneyEffect = function(){
 			var heroObj = GameManager.getInstance().getHeroObj();
 			var weapon = heroObj.getWeapon();

 			var heroObj = GameManager.getInstance().getHeroObj();
 			var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;


 			var node = Common.createAnimateNode(6,"eat_moneyb0");
 			var posX = 0;
 			if(heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ){
 				posX = (heroObj.getContentSize().width+weapon.getContentSize().width + 20)*dir
 			}else{
 				posX = (weapon.getContentSize().width + 20)*dir
 			}

 			heroObj.addChild(node);
 			node.setPosition(cc.p(posX,15));

 		};
 	}

 	var instance;

 	var _static = {
 		name : "EffctManager",

 		getInstance: function(){
 			if (instance === undefined) {
 			    instance = new _EffectManager();
 			}
 			return instance;
 		}
 	};
 	return _static;
 })();