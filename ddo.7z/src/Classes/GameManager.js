/**
 * Created by wangzhigang on 15/4/19.
 */

// 游戏管理对象，单例类
var GameManager = (function () {

    function _GameManager() {
	
        // 英雄对象
        this.heroObj = null;
        this.parallaxLayer = null;
        // 树对象的集合
        this.tree2Vector = null;
        //云对象的集合
        this.skyVector = [];
        //树的背景土地集合
        this.groundVector = [];
        //角色对象集合
        this.characterVector = [];


        this.Tree2 = null;
        //二维数组 第一维表示第几波 第二维表示具体对象
        this.monsterVector = [];  
        //阶段间怪物的距离
        this.monsterDisVector = [];

        //配置信息
        this.monsterGroupInfo = [];
        this.monsterInfo = [];
        this.characterInfo = [];

        //动态数据
        // 玩家拥有的金币值
        this.gold = 0;
        // 玩家的等级
        this.characterLevel = [0,0,0,0];

        //角色对象信息 
        this.characterData = {
            hp : 0,
            hpMax : 0,
            attack : 0,
            needGold : 0,
        };

        this.clear = function(){
            this.monsterVector = [];
            this.characterVector = [];
        };

        // ==============[getter && setter]==============
        this.setHeroObj = function(heroObj) {
           this.heroObj = heroObj;
        };
        this.getHeroObj = function() {
             return this.heroObj;
        };
        this.setParallaxLayer = function(obj) {
            this.parallaxLayer = obj;
        };
        this.getParallaxLayer = function() {
            return this.parallaxLayer;
        };
        this.setTree2Vector = function(obj) {
            this.tree2Vector = obj;
        };
        this.getTree2Vector = function() {
            return this.tree2Vector;
        };
        this.setTree2 = function(obj) {
            this.Tree2 = obj;
        };
        this.getTree2 = function() {
            return this.Tree2;
        };
        this.getMonsterVector = function() {
            return this.monsterVector;
        };
        this.getMonsterGroupVector = function() {
            return this.monsterGroupInfo;
        };
        this.setMonsterDisVector = function(obj) {
            this.monsterDisVector = obj;
        };
        this.getMonsterDisVector = function() {
            return this.monsterDisVector;
        };
        this.getCharacterInfo = function() {
            return this.characterInfo;
        };
        this.getMonsterInfo = function() {
            return this.monsterInfo;
        };

        this.setSky = function(obj) {
            this.skyVector = obj;
        };
        this.getSky = function() {
            return this.skyVector;
        };
        this.getGround = function() {
            return this.groundVector;
        };
        this.getCharacterData = function(){
            return this.characterData;
        };
        this.getCharacterVector = function() {
            return this.characterVector;
        };
        this.getGold = function(){
            return this.gold;
        };
        this.addGold = function(value){
            this.gold = this.gold  +  value;
        };
        this.getCharacterLevel = function(){
            return this.characterLevel;
        };
        this.getHeroNeedGold = function(){
            var level = this.characterLevel[0];
            var config = this.characterInfo[0]["config"];
            return config[level + 1] ? config[level + 1][2] : 0;
        };

	}

	//实例容器
    var instance;

    var _static = {
        name: 'GameManager',
        //获取实例的方法
        //返回Singleton的实例
        getInstance: function () {
            if (instance === undefined) {
                instance = new _GameManager();
            }
            return instance;
        }
    };
    return _static;
})();