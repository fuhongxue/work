
var EquipDataManager = (function(){
	function _EquipDataManager(){
		this.curSortedArr = [];
		this.clear = function(){
			this.curSortedArr = [];
		},
		this.getUnlockCharacterNum = function(){
			var unlockStatus = GameManager.getInstance().localData.skillUnlockStatus;
			var num = 0;

			for(var v in unlockStatus){
				if(unlockStatus[v] == 2){
					num = num + 1;
				}
			}

			return num;
		},
		this.getBaseAttrData = function(index){
			var arr = [];

			var fArr = ["血","攻","暴","防","韧","闪","命","速"];

			var item = this.curSortedArr[index];

			for (var i = 0; i < item.baseArr.length; i++) {
				var bItem = item.baseArr[i];


				arr[i] = [fArr[i],bItem];
			};
		},	
		this.EquipArrSortedByVariety = function(type){
			this.curSortedArr = [];

			var equipArr = GameManager.getInstance().localData.equipArr;
			cc.log("equipArr num :" + equipArr.length)
			for (var i = 0; i < equipArr.length; i++) {
				var item = equipArr[i];

				cc.log("variety ::" + item.variety)
				if (item.variety == type) {
					this.curSortedArr.push(item);
				};
			};
		},
		this.getEquipNum = function(){
			return this.curSortedArr.length;
		}
	}

	//实例容器
    var instance;
	var _static = {
		name : "EquipDataManager",

		getInstance: function(){
			if (instance === undefined) {
			    instance = new _EquipDataManager();
			}
			return instance;
		}
	};
	return _static;

})();