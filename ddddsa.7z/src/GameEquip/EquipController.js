
var EquipController = (function(){
	function _EquipController(){
		this.mainLayer = null;

		this.characterItemClick = function(index){
			this.mainLayer.resetItemStatus(index);
		},
		this.enterEquipUI = function(){
			EquipDataManager.getInstance().clear();
			EquipDataManager.getInstance().EquipArrSortedByVariety(0);
			cc.director.runScene(new GameEquipScene());
		}
	}


	//实例容器
    var instance;
	var _static = {
		name : "EquipController",

		getInstance: function(){
			if (instance === undefined) {
			    instance = new _EquipController();
			}
			return instance;
		}
	};
	return _static;

})();