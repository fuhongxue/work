
var GameEquipLayer = cc.Layer.extend({
    backgroundLayer : null,
    mainLayar : null,
    foreParallaxLayer : null,
    ctor:function () {
        this._super();
        
        this.loadBackground();
        this.loadMainLayer();
        return true;
    },
    loadBackground : function(){
        this.backgroundLayer = new GEBackgroundLayer();
        this.addChild(this.backgroundLayer);
    },
    loadMainLayer : function(){
        this.mainLayar = new GEMainLayer();
        this.addChild(this.mainLayar);

        EquipController.getInstance().mainLayer = this.mainLayar;
    },
});

var GameEquipScene = cc.Scene.extend({
    onEnter:function () {
        this._super();
        var layer = new GameEquipLayer();
        this.addChild(layer); 
    }
});