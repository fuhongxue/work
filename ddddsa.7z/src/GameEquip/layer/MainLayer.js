
var resArr = [
	[res.btn_wukong01,res.btn_wukong02,"EquipWukongView"],
	[res.btn_tangseng01,res.btn_tangseng02,"EquipTangsengView"],
	[res.btn_bajie01,res.btn_bajie02,"EquipBajieView"],
	[res.btn_shaseng01,res.btn_shaseng02,"EquipShasengView"],
]

var GEMainLayer =  cc.Layer.extend({
	cItemArr : [],
	cTableViewArr : [],
	ctor : function(){
		this._super();
		this.loadConfig();

		this.loadBackItem();
		this.loadGoldUI();
		this.loadStarUI();
		this.loadCharacterItem();


		// var blocks_scaled_with_insets = new cc.Scale9Sprite(res.frame_bg093);
		// blocks_scaled_with_insets.width = 4 * 250;
		// blocks_scaled_with_insets.height = 32*10 ;
		// cc.log("... setContentSize");

		// blocks_scaled_with_insets.x = GC.w2;
		// blocks_scaled_with_insets.y = GC.h2;

		// this.addChild(blocks_scaled_with_insets)

	},
	loadConfig : function(){
		this.cItemArr = [];
		this.cTableViewArr = [];
	},
	loadGoldUI : function(){
		var node = new cc.Sprite(res.ui_biggoldcoin);
		node.x = GC.w2 - 200;
		node.y = GC.h - 30;
		this.addChild(node);

		var pNode = Common.createFontNode(GameManager.getInstance().getGold(),3);

		this.addChild(pNode);
		pNode.setPosition(cc.p(GC.w2-160,GC.h - 30));
		pNode.setScale(4);
	},
	loadStarUI : function(){
		var node = new cc.Sprite(res.starbig_03);
		node.x = GC.w2 + 200;
		node.y = GC.h - 30;
		this.addChild(node);

		var pNode = Common.createFontNode(GameManager.getInstance().getStarNum(),3);

		this.addChild(pNode);
		pNode.setPosition(cc.p(GC.w2+240,GC.h - 30));
		pNode.setScale(4);
	},
	resetItemStatus : function(index){
		for (var i = 0; i < this.cItemArr.length; i++) {
			var node = this.cItemArr[i];
			var tbView = this.cTableViewArr[i];

			if (node.index == index) {
				node.setTexture(resArr[i][0]);
				tbView.setVisible(true);
			}else{
				node.setTexture(resArr[i][1]);
				tbView.setVisible(false);
			}
		};
	},
	loadCharacterItem : function(){

		var num = EquipDataManager.getInstance().getUnlockCharacterNum();
		cc.log("num :::" + num);
		for (var i = 0; i < 4; i++) {
			var resName = resArr[i][1]

			var node = new cc.Sprite(resName);
			node.x = GC.w - 40;
			node.y = GC.h -20 - 130*(i+1);
			this.addChild(node);

			node.index = i;

			this.cItemArr.push(node);

			var tbClass = eval(resArr[i][2]);
			var tbLayer = new tbClass();
			this.addChild(tbLayer)
			this.cTableViewArr.push(tbLayer);

			var listener = cc.EventListener.create({
			    event           : cc.EventListener.TOUCH_ONE_BY_ONE,
			    swallowTouches  : true,
			    onTouchBegan    : function (touch, event) {
		    		var target = event.getCurrentTarget();

		    		var locationInNode = target.convertToNodeSpace(touch.getLocation());
		    		var s = target.getContentSize();
		    		var rect = cc.rect(0, 0, s.width, s.height);

		    		if (cc.rectContainsPoint(rect, locationInNode)) {
		    			EquipController.getInstance().characterItemClick(target.index);
		    		    return true;
		    		}

		        	return false;
		    	},
			});
			cc.eventManager.addListener(listener, node);
		};

		this.resetItemStatus(0);
	},
	loadBackItem : function(){
		var nodeNormal    = new cc.Sprite(res.btn_back04);
		var nodeSelected  = new cc.Sprite(res.btn_back03);
		var nodeDisabled  = new cc.Sprite(res.btn_back04);

		var node = new cc.MenuItemSprite(
		nodeNormal,
		nodeSelected,
		nodeDisabled,
		function(){
			cc.director.runScene(new ChooseLevelScene());
		}.bind(this));

		node.x = GC.w - 50;
		node.y = GC.h - 50;

		var menu = new cc.Menu();
		menu.setPosition(0, 0);
		menu.addChild(node);
		this.addChild(menu);
	},
	
});