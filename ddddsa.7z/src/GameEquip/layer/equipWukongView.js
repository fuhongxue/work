

var EquipWukongView = cc.Layer.extend({
	ctor : function(){
		this._super();
		this.loadTableView();
	},
	loadTableView : function(){
		var tableView = new cc.TableView(this, cc.size(260*4 + 5, GC.h));
		tableView.setDirection(cc.SCROLLVIEW_DIRECTION_HORIZONTAL);
		tableView.x = 10;
		tableView.y = 70;
		tableView.setDelegate(this);
		this.addChild(tableView);
		tableView.reloadData();
		// tableView.setContentOffset(cc.p(-2000,0))
	},
	scrollViewDidScroll:function (view) {

	},
	scrollViewDidZoom:function (view) {
		cc.log("scrollViewDidZoom")
	},

	tableCellTouched:function (table, cell) {
	    cc.log("cell touched at index: " + cell.getIdx());
	},
	tableCellTouched2:function () {
	    cc.log("cell touched at index: ");
	},
	tableCellSizeForIndex:function (table, idx) {
	     return cc.size(260, 100);
	},
	tableCellAtIndex:function (table, idx) {
	    var strValue = idx.toFixed(0);
	    var cell = table.dequeueCell();
	    var label;
	    if (!cell) {
	        cell = new CustomTableViewCell();

	        this.loadBg(cell,idx);
	        this.loadEquipedBtn(cell);
	        this.loadUnloadBtn(cell);
	    }
	    this.loadEquipBg(cell,idx);
	    this.loadEquipUI(cell,idx);
	    this.loadBaseAttr(cell,idx);

	    return cell;
	},
	numberOfCellsInTableView:function (table) {
		var value = EquipDataManager.getInstance().getEquipNum();
	    return value;
	},
	loadBaseAttr : function(cell,idx){
		var node = new cc.LabelBMFont("血: 100050", res.dyfont08);
		node.anchorX = 0;
		node.anchorY = 0;
		node.x = 40;
		node.y = 300;
		cell.addChild(node);
	},
	loadEquipUI : function(cell,idx){
		var sprite = new cc.Sprite(res.wpicon_bj01);
		sprite.x = 130;
		sprite.y = 405;
		cell.addChild(sprite);
	},
	loadEquipBg : function(cell,idx){
		var sprite = new cc.Sprite(res.bluebg);
		sprite.x = 130;
		sprite.y = 405;
		cell.addChild(sprite);
	},
	loadBg : function(cell,idx){
	    var sprite = new cc.Sprite(res.euip_bg);
	    sprite.anchorX = 0;
	    sprite.anchorY = 0;
	    sprite.x = 0;
	    sprite.y = 0;
	    cell.addChild(sprite);
	},
	loadEquipedBtn : function(cell){
		var nodeNormal    = new cc.Sprite(res.ui_btn_zdxf_01);
		var nodeSelected  = new cc.Sprite(res.ui_btn_zdxf_02);
		var nodeDisabled  = new cc.Sprite(res.ui_btn_zdxf_01);

		var node = new cc.MenuItemSprite(
		nodeNormal,
		nodeSelected,
		nodeDisabled,
		function(){

		}.bind(this));

		node.x = 8;
		node.y = 17;
		node.anchorX = 0;
		node.anchorY = 0;

		var menu = new cc.Menu();
		menu.setPosition(0, 0);
		menu.addChild(node);
		cell.addChild(menu);
	},
	loadUnloadBtn : function(cell){
		var nodeNormal    = new cc.Sprite(res.btn_equip1);
		var nodeSelected  = new cc.Sprite(res.btn_equip02);
		var nodeDisabled  = new cc.Sprite(res.btn_equip1);

		var node = new cc.MenuItemSprite(
		nodeNormal,
		nodeSelected,
		nodeDisabled,
		function(){

		}.bind(this));

		node.x = 145;
		node.y = 17;
		node.anchorX = 0;
		node.anchorY = 0;

		var menu = new cc.Menu();
		menu.setPosition(0, 0);
		menu.addChild(node);
		cell.addChild(menu);
	}

});