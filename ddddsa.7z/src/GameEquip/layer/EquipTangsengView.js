

var EquipTangsengView = cc.Layer.extend({
	ctor : function(){
		this._super();
	}


});