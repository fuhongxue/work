

var EquipBajieView = cc.Layer.extend({
	ctor : function(){
		this._super();
	}


});