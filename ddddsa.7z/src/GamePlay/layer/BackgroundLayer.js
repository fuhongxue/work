/**
 * Created by wangzhigang on 15/8/21.
 */

var GPBackgroundLayer = cc.Layer.extend({

    ctor:function () {
        this._super();

        this.loadBg();
        this.loadTopBg();
        this.loadBottomBg();


        this.loadParallaxNode();
        this.loadRoad();
        
        return true;
    },
    loadBg : function(){
        var node = new cc.Sprite(res[GameManager.getInstance().getBgPath()+ "_bg1"]);
        this.addChild(node);

        node.setPosition(GC.w2, GC.h2);
        node.setScale(GC.SCALE_RATE);
    },

    loadTopBg : function() {
        var node = new cc.Sprite(res.ui_top);
        this.addChild(node,200);
        node.setScale(GC.SCALE_RATE);
        node.setPosition(GC.w2, GC.h - node.getBoundingBox().height/2);

    },
    loadBottomBg : function() {
        var node = new cc.Sprite(res.ui_top2);
        this.addChild(node);
        node.setScale(GC.SCALE_RATE);
        node.setPosition(GC.w2,node.getBoundingBox().height/2);
    },
    loadParallaxNode : function(){
        var node = new cc.ParallaxNode();
        this.addChild(node);
        this.parallaxNode = node;

        GameManager.getInstance().parallaxNode = node;
    },
    update : function(dt){
        var heroObj = GameManager.getInstance().getHeroObj();
        var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;

        var num = heroObj.getSpeed() * dt*dir;

        if (this.parallaxNode.x  - num > 0) {
            this.parallaxNode.x = 0
        }else{
            this.parallaxNode.x =  this.parallaxNode.x - num;
        }
        // num = num
        // GameManager.getInstance().effectParallax.x =  GameManager.getInstance().effectParallax.x - num;
        // if (GameManager.getInstance().effectParallax.x  - num > 0) {
        //     GameManager.getInstance().effectParallax.x = 0
        // }else{
        //     GameManager.getInstance().effectParallax.x =  GameManager.getInstance().effectParallax.x - num;
        // }

        var roadVector = this.roadVector;

        Common.bgRecycle(roadVector);
    },
    loadRoad : function() {
        this.roadVector = [];
        var mapInfo = GameManager.getInstance().mapInfo

        var prefix = mapInfo[0] + "_" + mapInfo[1];
        var forewordObj = BgParallax[mapInfo[0]]["backward"];

        for (var i = 0; i < forewordObj.length; i++) {
            var tnode = new cc.Node();
            var fieldObj = forewordObj[i];

            if (fieldObj.loop == "multiple") {
                for (var j = 0; j < fieldObj.amount; j++) {
                    var node = new cc.Sprite(res[prefix + "_" + fieldObj.name]);
                    node.setScale(GC.SCALE_RATE );
                    node.anchorX = 0;
                    node.anchorY = 0;


                    node.x =  node.getBoundingBox().width*j;
                    node.y =  fieldObj.height;

                    node.field = fieldObj.name;
                    tnode.addChild(node);

                    node.totalNum = fieldObj.amount;
                    this.roadVector.push(node);

                    if(fieldObj.tree){

                        for (var k = 0; k < fieldObj.tree.length; k++) {
                            var treeInfo = fieldObj.tree[k];

                            if (treeInfo.pNode == j) {
                               var trnode = new cc.Sprite(res[prefix + "_" + treeInfo.name]);
                               trnode.setScale(treeInfo.scaleRate);
                               trnode.anchorX = 0;
                               trnode.anchorY = 0;                            

                               trnode.x =  treeInfo.x;
                               trnode.y =  treeInfo.y;

                               node.addChild(trnode); 
                            };
                        };
                    }
                };
            };

            this.parallaxNode.addChild(tnode, -1, cc.p(fieldObj.ratio, 0), cc.p(0,0));

        };

    },
});