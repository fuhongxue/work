/**
 * Created by wangzhigang on 15/9/17.
 */

var GPForeParallaxLayer = cc.Layer.extend({
	parallaxNode : null,
	treeVector : [],
	ctor:function () {
		this._super();

		this.loadConfig();
		this.loadParallaxNode();
		this.loadBg();
	},
	loadConfig : function(){
		this.treeVector = [];
	},
	loadBg : function(){
		var mapInfo = GameManager.getInstance().mapInfo

		var prefix = mapInfo[0] + "_" + mapInfo[1];
		var forewordObj = BgParallax[mapInfo[0]]["foreword"];

		var tnode = new cc.Node();

		for (var i = 0; i < forewordObj.length; i++) {
			var fieldObj = forewordObj[i];

			var node = new cc.Sprite(res[prefix + "_" + fieldObj.name]);
			node.setScale(GC.SCALE_RATE );
			node.anchorX = 0;
			node.anchorY = 0;

			node.curPosIndex = -1;
			node.posVector = fieldObj.posVector;
			node.field = fieldObj.name;
			tnode.addChild(node);

			this.treeVector.push(node);
		};
		this.parallaxNode.addChild(tnode, -1, cc.p(fieldObj.ratio, 0), cc.p(-GC.w,0));
	},
	loadParallaxNode : function(){
		var node = new cc.ParallaxNode();
		this.addChild(node);
		this.parallaxNode = node;
	},
	update : function(dt){
		var heroObj = GameManager.getInstance().getHeroObj();
		var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;

		var preX = -this.parallaxNode.x;
		num = heroObj.getSpeed() * dt*dir;

		if (this.parallaxNode.x  - num > 0) {
		    this.parallaxNode.x = 0
		}else{
		    this.parallaxNode.x =  this.parallaxNode.x - num;
		}

		var curX = -this.parallaxNode.x;


		for ( i = 0, len = this.treeVector.length; i< len; i++){
			var node = this.treeVector[i];
			var posVector = node.posVector;
			for (var j = 0; j < posVector.length; j++) {
				var vPosx = posVector[j];

				if ((preX <= vPosx && curX > vPosx)) {

					var pos = node.getParent().convertToNodeSpace(cc.p(GC.w,0));
					node.setPositionX(pos.x);
					break;
				}else if (preX >= vPosx + GC.w + node.getBoundingBox().width && curX < vPosx + GC.w + node.getBoundingBox().width) {

					var pos = node.getParent().convertToNodeSpace(cc.p(-node.getBoundingBox().width,0));
					node.setPositionX(pos.x);
					break;
				}

			};
		}
	}

});