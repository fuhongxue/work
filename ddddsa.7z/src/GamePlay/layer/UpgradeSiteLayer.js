
/**
 * Created by wangzhigang on 15/4/20.
 */

 var CustomTableViewCell = cc.TableViewCell.extend({
     draw:function (ctx) {
         this._super(ctx);
     }
 });

 var GPUpgradeSiteLayer = cc.Layer.extend({
 	background : null,
 	wukongItem : null,
 	partnerItem : null,
 	menu        : null,
 	tvWukong    : null,
 	tvPartner   : null,
 	isShow      : false,
 	ctor : function(){
 		this._super();
 		this.loadConfig();
 		this.loadBg();
 		this.loadGradientUI();
 		this.loadWukongItem();
 		this.loadPartnerItem();
 		this.loadWukongTableView();
 		this.showTips();
 	},
 	showTips : function(){
 		var ret = GameManager.getInstance().checkIsShowTips();

 		if (!this.wukongItem.tips) {
 			var tnode = Common.createTipNode();
 			tnode.setPosition(this.wukongItem.width/2,this.wukongItem.height/2);

 			this.wukongItem.addChild(tnode);
 			this.wukongItem.tips = tnode;
 		};

 		if (!this.partnerItem.tips) {
 			var tnode = Common.createTipNode();
 			tnode.setPosition(this.partnerItem.width/2,this.partnerItem.height/2);

 			this.partnerItem.addChild(tnode);
 			this.partnerItem.tips = tnode;
 		};

 		if (ret[0]) {
 			this.wukongItem.tips.setVisible(true);
 		}else{
 			this.wukongItem.tips.setVisible(false);
 		}

 		if (ret[1]) {
 			this.partnerItem.tips.setVisible(true);
		}else{
			this.partnerItem.tips.setVisible(false);
		}
 	},
 	loadConfig : function(){
 		var node = new cc.Node();
 		this.addChild(node,-10)
 		node.setCascadeOpacityEnabled(true);

 		this.effUINode = node;
 		this.effUINode.y = -10;
 	},
 	addBgListener : function(){
 		var listener = cc.EventListener.create({
 		    event           : cc.EventListener.TOUCH_ONE_BY_ONE,
 		    // target          : this.background,
 		    swallowTouches  : true,
 		    onTouchBegan    : this.onTouchBegan,
 		    // onTouchMoved    : this.onTouchMoved,
 		    // onTouchEnded    : this.onTouchEnded
 		});
 		cc.eventManager.addListener(listener, this.background);
 	},
 	loadBg : function(){
 		var node = new cc.Sprite(res.ui_zdbg_02);
 		node.setAnchorPoint(0.5,0.5);
 		this.effUINode.addChild(node,-2);
 		node.setScale(1/GC.SCALE_RATE);

 		this.background = node;

 		var menu = new cc.Menu();
 		this.effUINode.addChild(menu,1);
 		menu.setPosition(0, 0);

 		this.menu = menu;
 		this.menu.x = -50

 		this.addBgListener();
 	},
 	loadGradientUI : function(){
 		var node = new cc.Sprite(res.ui_zd_01);
 		this.effUINode.addChild(node,-2);

 		node.setPosition(cc.p(-68,0))
 		node.setScale(1/GC.SCALE_RATE);

 		var node = new cc.Sprite(res.ui_zd_02);
 		this.effUINode.addChild(node,-2);

 		node.setPosition(cc.p(72,0))
 		node.setScale(1/GC.SCALE_RATE);
 	},
 	onTouchBegan: function (touch, event) {
 		var target = event.getCurrentTarget();

 		var locationInNode = target.convertToNodeSpace(touch.getLocation());
 		var s = target.getContentSize();
 		var rect = cc.rect(0, 0, s.width, s.height);
 		if (cc.rectContainsPoint(rect, locationInNode)) {
 		    return true;
 		}

		return false;
	},
 	loadWukongItem : function(){
 		var nodeNormal    = new cc.Sprite(res.ui_btn_wk02);
 		var nodeSelected  = new cc.Sprite(res.ui_btn_wk01);
 		var nodeDisabled  = new cc.Sprite(res.ui_btn_wk02);

 		var node = new cc.MenuItemSprite(
 		    nodeNormal,
 		    nodeSelected,
 		    nodeDisabled,
 		    function(){
 		    	this.wukongItem.selected();
 		    	this.partnerItem.unselected();
 		    	this.tvPartner.getContainer().setVisible(false);
 		    	this.tvWukong.getContainer().setVisible(true);
 		    	this.tvPartner.setTouchEnabled(false);
 		    	this.tvWukong.setTouchEnabled(true);

 		    	this.tvWukong.reloadData();

 		    }.bind(this));
 		node.setPosition(this.background.getContentSize().width/2/4+8, this.background.getContentSize().height/2/4-20);
 		node.setScale(1/GC.SCALE_RATE)
 		node.selected()

 		this.menu.addChild(node)

 		this.wukongItem = node;
 	},
 	loadPartnerItem : function() {
 		var nodeNormal    = new cc.Sprite(res.ui_btn_hb02);
 		var nodeSelected  = new cc.Sprite(res.ui_btn_hb01);
 		var nodeDisabled  = new cc.Sprite(res.ui_btn_hb02);

 		var node = new cc.MenuItemSprite(
 		    nodeNormal,
 		    nodeSelected,
 		    nodeDisabled,
 		    function(){
 		    	this.partnerItem.selected();
 		    	this.wukongItem.unselected();

 		    	this.tvPartner.getContainer().setVisible(true);
 		    	this.tvWukong.getContainer().setVisible(false);
 		    	this.tvPartner.setTouchEnabled(true);
 		    	this.tvWukong.setTouchEnabled(false);

 		    	this.tvPartner.reloadData();

 		    }.bind(this));
 		node.setPosition(this.background.getContentSize().width/2/4+8, this.background.getContentSize().height/2/4-50);
 		node.setScale(1/GC.SCALE_RATE)
 		this.menu.addChild(node)
 		this.partnerItem = node;

 	},
 	loadWukongTableView : function(){
 		var node = new GPWukongTableView();
 		this.effUINode.addChild(node,3);
 		this.tvWukong = node;
 		node.setCascadeOpacityEnabled(true);

 		var node = new GPPartnerTableView();
 		this.effUINode.addChild(node,3);
 		this.tvPartner = node;
 		node.setCascadeOpacityEnabled(true);


 		this.tvPartner.getContainer().setVisible(false);
 		this.tvPartner.setTouchEnabled(false);

 		this.tvWukong.getContainer().setCascadeOpacityEnabled(true);
 		this.tvPartner.getContainer().setCascadeOpacityEnabled(true);

 		this.setVisible(false);
 		cc.eventManager.removeListeners(this.background);  
 	},
 	showEff : function(isIntersect){
 		var heroObj = GameManager.getInstance().getHeroObj();
 		var time = 0.5;

 		if(!isIntersect){
 			if (this.isShow == true) {
 				this.effUINode.stopActionByTag(998);
 				this.menu.stopActionByTag(999);


 				this.isShow = (false);

 				var action2 = cc.fadeOut(time);
 				var action3 = cc.moveTo(time,cc.p(0,-10));

 				var callBack = cc.callFunc(function(){
 					this.effUINode.setVisible(false);
 				}.bind(this));


 				var action = cc.sequence(cc.spawn(action2,action3),callBack);
 				action.tag = 998;
 				this.effUINode.runAction(action);

 				var action5 = cc.moveTo(time,cc.p(-50,0));
 				action5.tag = 999;
 				this.menu.runAction(action5);
 				cc.eventManager.removeListeners(this.background);  

 			}
 		}else{
 			if (this.isShow == false) {
 				this.effUINode.stopActionByTag(998);
 				this.menu.stopActionByTag(999);

 				this.effUINode.setVisible(true);

 				this.effUINode.y = -10

 				this.tvWukong.reloadData();
 				this.tvPartner.reloadData();
 				
 				this.isShow = (true);

	 			var action2 = cc.fadeIn(time);
	 			var action3 = cc.moveTo(time,cc.p(0,0));

	 			var action = cc.sequence(cc.spawn(action2,action3));
	 			action.tag = 998;
 				this.effUINode.runAction(action);

 				var action5 = cc.moveTo(time,cc.p(0,0));
 				action5.tag = 999;
 				this.menu.runAction(action5);

 				this.addBgListener();
 				this.reloadData();
 			};

 			if (this.isVisible() == false) {
 				this.setVisible(true);
 			};

 		}
 	},
 	reloadData : function(){
 		this.tvWukong.reloadData();
 		this.tvPartner.reloadData();

 		this.showTips();
 	},
});