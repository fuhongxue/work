

var GPBottomLayer = cc.Layer.extend({
	bg  : null,
	progressArr : null,
	ctor : function(){
		this._super();
		this.loadConfig();
		this.loadBGUI();
		this.loadSkillIcon();
	},
	loadConfig : function(){
		this.progressArr = [];
		GameManager.getInstance().progressArr = this.progressArr;
	},
	loadBGUI : function(){
		var node = new cc.Sprite(res.ui_top2);
 	    this.addChild(node);
 	    node.setScale(GC.SCALE_RATE);
 	    node.setPosition(GC.w2,node.getBoundingBox().height/2);

 	    this.bg = node;
	},
	bindListener : function(node){

		var listener1 = cc.EventListener.create({
		    event: cc.EventListener.TOUCH_ONE_BY_ONE,
		    swallowTouches: true,
		    onTouchBegan: function (touch, event) {
		        var target = event.getCurrentTarget();

		        var locationInNode = target.convertToNodeSpace(touch.getLocation());
		        var s = target.getContentSize();
		        var rect = cc.rect(0, 0, s.width, s.height);

		        if (cc.rectContainsPoint(rect, locationInNode)) {
		        	var skillData = GameManager.getInstance().localData.skillUnlockStatus;
		        	var isUnlock = skillData[target.name];
		        	var curData =  GPDataManager.getInstance().skillData[target.name];
		        	var isCooling = curData.isCooling;
		        	if (!isCooling && isUnlock) {
		        		curData.isWork = true;
		        		curData.isCooling = true;
		        		curData.continueTimeClock = 0;
		        		curData.coolingTimeClock = 0;

		        		var arr = GameManager.getInstance().progressArr ;
		        		var proTime ;
		        		for (var i = 0; i < arr.length; i++) {
		        			var name = arr[i].name;

		        			if (name == target.name) {
		        				proTime = arr[i];
		        				break
		        			};
		        		};
		        		var skillInfo = GameManager.getInstance().skillInfo;
		        		var sLv = GameManager.getInstance().getSkillLv(target.name);
		        		var time = skillInfo[target.name].config[sLv][2];

		        		var to = cc.progressFromTo(time, 0, 100);
		        		proTime.runAction(to.clone());

		        		GPDataManager.getInstance().ratingData[8] = GPDataManager.getInstance().ratingData[8] + 1;
		        	};

		            return true;
		        }
		        return false;
		    },
		});

		cc.eventManager.addListener(listener1, node);
	},
	loadSkillIcon : function(){
		var skillData = GameManager.getInstance().localData.skillUnlockStatus;

		for (var i = 0; i < TV_WU_RES.length; i++) {
			var name = TV_WU_RES[i].cName;
			var resName = TV_WU_RES[i].bg;

			if(name != "wukong"){
				var value = skillData[name];
				var isFind = false;

				for (var j = 0; j < this.progressArr.length; j++) {
					var node = this.progressArr[j];

					if (node.name == name) {
						isFind = true;
						break;
					};
				};

				if (isFind) {
					continue;
				};

				if (value == 2) {
					var node = new cc.Sprite(res[resName])
					node.setPosition(220 + i*100,this.bg.getBoundingBox().height/2);
					node.setScale(GC.SCALE_RATE/4*3);
					this.addChild(node);

					var mask = new cc.LayerColor(cc.color(0, 0, 0, 175),80,80);
					mask.ignoreAnchorPointForPosition(false);
					mask.anchorX = 0.5;
					mask.anchorY = 0.5;
					mask.setPosition(220 + i*100,this.bg.getBoundingBox().height/2);
					this.addChild(mask);

					var proTime = new cc.ProgressTimer(new cc.Sprite(res[resName]));
					proTime.type = cc.ProgressTimer.TYPE_RADIAL;
					proTime.midPoint = cc.p(0.5, 0.5);
					proTime.barChangeRate = cc.p(0, 1);
					this.addChild(proTime);
					proTime.x = 220 + i*100
					proTime.y = this.bg.getBoundingBox().height/2
					proTime.setScale(GC.SCALE_RATE/4*3);

					proTime.setPercentage(100);

					proTime.name = name;
					this.progressArr.push(proTime)
					this.bindListener(proTime);

				}else{
					var node = new cc.Sprite(res.ui_skillbg1);
					node.setPosition(220 + i*100,this.bg.getBoundingBox().height/2);
					node.setScale(GC.SCALE_RATE);
					this.addChild(node);
				}
			}
		};
	},
});