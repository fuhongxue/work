
/**
 * Created by wangzhigang on 15/4/20.
 */

var Hero = cc.Sprite.extend({ 
	speed		: 0,
	direction	: GC.CHARACTER_DIRECTION.RIGHT,
	isMove      : false,
	isDeath     : false,

	weapon 		: null,
	weaponEffNode : null,
	hpBar       : null,

	hp          : 0,
	attack      : 0,    //攻击
	def         : 0,    //防御
	needGold　　: 0,    //升级所需金钱
	isDeathAnimationFinished : false,
	isSpeedReduce : false,  //是否处于减速的过程中
	runSmoke    : null,
	isOnSite    : false,
	hpNode      : null,
	tempSpeed   : -1,  // 与怪物撞击时缓存速度
	isShowSmoke : true,
	attrArr : null,

	ctor : function() {
		this._super(res.wukong_standby_r_1);

		this.loadConfig();
		this.loadRunSmoke();
		this.loadAnimation();
		this.loadWeapon();
		this.schedule(this.updateRestoreHp, GC.HERO_HP_TIME);
		return true;
	},
	loadConfig : function() {
		this.speed = GC.HERO_START_SPEED;
		var data =  GameManager.getInstance().getCharacterData();
		this.hp     = data[0];
		this.attrArr = data;
		this.setScale(GC.SCALE_RATE);
	},
	resetBaseConfig : function(){
		this.attrArr = GameManager.getInstance().getCharacterData();
	},
	getLevel : function(){
		var level = GameManager.getInstance().getCharacterLevel(0);
		if (level >= 9) {level = 9};
		return 2;
	},
	loadRunSmoke : function(){
		var node = Common.createAnimateNode(4,"ef_run_smoke",true);
		this.addChild(node);

		node.setAnchorPoint(0.5,0);

		node.x = 87/4 - 10;
		node.setVisible(false);
		this.runSmoke = node;
	},
	loadAnimation : function() {
		if (!this.isDeath) {
			this.stopActionByTag(998);

			if(this.getIsMove())
			{
			    var prefix =  "l01_run0";
			    this.setTexture(res[prefix + "1"]);
			    this.setAnchorPoint(0.5,0);

			    var animation = cc.Animation.create();  //利用动画保存每一帧的图片

			    for (var i = 1; i <= 4; i++) {
			    	animation.addSpriteFrameWithFile(res[prefix + i ]);
			    };

			    animation.setDelayPerUnit(0.1);  //每一帧播放的间隔
			    // animation.setRestoreOriginalFrame(true);  //是否回到第一帧播放
			    var animate = cc.animate(animation).repeatForever();
			    animate.tag = 998;
			    this.runAction(animate);

			}else {
				var prefix =  "l01_standby0";
				this.setTexture(res[prefix + "1"]);
				this.setAnchorPoint(0.5,0);

				var animation = cc.Animation.create();  //利用动画保存每一帧的图片

				for (var i = 1; i <= 4; i++) {
					animation.addSpriteFrameWithFile(res[prefix + i ]);
				};

				animation.setDelayPerUnit(0.1);  //每一帧播放的间隔
				var animate = cc.animate(animation).repeatForever();
				animate.tag = 998;
				this.runAction(animate);

			}

			if (this.direction == GC.CHARACTER_DIRECTION.RIGHT) {
				this.setRotationY(0);
			}else{
				this.setRotationY(180);
			}

			this.loadWeapon();
		};

	},
	loadDeathAnimaiton : function(){
		this.weapon.setVisible(false);
		this.runSmoke.setVisible(false);

		this.stopActionByTag(998);

		var dir = this.direction == GC.CHARACTER_DIRECTION.RIGHT ? "r" : "l";

		var prefix =  "l01_death0";
		this.setTexture(res[prefix + "1"]);

		var animation = cc.Animation.create();  //利用动画保存每一帧的图片

		for (var i = 1; i <= 7; i++) {
			animation.addSpriteFrameWithFile(res[prefix + i ]);
		};

		animation.setDelayPerUnit(0.1);  //每一帧播放的间隔
		var animate = cc.animate(animation);
		animate.tag = 998;


		var callBack = cc.callFunc(function(){
			this.isDeathAnimationFinished = true;
		}.bind(this));

		this.runAction(cc.sequence(animate,callBack));

		if (this.direction == GC.CHARACTER_DIRECTION.RIGHT) {
			this.setRotationY(0);
		}else{
			this.setRotationY(180);
		}
	},
	loadWeapon : function() {
		if(!this.weapon){
			var prefix = ""
			if (this.getLevel() >= 9) {
				prefix = "wa_" +　(this.getLevel()+1) ;
			}else{
				prefix =  "wa_0" +　(this.getLevel()+1) ;
			}
			var node = new cc.Sprite(res[prefix]);
			this.addChild(node);
			node.setAnchorPoint(0.5,0);

			var moveUp = cc.moveBy(0.1,cc.p(0,1));
			var moveFront = cc.moveBy(0.1,cc.p(1,0));
			var moveDown = cc.moveBy(0.1,cc.p(0,-1));
			var moveBehind = cc.moveBy(0.1,cc.p(-1,0));

			var action = cc.sequence(cc.spawn(moveUp,moveFront),cc.spawn(moveDown,moveBehind) );
			node.runAction(action.repeatForever());

			node.setPosition(node.getContentSize().width + 12,this.getContentSize().height-36);

			var eff = Common.createAnimateNode(5,"Attaca",true);
			eff.setAnchorPoint(0.5,0);
			node.addChild(eff);
			eff.setPosition(30,-3)

			this.weaponEffNode = eff;

			this.weapon = node;
		}else{
			var prefix = ""
			if (this.getLevel() >= 9) {
				prefix = "wa_" +　(this.getLevel()+1) ;
			}else{
				prefix =  "wa_0" +　(this.getLevel()+1) ;
			}
			this.weapon.setTexture(res[prefix]);
		}

		if(this.getIsMove()){
			this.weapon.setVisible(true);
		}else{
			this.weapon.setVisible(false);
		}

	},
	getHpRate : function(){
		var value = GameManager.getInstance().getCharacterData()[0]*GC.HERO_HP_RATE;

		if (this.getIsOnSite()) {
			value = GameManager.getInstance().getCharacterData()[0]*GC.HERO_SITE_HP_RATE;
		};

		return value;
	},
	updateRestoreHp : function(){
		if (this.isOnHit) {
			return;
		};

		if (this.hp < GameManager.getInstance().getCharacterData()[0]) {
			this.hp = this.hp + this.getHpRate();
			if (this.hp > GameManager.getInstance().getCharacterData()[0]) {
				this.hp = GameManager.getInstance().getCharacterData()[0]
			};
			var percent = this.hp/GameManager.getInstance().getCharacterData()[0];

			this.hpNode.setMoveHpBar(percent);
		};
	},
	setHpBar : function() {
		var percent = this.hp/GameManager.getInstance().getCharacterData()[0];

		this.hpNode.setHpBar(percent);
	},
	getSpeed : function() {
		var value = this.speed;

		if(!GameManager.getInstance().GPMainLayer.isMonsterBack){
			var skillData = GameManager.getInstance().localData.skillUnlockStatus;
			var isWork = GPDataManager.getInstance().skillData["jindouyun"].isWork;

			if (skillData["jindouyun"] && isWork) {
				var rate = GameManager.getInstance().getSkillRate("jindouyun");
				value = value*(1+rate);
			};
		}

		return value;
	},
	setSpeed : function(dt) {
		if (this.isSpeedReduce) {
			this.speed = this.speed- Math.abs(dt*GC.HERO_REDUCE_SPEED);

			if (this.speed < 0) {
				this.speed = 0;
				this.isSpeedReduce = false;

				var cVector = GameManager.getInstance().getCharacterVector();
				for (var i = 0; i < cVector.length; i++) {
					cVector[i].loadAnimation();
				};
			};
		}else{
			this.speed = this.speed+Math.abs(dt*GC.HERO_ACCELERATED_SPEED);

			var skillData = GameManager.getInstance().localData.skillUnlockStatus;
			var isWork = GPDataManager.getInstance().skillData["jindouyun"].isWork;
			var maxSpeed = GC.HERO_SPEED;


			if (skillData["jindouyun"] && isWork) {
				var rate = GameManager.getInstance().getSkillRate("jindouyun");
				maxSpeed = maxSpeed*(1+rate);
			};

			if (this.speed > maxSpeed) {
				this.speed = maxSpeed;
			};
		}



	},
	setDirection : function(dir) {
		if(this.direction != dir){
			this.direction = dir;
			this.loadAnimation();
			GameManager.getInstance().GPMainLayer.isMonsterBack = false;

		}
	},
	getDirection : function() {
		return this.direction;
	},
	getIsMove : function() {
		return this.isMove;
	},
	setIsMove : function(i) {
		this.isMove = i;
	},
	getIsSpeedReduce : function(){
		return this.isSpeedReduce;
	},
	setIsSpeedReduce : function(i) {
		this.isSpeedReduce = i;
	},
	getIsDeath : function() {
		return this.isDeath;
	},
	setIsDeath : function(i) {
		this.isDeath = i;

		if (this.isDeath) {
			this.loadDeathAnimaiton();
		}else{
			this.setVisible(true);
			this.isShowSmoke = true;
		}
	},
	addHp : function(v){
		this.hp = this.hp + v;
		if (this.hp > GameManager.getInstance().getCharacterData()[0]) {
			this.hp = GameManager.getInstance().getCharacterData()[0];
		};
		this.setHpBar();
	},
	onHit : function(options) {
		this.isOnHit = true;

		this.hp = this.hp - options.mAttack;

		if (options.isHeroDeath) {
			cc.log("hero die");
			this.setIsMove(false);
			this.setIsDeath(true);
			this.hp = 0;
			this.isShowSmoke = false;
		}else{
			if (options.actionType == 1) {
				this.isShowSmoke = false;

				var time = GC.FIGHT_RULE[1][0][0]/GC.HERO_BACK_SPEED

				var action1 = cc.moveBy(time/2,cc.p(0,GC.FIGHT_RULE[1][0][1]));
				var action2 = cc.moveBy(time/2,cc.p(0,-GC.FIGHT_RULE[1][0][1]));

				var callBack = cc.callFunc(function(){
					this.loadAnimation();
					this.isOnHit = false;
					this.isShowSmoke = true;
					this.speed = 0;
					GameManager.getInstance().GPMainLayer.isMonsterBack = false
				}.bind(this));

				this.runAction( cc.sequence(action1,action2,callBack) );

				var action1 = action1.clone();
				var action2 = action2.clone();
				this.hpNode.runAction(cc.sequence(action1,action2))
			}else{
				this.isOnHit = false;
			}
		}

		this.setHpBar();
	},
	getCollisionRect : function() {
		var heroPos = this.getPosition();
		var heroRect;

		if(this.direction == GC.CHARACTER_DIRECTION.RIGHT ){
			heroRect = cc.rect(
			    heroPos.x -this.getBoundingBox().width/2,
			    heroPos.y ,
			    this.getBoundingBox().width+ this.weapon.getBoundingBox().width*GC.SCALE_RATE ,
			    this.getBoundingBox().height);
		}else{
			heroRect = cc.rect(
			    heroPos.x-this.getBoundingBox().width/2-(this.weapon.getBoundingBox().width*GC.SCALE_RATE),
			    heroPos.y ,
			    this.getBoundingBox().width + this.weapon.getBoundingBox().width*GC.SCALE_RATE,
			    this.getBoundingBox().height)
		}

		return heroRect;
	},
	getAwardCollisionRect : function(){
		var heroPos = this.getPosition();

		return cc.rect(
			    heroPos.x-this.getBoundingBox().width/2,
			    heroPos.y ,
			    this.getBoundingBox().width,
			    this.getBoundingBox().height);
	},
	getTempleCollisionRect : function(){
		var heroPos = this.getPosition();
		var heroRect;

		if(this.direction == GC.CHARACTER_DIRECTION.RIGHT ){
			heroRect = cc.rect(
			    heroPos.x+this.getBoundingBox().width/2,
			    heroPos.y ,
			    1,
			    this.getBoundingBox().height);
		}else{
			heroRect = cc.rect(
			    heroPos.x-this.getBoundingBox().width/2,
			    heroPos.y ,
			    1,
			    this.getBoundingBox().height);
		}

		return heroRect;
	},
	getWeapon : function() {
		return this.weapon;
	},
	reset : function(){
		this.loadConfig();
		this.setHpBar();
		this.setIsDeath(false);
		this.loadAnimation();
	},
	deathFadeIn : function(){
		var action = cc.fadeIn(0.5);
		var callBack = cc.callFunc(function(){
			this.setHpBar();
			this.hpNode.setVisible(true)
		}.bind(this));

		this.runAction(cc.sequence(action,callBack) );

	},
	deathFadeOut : function(cbFunc){
		var callBack = cc.callFunc(function(){
			cbFunc();
		}.bind(this));

		var action = cc.fadeOut(0.5);
		this.runAction(cc.sequence(action,callBack) );
		this.hpNode.setVisible(false)

	},
	resetSpeed : function(value){
		if (value >= 0 ) {
			this.speed = value ;
		};
	},
	getSpeedRate : function(){
		return this.speed/GC.HERO_SPEED < 1/3 ? 1/3 : this.speed/GC.HERO_SPEED;
	},
	setIsOnSite : function(i){
		this.isOnSite = i;
	},
	getIsOnSite : function(){
		return this.isOnSite;
	},
	setHpBarNode : function(i){
		this.hpNode = i;
	},
	resetHpBar : function(){
		this.hpNode.setPosition(this.x - this.hpNode.getWidth()*GC.SCALE_RATE/2,this.y + GC.HP_BAR_HIGHT)
	},
	getAttrArr : function(){
		return this.attrArr;
	},
	checkSmoke : function(){
		if (!this.isDeath) {
			if (this.isMove) {
				if (this.isShowSmoke) {
					if (this.speed >= GC.RUNNING_SMOKE_VALUE) {
						this.runSmoke.setVisible(true);
					}else{
						this.runSmoke.setVisible(false);
					}
				}else{
					this.runSmoke.setVisible(false);
				}
			}else{
				this.runSmoke.setVisible(false);
			}
		};

	}
});