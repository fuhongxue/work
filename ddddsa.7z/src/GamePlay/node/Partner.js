

var Partner = cc.Sprite.extend({ 
	pType : null,
	direction	: GC.CHARACTER_DIRECTION.RIGHT,

	ctor : function(type) {
		this.pType = type;

		this._super(res["p0" + type + "_run_r_01"]);
		this.loadConfig();
		this.loadAnimation();

	},
	loadConfig : function(){
		// this.setScale(GC.SCALE_RATE);
	},
	loadDeathAnimaiton : function(){
		this.stopActionByTag(998);

		var prefix =  "p0" + this.pType +"_death0";
		this.setTexture(res[prefix + "1"]);

		var animation = cc.Animation.create();  //利用动画保存每一帧的图片

		for (var i = 1; i <= 7; i++) {
			animation.addSpriteFrameWithFile(res[prefix + i ]);
		};

		animation.setDelayPerUnit(0.1);  //每一帧播放的间隔
		var animate = cc.animate(animation);
		animate.tag = 998;

		this.runAction(cc.sequence(animate));
	},
	loadAnimation : function(){
		var heroObj = GameManager.getInstance().getHeroObj();

		if (!heroObj.getIsDeath()) {
			this.stopActionByTag(998);

			var dir = this.direction == GC.CHARACTER_DIRECTION.RIGHT ? "r" : "l";

			if(heroObj.getIsMove()){
				var prefix =  "p0" + this.pType +"_run0";
				this.setTexture(res[prefix + "1"]);
				var animation = cc.Animation.create();  //利用动画保存每一帧的图片

				for (var i = 1; i <= 4; i++) {
					animation.addSpriteFrameWithFile(res[prefix + i ]);
				};

				animation.setDelayPerUnit(0.1);  //每一帧播放的间隔
				// animation.setRestoreOriginalFrame(true);  //是否回到第一帧播放
				var animate = cc.animate(animation).repeatForever();
				animate.tag = 998;
				this.runAction(animate);
			}else{
				var prefix =  "p0" + this.pType +"standby0";
				this.setTexture(res[prefix + "1"]);
				var animation = cc.Animation.create();  //利用动画保存每一帧的图片

				for (var i = 1; i <= 4; i++) {
					animation.addSpriteFrameWithFile(res[prefix + i ]);
				};

				animation.setDelayPerUnit(0.1);  //每一帧播放的间隔
				// animation.setRestoreOriginalFrame(true);  //是否回到第一帧播放
				var animate = cc.animate(animation).repeatForever();
				animate.tag = 998;
				this.runAction(animate);
			}

			if (this.direction == GC.CHARACTER_DIRECTION.RIGHT) {
				this.setRotationY(0);
			}else{
				this.setRotationY(180);
			}
		};
	},
	setDirection : function(dir) {
		if(this.direction != dir){
			this.direction = dir;
			this.loadAnimation();
		}
	},
	deathFadeIn : function(){
		var action = cc.fadeIn(0.5);
		this.runAction(action);

		this.loadAnimation();
	},
	deathFadeOut : function(){
		var action = cc.fadeOut(0.5);
		this.runAction(action);
	}
});