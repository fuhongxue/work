
/**
* Created by wangzhigang on 15/10/15.
*/

var Temple = cc.Sprite.extend({ 
	level          : -1,
	isIdle         : true,
	className      : "Temple",
	upgradeSite    : null,
	lightTips      : null,
	ctor : function(){
		this._super(res[GameManager.getInstance().temple]);

		this.loadConfig();
		this.loadLightTips();
		this.loadUpgradeSite();
	},
	loadConfig : function(){
		this.level = -1;
		this.isIdle = true;
		this.className = "Temple";
	},
	loadUpgradeSite : function(){
		var layer = new GPUpgradeSiteLayer();
		this.addChild(layer);
		layer.setPosition(cc.p(this.getContentSize().width/2,65));

		this.upgradeSite = layer;

		GameManager.getInstance().GPUpgradeSiteLayer = layer;
	},
	getUpgradeSite : function(){
		return this.upgradeSite;
	},
	showUpgradeSite : function(isIntersect){
		this.upgradeSite.showEff(isIntersect);
	},
	loadLightTips : function(){
		var pNode = new cc.Node();
		this.addChild(pNode);

		var node = new cc.Sprite(res.ef_temple_lighting01);
		pNode.addChild(node);
		node.setPosition(cc.p(this.getContentSize().width/2 - 20,23));

		var node = new cc.Sprite(res.ef_temple_lighting01);
		pNode.addChild(node);
		node.setPosition(cc.p(this.getContentSize().width/2 + 20,23));

		this.lightTips = pNode;

		this.showLightTips(false);
	},
	showLightTips : function(isShow){
		if (isShow) {
			this.lightTips.setVisible(true);
		}else{
			this.lightTips.setVisible(false);
		}
	},	
	getCollisionRect : function(){
		var pos = this.getPosition();
		var rect;

		if(this.direction == GC.CHARACTER_DIRECTION.RIGHT ){
			rect = cc.rect(
			    pos.x-this.getBoundingBox().width/2,
			    pos.y ,
			    this.getBoundingBox().width,
			    this.getBoundingBox().height);
		}else{
			rect = cc.rect(
			    pos.x+this.getBoundingBox().width/2,
			    pos.y ,
			    this.getBoundingBox().width,
			    this.getBoundingBox().height);
		}

		return rect;
	},
});