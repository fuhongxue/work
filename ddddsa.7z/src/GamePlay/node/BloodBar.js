
/**
 * Created by wangzhigang on 15/10/26.
 */

var BloodBar = cc.Sprite.extend({
	type : null,
	ctor : function(type){
		this._super(res.ui_hp_bg);

		this.type = type;

		this.loadHpBarBg();
		this.loadHpBar(type);
	},
	loadHpBarBg : function(){
		this.setAnchorPoint(0,0);

		this.setPosition(0,GC.HP_BAR_HIGHT);
		this.setCascadeOpacityEnabled(true);
	},
	setHpTexture : function(color){
		var resName = "";

		if (color == "green") {
			resName = res.ui_hp_green;
		}else if (color == "purple") {
			resName = res.ui_hp_purple;
		}else if (color == "red") {
			resName = res.ui_hp_red;
		}else if (color == "yellow") {
			resName = res.ui_hp_yellow;
		};

		this.hpBar.setTexture(resName);
	},
	loadHpBar : function(type){
		var color = "";

		if (type == "hero") {
			color = "green";
		}else{
			color = "purple";
		}

		var node = new cc.Sprite();
		this.hpBar = node;
		this.setHpTexture(color);
		this.addChild(node);
		node.setAnchorPoint(0,0);
		node.setCascadeOpacityEnabled(true);

	},
	setHpBarColor : function(percent){
		var color = "";
		if (this.type == "hero") {
			for (var i = 0; i < GC.HERO_HP_COLOR.length; i++) {
				var item = GC.HERO_HP_COLOR[i];

				if (percent >= item[0] && percent <= item[1]) {
					color = item[2];
					this.setHpTexture(color);
					break;
				};
			};
		};
	},
	setHpBar : function(percent){
		if(percent > 0){
			this.hpBar.setScaleX(percent);
		}else{
			this.hpBar.setScaleX(0);
		}

		this.setHpBarColor(percent)
	},
	setMoveHpBar : function(percent){
		var action = cc.scaleTo(0.1,percent,1);
		this.hpBar.runAction(action);

		this.setHpBarColor(percent);
	},
	getWidth : function(){
		return 42;
	}
});