/**
 * Created by wangzhigang on 15/4/20.
 */


var GamePlayLayer = cc.Layer.extend({
    backgroundLayer : null,
    mainLayar : null,
    foreParallaxLayer : null,
    ctor:function () {
        this._super();
        new LevelLoader(GameManager.getInstance().getCurLevel());
        GPDataManager.getInstance().clear();
        
        this.loadBackground();
        this.loadMainLayer();
        this.loadForeParallax();
        this.loadBottomLayer();
        EffectManager.getInstance().init();
        return true;
    },
    loadBackground : function(){
        this.backgroundLayer = new GPBackgroundLayer();
        this.addChild(this.backgroundLayer);

        GameManager.getInstance().GPBackgroundLayer= this.backgroundLayer;
    },
    loadMainLayer : function(){
        this.mainLayar = new GPMainLayer();
        this.addChild(this.mainLayar);

        GameManager.getInstance().GPMainLayer = this.mainLayar;
    },
    loadForeParallax : function(){
        this.foreParallaxLayer = new GPForeParallaxLayer();
        this.addChild(this.foreParallaxLayer);

        GameManager.getInstance().foreParallaxLayer = this.foreParallaxLayer; 
    },
    loadBottomLayer : function(){
        this.GPBottomLayer = new GPBottomLayer();
        this.addChild(this.GPBottomLayer);

        GameManager.getInstance().GPBottomLayer = this.GPBottomLayer;
    },
});

var GamePlayScene = cc.Scene.extend({
    onEnter:function () {
        this._super();
        var layer = new GamePlayLayer();
        this.addChild(layer); 
    }
});