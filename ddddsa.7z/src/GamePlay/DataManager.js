

var GPDataManager = (function(){
	function _GPDataManager(){
		this.skillData = null,
		this.ratingData = null,
		this.clear = function(){
			this.skillData = {
				"jindouyun" : {
					isWork : false,    // 是否生效
					isCooling : false, // 是否冷却中
					continueTimeClock : 0, //持续时间
					coolingTimeClock  : 0, //冷却时间
				},
				"jingubang" : {
					isWork : false,    // 是否生效
					isCooling : false, // 是否冷却中
					continueTimeClock : 0, //持续时间
					coolingTimeClock  : 0, //冷却时间
				},
				"jingang" : {
					isWork : false,    // 是否生效
					isCooling : false, // 是否冷却中
					continueTimeClock : 0, //持续时间
					coolingTimeClock  : 0, //冷却时间
				},
			},

			this.ratingData = [];
			for (var i = 0; i < RatingConfig.text.length; i++) {
				this.ratingData[i] = 0;
			};

	
		},
		this.update = function(dt){
			var skillInfo = GameManager.getInstance().skillInfo;
			var self = this;
			for(var v in this.skillData){
				var item = this.skillData[v];
				var sLv = GameManager.getInstance().getSkillLv(v);

				if (item.isCooling) {
					item.coolingTimeClock = item.coolingTimeClock + dt;

					var arr = GameManager.getInstance().progressArr ;
					var proTime ;
					for (var i = 0; i < arr.length; i++) {
						var name = arr[i].name;

						if (name == v) {
							proTime = arr[i];
							break
						};
					};

					if (item.coolingTimeClock >= skillInfo[v].config[sLv][2]) {
						item.isCooling = false;
					}
				};
				if (item.isWork) {
					item.continueTimeClock = item.continueTimeClock + dt;

					if (item.continueTimeClock >= skillInfo[v].config[sLv][1]) {
						item.isWork = false;
					};
				};

			};
		},
		this.roleCollisionEffectJudge = function(hero,monster){
			var isHeroDeath = false;
			var isMonsterDeath = false;
			var monsterGold = 0;
			var actionType = -1;

			var mHp = monster.hp;
			var hHp = hero.hp;
			var hAttack =  this.calculateDamage(hero.getAttrArr(),monster.getAttrArr(),true); 
			var mAttack = this.calculateDamage(monster.getAttrArr(),hero.getAttrArr());
			var mHpMax = monster.hpMax;
			var hHpMax = GameManager.getInstance().getCharacterData()[0];


			var skillData = GameManager.getInstance().localData.skillUnlockStatus;
			var isWork = GPDataManager.getInstance().skillData["jingubang"].isWork;

			if (skillData["jingubang"] && isWork) {
				var rate = GameManager.getInstance().getSkillRate("jingubang");
				hAttack = Math.floor(hAttack*(1+rate));
			};

			monsterGold = monster.gold;

			if (hHp - mAttack <= 0) {
				isHeroDeath = true;
			}

			if (mHp - hAttack <= 0) {
				isMonsterDeath = true;
			};

			var costHpRate = hAttack/mHpMax;

			if (costHpRate < GC.FIGHT_RULE[0][0]) {
				actionType = 1;

				hero.speed = GC.HERO_BACK_SPEED;
			}else if (costHpRate >= GC.FIGHT_RULE[0][0] && costHpRate <= GC.FIGHT_RULE[0][1]) {
				actionType = 2;
				if (!isHeroDeath) {
					var heroRate = ( 1-GC.FIGHT_RULE[1][3] * mAttack/hHpMax) 
					if (heroRate < 0) {
						heroRate = 0;
					};

					hero.speed = hero.speed*heroRate;
				};

			}else if (costHpRate > GC.FIGHT_RULE[0][1]) {
				actionType = 3;
				if (!isHeroDeath) {
					var heroRate = ( 1-GC.FIGHT_RULE[1][3] * mAttack/hHpMax) 
					if (heroRate < 0) {
						heroRate = 0;
					};

					hero.speed = hero.speed*heroRate;
				};

			};


			return {
				"isHeroDeath" : isHeroDeath,
				"isMonsterDeath" : isMonsterDeath,
				"monsterGold" : monsterGold,
				"actionType" : actionType,
				"hAttack"       : hAttack,
				"mAttack"       : mAttack
			};
		},
		// 计算伤害值
		this.calculateDamage = function(cArrt,oArrt,isHero){
			// 血， 攻，暴，防，韧， 闪，命;
			var cMZ = cArrt[6] ? cArrt[6] : 0;
			var cGJ = cArrt[1] ? cArrt[1] : 0;
			var cBJ = cArrt[2] ? cArrt[2] : 0;
			var oSB = oArrt[5] ? oArrt[5] : 0;
			var oRX = oArrt[4] ? oArrt[4] : 0;
			var oFY = oArrt[3] ? oArrt[3] : 0;

			var value = 0;

			//实际命中=(我方命中+1)/（我方命中+1+敌方闪避）
			var MZ_rate = (cMZ + 1)/(cMZ+1+oSB) 

			var damage = 0;
			if (Common.calculateProbability(MZ_rate)) {
				if (!isHero) {
					var skillData = GameManager.getInstance().localData.skillUnlockStatus;
					var isWork = GPDataManager.getInstance().skillData["jingang"].isWork;

					if (skillData["jingang"] && isWork) {
						var rate = GameManager.getInstance().getSkillRate("jingang");
						oFY = Math.floor(oFY*(1+rate));
					};
				};

				damage = cGJ - oFY;


				if (damage < 1) {
					damage = 1;
				};

				// 实际暴击=（我方暴击/（我方暴击+300+敌方韧性））*70%	
				var BJ_rate = (cBJ/(cBJ + 300 + oRX))*0.7;

				if(Common.calculateProbability(BJ_rate)){
					var BJ_value = Common.random(GC.BJ_SCOPE[0],GC.BJ_SCOPE[1]);
					damage = parseInt(damage * BJ_value);
				}
			};

			damage = Common.randomInt(damage * GC.ATTACK_RATE[0],damage * GC.ATTACK_RATE[1]) ;
			if (damage < 1) {damage = 1};

			return damage;
		},
		this.ratingConditionJudge = function(){
			var gRating = GameManager.getInstance().localData.rating;
			var curLevel = GameManager.getInstance().getCurLevel();
			var ratingCondition = eval("Level" + curLevel).rating;
			var ratingData = this.ratingData;

			if (!gRating[curLevel]) {
				gRating[curLevel] = [false,false,false];
			};

			for (var i = 0; i < ratingCondition.length; i++) {
				var config = ratingCondition[i];

				function addRatingStar(){
					gRating[curLevel][i] = true;
					GameManager.getInstance().localData.ratingStar += 1; 
					GameManager.getInstance().unlockSkillAndPartner();
				}

				if (!gRating[curLevel][i]) {
					if ( RatingConfig.text[config[0]][3] == "less") {
						if (ratingData[config[0]] < config[1]) {
							addRatingStar()
						};
					}else if(RatingConfig.text[config[0]][3] == "more"){
						if (ratingData[config[0]] > config[1]) {
							addRatingStar();
						};
					}else if (RatingConfig.text[config[0]][3] == "lessOrequal") {
						if (ratingData[config[0]] <= config[1]) {
							addRatingStar();
						};
					};
				};
			};
			GameManager.getInstance().saveLocalData();
		},
		this.equipDropJudge = function(){
			var dropConfig = EquipConfig.drop;
			var dropRate = dropConfig.rate;
			var dropQWeight = dropConfig.weight;
			var qualityConfig = EquipConfig.quality;
			var baseConfig = EquipConfig.baseAttr;
			var bUpgradeConfig = baseConfig.upgradeConfig;

			var gEquipArr = GameManager.getInstance().localData.equipArr;

			var gRating = GameManager.getInstance().localData.rating;
			var curLevel = GameManager.getInstance().getCurLevel();

			// 计算当前关卡星级数量
			var curStarNum = 0;
			for (var i = 0; i < gRating[curLevel].length; i++) {
				if(gRating[curLevel][i]){
					curStarNum = curStarNum + 1;
				}
			};

			// 根据星级数量，判断是否掉落装备
			var isDrop = false;
			if (curStarNum != 0) {
				for (var i = 0; i < dropRate.length; i++) {
					var sNum = dropRate[i][0];
					var sRate = dropRate[i][1];

					if (curStarNum == sNum) {
						var value = Common.randomInt(1,100);
						cc.log("drop value ::" + value)
						cc.log("sRate      ::" + sRate);


						if (value <= sRate*100) {
							isDrop = true;
						};
						break
					};
				};
			};


			if (isDrop) {
				var eQuality = 0;
				var eVariety = 0;
				var baseArr = [-1,-1,-1,-1,-1,-1,-1];
				var specialArr = [-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1];

				// 如果确定掉落装备,判断掉落武器类型 棍	杖	耙	铲
				var rWeight = Common.randomInt(1,4);
				eVariety = rWeight - 1;


				// 如果确定掉落装备，根据当前关卡判断装备品质
				for (var i = 0; i < dropQWeight.length; i++) {
					var item = dropQWeight[i];

					// 界定关卡范围
					if (curLevel >= item[0][0] && curLevel < item[0][1]) {

						var totalWeight = 0;

						for (var j = 1; j < item.length; j++) {
							totalWeight = totalWeight + item[j];
						};

						cc.log("totalWeight ::" + totalWeight);
						var rWeight = Common.randomInt(1,totalWeight);
						for (var j = 1; j < item.length; j++) {
							if (rWeight <= item[j]) {
								eQuality = j - 1;
								break;
							}else{
								rWeight = rWeight - item[j];
							}
						};
						break
					};
				};

				// 根据武器品质，确定武器加成的基础属性以及特殊属性
				var qItem = qualityConfig[eQuality];

				//确定加成基本属性 血，攻，暴，防，韧， 闪，命，速度
				var qNum = qItem[0];

				while(qNum != 0){
					var bNum = Common.randomInt(1,7);

					var isFind = false;
					for (var j = 0; j < baseArr.length; j++) {
						if(baseArr[j] == -1){
							isFind = true;
							break;
						}
					};

					if (!isFind) {
						baseArr.push(bNum);
						qNum = qNum - 1;
					};
				}

				//确定加成的特殊属性 
				var qNum = qItem[1];

				while(qNum != 0){
					var bNum = Common.randomInt(1,7);

					var isFind = false;
					for (var j = 0; j < specialArr.length; j++) {
						if(specialArr[j] == bNum){
							isFind = true;
							break;
						}
					};

					if (!isFind) {
						specialArr.push(bNum);
						qNum = qNum - 1;
					};
				}

				var eArr = {};
				eArr.quality = eQuality;
				eArr.variety = eVariety;
				eArr.baseArr = baseArr;
				eArr.specialArr = specialArr;

				gEquipArr.push(eArr);

				cc.log("eQuality ::: " + eQuality)
				cc.log("eVariety ::: " + eVariety)
				cc.log("baseArr ::: " + baseArr)
				cc.log("specialArr ::: " + specialArr)

				for(var v in gEquipArr[0]){
					cc.log("v ::: " + v,gEquipArr[0][v]);
				}
			};
		}
	}

	var instance;

	var _static = {
		name : "EffctManager",

		getInstance: function(){
			if (instance === undefined) {
			    instance = new _GPDataManager();
			}
			return instance;
		}
	};
	return _static;
})();