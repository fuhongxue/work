/**
 * Created by wangzhigang on 15/8/28.
 */

 var Level22 = {
 	// 地图类型 该类型下的第几套图
 	mapInfo : ["type1","02"],
 	temple  : "t02",
 	groups : [
 		//1,2,3,4级怪以及boss数量
		[2,2,0,0,0],
		[3,4,0,0,0],
		[1,3,4,0,0],
		[1,2,8,0,0],
		[0,2,5,4,0],
		[0,1,4,6,0],
		[0,1,3,8,1],

 	],
 	monster : [
		{hp : 157,attack : 6,gold : 6},
		{hp : 163,attack : 7,gold : 7},
		{hp : 169,attack : 8,gold : 8},
		{hp : 173,attack : 8,gold : 9},

 		// BOSS
		{hp : 400,attack : 30,gold : 27},

	],
 	adjustWidth : [128,136,114,254,232],
 }