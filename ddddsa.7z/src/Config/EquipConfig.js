

var EquipConfig = {
	// 品阶划分(限制数量) 
	// 基本属性 特殊属性 最高等级

	quality : [
		//普通（白）		
		[1,0,10],
		//精品（绿）		
		[2,0,20],
		//稀有（蓝）		
		[2,1,30],
		//完美（紫）		
		[2,1,40],
		//史诗（橙）		
		[2,2,50],
		//传说（黄）		
		[3,2,60],
	], 
	drop : {
		rate : [
			[1,1],
			[2,1],
			[3,1],
		],
		weight : [
			//1-10关 普通 精品 稀有 完美 史诗 传说权重
			[[1,10],1,0,0,0,0,0],
			[[10,30],1,0,0,0,0,0],
			[[30,50],0,2,1,0,0,0],
		],
	},
	// 基础属性权重
	baseAttr : {
		// 依次顺序：血，攻，暴，防，韧， 闪，命，速度
		variety : [
			//棍 杖	耙 铲
			[4,0,1,0],
			[0,4,1,0],
			[1,0,4,0],
			[0,1,0,4], 
			[4,0,0,1], 
			[0,4,0,1], 
			[0,1,4,0],
			[1,0,0,4], 
		],
		// 升级参数
		// 依次顺序：血，攻，暴，防，韧， 闪，命，速度
		upgradeConfig : [
			eval(EquipBaseUpgradeXue),
			eval(EquipBaseUpgradeGong),
			eval(EquipBaseUpgradeBao),
			eval(EquipBaseUpgradeFang),
			eval(EquipBaseUpgradeRen),
			eval(EquipBaseUpgradeShan),
			eval(EquipBaseUpgradeMing),
			eval(EquipBaseUpgradeSu),
		]
	},
	specialAttr : {
		text : [
			["复活","立即复活，回复x血量"],
			["毒液","攻击后敌方每秒损失x血量"],
			["回血","每秒回复x血量"],
			["格挡","有x的概率抵挡1次伤害"],
			["致命一击","致命一击概率"],
			["击晕","击晕概率"],
			["反击","损血量*反击系数"],
			["吸血","敌方损血量*吸血系数"],
			["嗜血","攻击加成=损血百分比*系数"],
			["技能冷却","某项技能冷却时间减少百分比"],
			["金钱增加","掉落金钱*（1+系数）"],
		],
		upgradeConfig : [
			

		]
	}

}