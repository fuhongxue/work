/**
 * Created by wangzhigang on 15/8/28.
 */

 var Level25 = {
 	// 地图类型 该类型下的第几套图
 	mapInfo : ["type1","02"],
 	temple  : "t02",
 	groups : [
 		//1,2,3,4级怪以及boss数量
		[2,2,0,0,0],
		[3,4,0,0,0],
		[1,3,4,0,0],
		[1,2,8,0,0],
		[0,2,5,4,0],
		[0,1,4,6,0],
		[0,1,3,8,1],

 	],
 	monster : [
		{hp : 181,attack : 7,gold : 7},
		{hp : 186,attack : 7,gold : 8},
		{hp : 192,attack : 8,gold : 9},
		{hp : 197,attack : 9,gold : 10},

 		// BOSS
		{hp : 220,attack : 23,gold : 30},

	],
 	adjustWidth : [128,136,114,254,232],
 }