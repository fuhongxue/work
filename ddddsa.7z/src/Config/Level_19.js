/**
 * Created by wangzhigang on 15/8/28.
 */

 var Level19 = {
 	// 地图类型 该类型下的第几套图
 	mapInfo : ["type1","02"],
 	temple  : "t02",
 	groups : [
 		//1,2,3,4级怪以及boss数量
		[2,2,0,0,0],
		[3,4,0,0,0],
		[1,3,4,0,0],
		[1,2,8,0,0],
		[0,2,5,4,0],
		[0,1,4,6,0],
		[0,1,3,8,1],

 	],
 	monster : [
		{hp : 134,attack : 6,gold : 5},
		{hp : 138,attack : 6,gold : 6},
		{hp : 145,attack : 7,gold : 7},
		{hp : 149,attack : 8,gold : 8},

 		// BOSS
		{hp : 170,attack : 20,gold : 24},

	],
 	adjustWidth : [128,136,114,254,232],
 }