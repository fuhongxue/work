/**
 * Created by wangzhigang on 15/8/28.
 */

 var Level12 = {
 	// 地图类型 该类型下的第几套图
 	mapInfo : ["type1","02"],
 	temple  : "t02",
 	groups : [
 		//1,2,3,4级怪以及boss数量
 		[2,2,0,0,0],
 		[4,3,0,0,0],
 		[2,3,3,0,0],
 		[2,3,6,0,0],
 		[0,3,5,3,0],
 		[0,2,4,5,0],
 		[0,2,3,7,1],

 	],
 	monster : [
		{hp : 86,attack : 4,gold : 3},
		{hp : 90,attack : 5,gold : 4},
		{hp : 93,attack : 5,gold : 5},
		{hp : 99,attack : 6,gold : 5},

 		// BOSS
		{hp : 110,attack : 14,gold : 15},

	],
 	adjustWidth : [128,136,114,254,232],
 }