/**
 * Created by wangzhigang on 15/8/28.
 */

 var Level2 = {
 	// 地图类型 该类型下的第几套图
 	mapInfo : ["type1","02"],
 	temple  : "t02",
 	groups : [
 		//1,2,3,4级怪以及boss数量
	 	[2,2,0,0,0],
		[4,3,0,0,0],
		[2,3,3,0,0],
		[2,3,6,0,0],
		[0,3,5,3,0],
		[0,2,4,5,0],
		[0,2,3,7,1],
		
 	],
 	monster : [
		{hp : 4,attack : 2,gold : 1},
		{hp : 6,attack : 2,gold : 1},
		{hp : 9,attack : 3,gold : 2},
		{hp : 12,attack : 3,gold : 2},

 		// BOSS
		{hp : 20,attack : 3,gold : 10},

 	],
 	adjustWidth : [128,136,114,254,232],
 }