/**
 * Created by wangzhigang on 15/8/28.
 */

 var Level9 = {
 	// 地图类型 该类型下的第几套图
 	mapInfo : ["type1","02"],
 	temple  : "t02",
 	groups : [
 		//1,2,3,4级怪以及boss数量
		[4,0,0,0,0],
		[5,2,0,0,0],
		[5,3,0,0,0],
		[4,3,4,0,0],
		[2,3,3,3,0],
		[2,2,3,4,0],
		[2,2,4,4,1],

 	],
 	monster : [
		{hp : 51,attack : 3,gold : 2},
		{hp : 51,attack : 4,gold : 3},
		{hp : 56,attack : 4,gold : 4},
		{hp : 56,attack : 4,gold : 4},

 		// BOSS
		{hp : 90,attack : 8,gold : 23},

 	],
 	adjustWidth : [128,136,114,254,232],
 }