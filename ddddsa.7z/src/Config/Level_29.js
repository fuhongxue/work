/**
 * Created by wangzhigang on 15/8/28.
 */

 var Level29 = {
 	// 地图类型 该类型下的第几套图
 	mapInfo : ["type1","02"],
 	temple  : "t02",
 	groups : [
 		//1,2,3,4级怪以及boss数量
		[4,0,0,0,0],
		[5,2,0,0,0],
		[5,3,0,0,0],
		[4,3,4,0,0],
		[2,3,3,3,0],
		[2,2,3,4,0],
		[2,2,4,4,1],

 	],
 	monster : [
		{hp : 214,attack : 8,gold : 9},
		{hp : 220,attack : 8,gold : 10},
		{hp : 226,attack : 9,gold : 11},
		{hp : 232,attack : 9,gold : 11},

 		// BOSS
		{hp : 260,attack : 25,gold : 33},

	],
 	adjustWidth : [128,136,114,254,232],
 }