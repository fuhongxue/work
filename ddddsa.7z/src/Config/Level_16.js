/**
 * Created by wangzhigang on 15/8/28.
 */

 var Level16 = {
 	// 地图类型 该类型下的第几套图
 	mapInfo : ["type1","02"],
 	temple  : "t02",
 	groups : [
 		//1,2,3,4级怪以及boss数量
		[2,2,0,0,0],
		[3,4,0,0,0],
		[1,3,4,0,0],
		[1,2,8,0,0],
		[0,2,5,4,0],
		[0,1,4,6,0],
		[0,1,3,8,1],

 	],
 	monster : [
		{hp : 113,attack : 5,gold : 4},
		{hp : 118,attack : 6,gold : 5},
		{hp : 123,attack : 7,gold : 6},
		{hp : 127,attack : 7,gold : 7},

 		// BOSS
		{hp : 140,attack : 18,gold : 18},

	],
 	adjustWidth : [128,136,114,254,232],
 }