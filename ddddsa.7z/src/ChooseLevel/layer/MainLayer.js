/**
 * Created by wangzhigang on 15/9/22.
 */

var CLMainLayer = cc.Layer.extend({
	fontLv  : null,
	ctor : function(){
		this._super();

		this.loadConfig();
		this.loadBg();
		this.loadLevelImage();
		this.loadLeftItem();
		this.loadRightItem();
		this.loadStartItem();
		this.loadLvUI();
		this.changeItemStatus();

	},
	loadConfig : function(){

	},
	loadBg : function(){
		var node = new cc.Sprite(res.ui_clbg01);
		this.addChild(node)

		node.setPosition(GC.w2,GC.h2);
	},
	loadLevelImage : function(){
		var node = new cc.Sprite(res.glass01);
		this.addChild(node)
		node.setScale(2)
		node.setPosition(GC.w2,GC.h2);
	},
	resetUI : function(){
		this.fontLv.removeFromParent();

		var fNode = Common.createFontNode(GameManager.getInstance().getCurLevel(),10);
		fNode.x = GC.w2-230;
		fNode.y = GC.h2+180;
		this.addChild(fNode);

		this.fontLv = fNode;

		this.changeItemStatus();

	},
	loadLvUI : function(){
		var node = new cc.Sprite(res.f05_ndlv);
		this.addChild(node)

		node.setPosition(GC.w2-280,GC.h2+180);

		var fNode = Common.createFontNode(GameManager.getInstance().getCurLevel(),10);
		fNode.x = GC.w2-230;
		fNode.y = GC.h2+180;
		this.addChild(fNode);

		this.fontLv = fNode;
	},
	changeItemStatus : function(){
		var curLevel = GameManager.getInstance().getCurLevel();
		var unlockLevel = GameManager.getInstance().getUnlockLevel();

		if (curLevel == 1) {
			this.leftItem.setVisible(false);
		}else{
			this.leftItem.setVisible(true);
		}

		if (curLevel == unlockLevel) {
			this.rightItem.setVisible(false);
		}else{
			this.rightItem.setVisible(true);
		}
	},
	loadLeftItem : function(){
		var self = this;

		var listener = cc.EventListener.create({
		    event: cc.EventListener.TOUCH_ONE_BY_ONE,
		    swallowTouches: true,
		    onTouchBegan: function (touch, event) {
		        var target = event.getCurrentTarget();

		        var locationInNode = target.convertToNodeSpace(touch.getLocation());
		        var s = target.getContentSize();
		        var rect = cc.rect(0, 0, s.width, s.height);

		        if (cc.rectContainsPoint(rect, locationInNode)) {
		            target.opacity = 180;
		            return true;
		        }
		        return false;
		    },
		    onTouchMoved: function (touch, event) {
		    },
		    onTouchEnded: function (touch, event) {
		        var target = event.getCurrentTarget();
		        cc.log("sprite onTouchesEnded.. ");
		        target.setOpacity(255);

		        var curLevel = GameManager.getInstance().getCurLevel();
		        if (curLevel -1 >=1) {
		        	GameManager.getInstance().setCurLevel(curLevel -1);
		        	GameManager.getInstance().saveLocalData();
		        	self.resetUI();
		        };
		    }
		});

		var node = new cc.Sprite(res.btn_l_sg01);
		this.addChild(node)

		node.setPosition(GC.w2 - 400,GC.h2);

		this.leftItem = node;

		cc.eventManager.addListener(listener, node);

	},
	loadRightItem : function(){
		var self = this;

		var listener = cc.EventListener.create({
		    event: cc.EventListener.TOUCH_ONE_BY_ONE,
		    swallowTouches: true,
		    onTouchBegan: function (touch, event) {
		        var target = event.getCurrentTarget();

		        var locationInNode = target.convertToNodeSpace(touch.getLocation());
		        var s = target.getContentSize();
		        var rect = cc.rect(0, 0, s.width, s.height);

		        if (cc.rectContainsPoint(rect, locationInNode)) {
		            target.opacity = 180;
		            return true;
		        }
		        return false;
		    },
		    onTouchMoved: function (touch, event) {
		    },
		    onTouchEnded: function (touch, event) {
		        var target = event.getCurrentTarget();
		        cc.log("sprite onTouchesEnded.. ");
		        target.setOpacity(255);

		        var curLevel = GameManager.getInstance().getCurLevel();
		        var unlockLevel = GameManager.getInstance().getUnlockLevel();

		        
		        if (curLevel  < unlockLevel) {
		        	GameManager.getInstance().setCurLevel(curLevel +1);
		        	GameManager.getInstance().saveLocalData();

		        	self.resetUI();
		        };
		    }
		});
		var node = new cc.Sprite(res.btn_z_sg01);
		this.addChild(node)

		node.setPosition(GC.w2 + 400,GC.h2);

		this.rightItem = node;

		cc.eventManager.addListener(listener, node);

	},
	loadStartItem : function(){
		var nodeNormal    = new cc.Sprite(res.btn_stragame02);
		var nodeSelected  = new cc.Sprite(res.btn_stragame01);
		var nodeDisabled  = new cc.Sprite(res.btn_stragame02);

		var node = new cc.MenuItemSprite(
		nodeNormal,
		nodeSelected,
		nodeDisabled,
		function(){
			cc.director.runScene(new GamePlayScene());
		}.bind(this));

		node.x = GC.w2;
		node.y = node.getContentSize().width/2;

		var menu = new cc.Menu();
		menu.setPosition(0, 0);
		menu.addChild(node);
		this.addChild(menu);
	},
});