/**
 * Created by wangzhigang on 15/9/22.
 */

var glassContent = {
	width : 284,
	height : 160,
}

var CLMainLayer = cc.Layer.extend({
	fontLv  : null,
	curGlass : null,
	clipper  : null,
	ratingArr : null,
	ctor : function(){
		this._super();

		this.loadConfig();
		this.loadBg();
		this.loadLevelImage();
		this.loadLeftItem();
		this.loadRightItem();
		this.loadStartItem();
		this.loadLvUI();
		this.changeItemStatus();
		this.loadHuaWen();
		this.loadMoveAnimation();
		this.loadRatingUI();

		this.loadEquipItem();



		var label2 = new cc.LabelBMFont("难度12344567894560.:", res.dyfont01_0_fnt);
		// testing anchors
		label2.anchorX = 0.5;
		label2.anchorY = 0.5;
		label2.x = GC.h -100;
		label2.y = GC.w2;
		this.addChild(label2,1000);

	},
	loadConfig : function(){

	},
	loadEquipItem : function(){
		var nodeNormal    = new cc.Sprite(res.btn_sc02);
		var nodeSelected  = new cc.Sprite(res.btn_sc01);
		var nodeDisabled  = new cc.Sprite(res.btn_sc02);

		var node = new cc.MenuItemSprite(
		nodeNormal,
		nodeSelected,
		nodeDisabled,
		function(){
			EquipController.getInstance().enterEquipUI();
		}.bind(this));

		node.x = GC.w - 100;
		node.y = GC.h2;

		var menu = new cc.Menu();
		menu.setPosition(0, 0);
		menu.addChild(node);
		this.addChild(menu);
	},
	loadMoveAnimation : function(){
		if(GameManager.getInstance().isShowMove){
			this.moveGlass("right")
		}
	},
	loadHuaWen : function(){
		var node = new cc.Sprite(res.ui_zzb01);
		this.addChild(node)
		node.anchorX = 0;
		node.anchorY = 1;

		node.setPosition(GC.w2 - glassContent.width,GC.h2 + glassContent.height)

		var node = new cc.Sprite(res.ui_zzb02);
		this.addChild(node)
		node.anchorX = 1;
		node.anchorY = 1;

		node.setPosition(GC.w2 + glassContent.width,GC.h2 + glassContent.height)

		var node = new cc.Sprite(res.ui_zzb03);
		this.addChild(node)
		node.anchorX = 0;
		node.anchorY = 0;

		node.setPosition(GC.w2 - glassContent.width,GC.h2 - glassContent.height)

		var node = new cc.Sprite(res.ui_zzb04);
		this.addChild(node)
		node.anchorX = 1;
		node.anchorY = 0;

		node.setPosition(GC.w2 + glassContent.width,GC.h2 - glassContent.height)
	},
	loadBg : function(){
		var node = new cc.Sprite(res.ui_clbg01);
		this.addChild(node)

		node.setPosition(GC.w2,GC.h2);
	},
	loadLevelImage : function(){
        var clipper = new cc.ClippingNode();
        clipper.width = glassContent.width*GC.SCALE_RATE/2;
	    clipper.height = glassContent.height*GC.SCALE_RATE;
        clipper.anchorX = 0.5;
        clipper.anchorY = 0.5;
        clipper.x = GC.w2;
        clipper.y = GC.h2;
        // clipper.runAction(cc.rotateBy(1, 45).repeatForever());
        this.addChild(clipper);

        var stencil = new cc.DrawNode();
        var rectangle = [cc.p(0, 0),cc.p(clipper.width, 0),
            cc.p(clipper.width, clipper.height),
            cc.p(0, clipper.height)];

        var white = cc.color(255, 255, 255, 255);
        stencil.drawPoly(rectangle, white, 1, white);
        clipper.stencil = stencil;


        this.clipper = clipper;

        var resName = "";
        var curLevel = -1;
        if(GameManager.getInstance().isShowMove){
        	curLevel = GameManager.getInstance().getCurLevel() -1;
        }else{
        	curLevel = GameManager.getInstance().getCurLevel();
        }


        var resName = eval("Level" + curLevel).glass;

		var node = new cc.Sprite(res[resName]);
		clipper.addChild(node)
		node.setScale(2)
		node.setPosition(GC.w2 - glassContent.width,GC.h2);

		this.curGlass  = node;
	},
	resetUI : function(){
		this.fontLv.removeFromParent();

		var fNode = Common.createFontNode(GameManager.getInstance().getCurLevel(),10);
		fNode.x = GC.w2-230;
		fNode.y = GC.h2+180;
		this.addChild(fNode);

		this.fontLv = fNode;

		this.changeItemStatus();
	},
	moveGlass : function(type){
		var self = this;

		var resName = ""

		var curLevel = GameManager.getInstance().getCurLevel();
		var resName = eval("Level" + curLevel).glass;


		var moveDis = 0;
		var addDis = 40;
		if (type == "Left") {
			moveDis = glassContent.width*2 + addDis
		}else{
			moveDis = -glassContent.width*2 - addDis
		}


		var preNode = self.curGlass;
		var action = cc.moveBy(0.3,cc.p(moveDis,0));
		var callBack = cc.callFunc(function(){
			this.removeFromParent();
		}.bind(preNode));

		preNode.runAction(cc.sequence(action,callBack) );

		var node = new cc.Sprite(res[ resName ]);
		self.clipper.addChild(node)
		node.setScale(2)

		if (type == "Left") {
			node.setPosition(GC.w2 - 3*glassContent.width - addDis,GC.h2);
		}else{
			node.setPosition(GC.w2 + glassContent.width + addDis,GC.h2);
		}
		var action = cc.moveBy(0.3,cc.p(moveDis,0));
		var callBack = cc.callFunc(function(){
			self.isMove = false;
			self.curGlass  = this;
			if (GameManager.getInstance().isShowMove) {
				GameManager.getInstance().isShowMove = false;
			};
		}.bind(node));
		node.runAction(cc.sequence(action,callBack) );

		self.isMove = true;
	},
	loadLvUI : function(){
		var node = new cc.Sprite(res.f05_ndlv);
		this.addChild(node)

		node.setPosition(GC.w2-280,GC.h2+180);

		var fNode = Common.createFontNode(GameManager.getInstance().getCurLevel(),10);
		fNode.x = GC.w2-230;
		fNode.y = GC.h2+180;
		this.addChild(fNode);

		this.fontLv = fNode;
	},
	changeItemStatus : function(){
		var curLevel = GameManager.getInstance().getCurLevel();
		var unlockLevel = GameManager.getInstance().getUnlockLevel();

		if (curLevel == 1) {
			this.leftItem.setVisible(false);
		}else{
			this.leftItem.setVisible(true);
		}

		if (curLevel == unlockLevel) {
			this.rightItem.setVisible(false);
		}else{
			this.rightItem.setVisible(true);
		}

	},
	loadLeftItem : function(){
		var self = this;

		var listener = cc.EventListener.create({
		    event: cc.EventListener.TOUCH_ONE_BY_ONE,
		    swallowTouches: true,
		    onTouchBegan: function (touch, event) {

		    	if (!self.isMove) {
		    		var target = event.getCurrentTarget();

		    		if (!target.isVisible()) {return false};

		    		var locationInNode = target.convertToNodeSpace(touch.getLocation());
		    		var s = target.getContentSize();
		    		var rect = cc.rect(0, 0, s.width, s.height);

		    		if (cc.rectContainsPoint(rect, locationInNode)) {
		    		    target.opacity = 180;
		    		    var curLevel = GameManager.getInstance().getCurLevel();
		    		    if (curLevel -1 >=1) {
		    		    	GameManager.getInstance().setCurLevel(curLevel -1);
		    		    	GameManager.getInstance().saveLocalData();
		    		    	self.resetUI();
		    		    	self.loadRatingUI();
		    		    	self.moveGlass("Left");
		    		    };

		    		    return true;
		    		}
		    	};

		        return false;
		    },
		    onTouchMoved: function (touch, event) {
		    },
		    onTouchEnded: function (touch, event) {
	    		var target = event.getCurrentTarget();
	    		target.setOpacity(255);
		    }
		});

		var node = new cc.Sprite(res.btn_l_sg01);
		this.addChild(node)

		node.x = GC.w2 - 200;
		node.y = 120;


		this.leftItem = node;

		cc.eventManager.addListener(listener, node);

	},
	loadRightItem : function(){
		var self = this;

		var listener = cc.EventListener.create({
		    event: cc.EventListener.TOUCH_ONE_BY_ONE,
		    swallowTouches: true,
		    onTouchBegan: function (touch, event) {
		    	if (!self.isMove) {
		    		var target = event.getCurrentTarget();

		    		var locationInNode = target.convertToNodeSpace(touch.getLocation());
		    		var s = target.getContentSize();
		    		var rect = cc.rect(0, 0, s.width, s.height);

		    		// if (!target.isVisible()) {return false};

		    		if (cc.rectContainsPoint(rect, locationInNode)) {
		    		    target.opacity = 180;

		    		    var curLevel = GameManager.getInstance().getCurLevel();
		    		    var unlockLevel = GameManager.getInstance().getUnlockLevel();

		    		    
		    		    if (curLevel  < unlockLevel) {
		    		    	GameManager.getInstance().setCurLevel(curLevel +1);
		    		    	GameManager.getInstance().saveLocalData();

		    		    	self.resetUI();
		    		    	self.loadRatingUI();
		    		    	self.moveGlass("Right");

		    		    };

		    		    return true;
		    		}
				}

		        return false;
		    },
		    onTouchMoved: function (touch, event) {
		    },
		    onTouchEnded: function (touch, event) {
	    		var target = event.getCurrentTarget();
	    		target.setOpacity(255);
		    }
		});
		var node = new cc.Sprite(res.btn_z_sg01);
		this.addChild(node)

		node.x = GC.w2 + 200;
		node.y = 120;

		this.rightItem = node;

		cc.eventManager.addListener(listener, node);

	},
	loadStartItem : function(){
		var nodeNormal    = new cc.Sprite(res.btn_stragame02);
		var nodeSelected  = new cc.Sprite(res.btn_stragame01);
		var nodeDisabled  = new cc.Sprite(res.btn_stragame02);

		var node = new cc.MenuItemSprite(
		nodeNormal,
		nodeSelected,
		nodeDisabled,
		function(){
			cc.director.runScene(new GamePlayScene());
		}.bind(this));

		node.x = GC.w2;
		node.y = node.getContentSize().width/2;

		var menu = new cc.Menu();
		menu.setPosition(0, 0);
		menu.addChild(node);
		this.addChild(menu);
	},
	loadRatingUI : function(){
		if (this.ratingArr) {
			for (var i = 0; i < this.ratingArr.length; i++) {
				this.ratingArr[i].removeFromParent(true);
				this.ratingArr[i] = null;
			};
		}else{
			this.ratingArr = [];
		}

		var curLevel = GameManager.getInstance().getCurLevel();

		var params = GameManager.getInstance().getRatingParams(GC.RATING_TYPE.INTRODUCE,curLevel);

		var rating = params.rating;

		var baseHeight = GC.h2 + 120;
		var baseWidth  = GC.w2 - 230;
		var baseDis = 60;
		for (var i = 0; i < rating.length; i++) {
			var bool = rating[i];

			var node = new cc.Sprite(res.starbg_01);
			node.setPosition(baseWidth ,baseHeight- i*baseDis);
			this.addChild(node,2);
			
			if (bool) {
				var node = new cc.Sprite(res.starbig_01);
				node.setPosition(baseWidth ,baseHeight- i*baseDis);
				this.addChild(node,2);
			}
			this.ratingArr[i] = node;

			var listener = cc.EventListener.create({
			    event: cc.EventListener.TOUCH_ONE_BY_ONE,
			    swallowTouches: true,
			    onTouchBegan: function (touch, event) {

		    		var target = event.getCurrentTarget();

		    		var locationInNode = target.convertToNodeSpace(touch.getLocation());
		    		var s = target.getContentSize();
		    		var rect = cc.rect(0, 0, s.width, s.height);

		    		if (cc.rectContainsPoint(rect, locationInNode)) {
						new RatingBox(params);
		    		    return true;
		    		}

			        return false;
			    },
			});

			cc.eventManager.addListener(listener, node);
		};
	}
});