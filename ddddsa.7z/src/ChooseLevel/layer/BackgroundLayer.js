/**
 * Created by wangzhigang on 15/9/22.
 */

var CLBackgroundLayer = cc.Layer.extend({
	ctor : function(){
		this._super();
	},
});