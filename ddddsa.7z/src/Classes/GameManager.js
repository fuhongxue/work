/**
 * Created by wangzhigang on 15/4/19.
 */

// 游戏管理对象，单例类
var GameManager = (function () {

    function _GameManager() {
	
        // 英雄对象
        this.heroObj = null;
        this.parallaxLayer = null;
        this.characterVector = [];

        //二维数组 第一维表示第几波 第二维表示具体对象
        this.monsterVector = [];  
        //阶段间怪物的距离
        this.monsterDisVector = [];

        //配置信息
        this.monsterGroupInfo = [];
        this.monsterInfo = [];
        this.characterInfo = [];

        // 血， 攻，暴，防，韧， 闪，命;
        this.characterData = [0,0,0,0,0,0,0];


        // 游戏本地数据存储字段
        this.localData = null;

        this.clear = function(){
            this.monsterVector = [];
            this.characterVector = [];
            this.GPUpgradeSiteLayer = null;
            this.characterData = [0,0,0,0,0,0,0];
        };
        this.initLocalData = function(){
            this.localData = {

                // 游戏金币
                gold : 0,
                // 当前停留在哪一个关卡
                curLevel : 1, 
                // 已解锁到哪一个关卡     
                unlockLevel : 1,   

                // 角色等级，依次 悟空，唐僧，八戒，沙僧
                characterLevel : [0,0,0,0],
                //角色伙伴解锁状态： 0: 未解锁 1：已解锁，未上阵 2：已上阵
                partnerUnlockStatus : {
                    "bajie"     : 0,
                    "tangseng"  : 0,
                    "shaseng"   : 0,
                },  

                // 技能等级,依次为 筋斗云，金箍棒，分身
                skillLevel : [0,0,0],

                // 升级界面悟空栏 解锁状态：  0: 未解锁 1：已解锁，未上阵 2：已上阵
                skillUnlockStatus : {
                    "wukong" : 2,
                    "jindouyun" : 0,
                    "jingubang" : 0,
                    "jingang"   : 0,
                },

                // 每一个关卡星级完成情况 默认是 [false,false,false]
                rating : [],
                
                ratingStar : 0,      //星星各数
                ratingUnlockNum : 0, //星级解锁顺序现在到几了

                // 装备列表
                /*
                    {
                        //品质从0开始，依次代表 普通 精品  稀有  完美  史诗  传说
                        quality : 0,
                        // 武器类型从0开始， 棍  杖   耙   铲
                        variety : 0,
                        // 加成基本属性 数组 血，攻，暴，防，韧， 闪，命，速度
                        baseArr : [],
                        // 加成特殊属性 数组
                        specialArr : [],
                        // 等级
                        lv : 0,
                        // 是否装备了
                        isEquiped : false
                    }
                */
                equipArr : [],
            };
        };
        //========[localstorage]===========
        this.clearLocalData = function(){
            this.localData = "";
            this.saveLocalData();
        },
        this.saveLocalData = function(){
            var localData = JSON.stringify(this.localData);  
            cc.sys.localStorage.setItem("localData", Crypto.encrypt(localData));  
        };
        this.loadLocalStorage = function(){
            var localData = cc.sys.localStorage.getItem("localData");  
            if (localData == null || localData == "") {
                this.initLocalData();
                this.saveLocalData();
                this.localData = JSON.parse(Crypto.decrypt(cc.sys.localStorage.getItem("localData")) );
            }else{
                this.localData = JSON.parse(Crypto.decrypt(localData) );
            }
            // this.localData.partnerUnlockStatus["tangseng"] = 1;
            // this.localData.partnerUnlockStatus["bajie"] = 1;
            // this.localData.partnerUnlockStatus["shaseng"] = 1;
            // this.localData.gold = 200000000;
            // this.localData.unlockLevel = 50;
            // this.localData.ratingStar = 1000;

            this.localData.equipArr = [
                {quality : 0,variety : 0,baseArr : [0,2,0,0,0,0,0,0],specialArr : [0,1,0,0,0,0,0,0,0,0,0],lv : 0,isEquiped : false},
                {quality : 0,variety : 0,baseArr : [0,2,0,0,0,0,0,0],specialArr : [0,1,0,0,0,0,0,0,0,0,0],lv : 0,isEquiped : false},
                {quality : 0,variety : 0,baseArr : [0,2,0,0,0,0,0,0],specialArr : [0,1,0,0,0,0,0,0,0,0,0],lv : 0,isEquiped : false},
                {quality : 0,variety : 0,baseArr : [0,2,0,0,0,0,0,0],specialArr : [0,1,0,0,0,0,0,0,0,0,0],lv : 0,isEquiped : false},
                {quality : 0,variety : 0,baseArr : [0,2,0,0,0,0,0,0],specialArr : [0,1,0,0,0,0,0,0,0,0,0],lv : 0,isEquiped : false},
                {quality : 0,variety : 0,baseArr : [0,2,0,0,0,0,0,0],specialArr : [0,1,0,0,0,0,0,0,0,0,0],lv : 0,isEquiped : false},
                {quality : 0,variety : 0,baseArr : [0,2,0,0,0,0,0,0],specialArr : [0,1,0,0,0,0,0,0,0,0,0],lv : 0,isEquiped : false},
                {quality : 0,variety : 0,baseArr : [0,2,0,0,0,0,0,0],specialArr : [0,1,0,0,0,0,0,0,0,0,0],lv : 0,isEquiped : false},
                {quality : 0,variety : 0,baseArr : [0,2,0,0,0,0,0,0],specialArr : [0,1,0,0,0,0,0,0,0,0,0],lv : 0,isEquiped : false},

            ]

        };
        this.getCharacterLevel = function(id){
            return this.localData.characterLevel[id];
        },
        this.setCharacterLevel = function(id,value){
            this.localData.characterLevel[id] = value;
        },
        this.resetRoleData = function(){
            for (var i = this.characterData.length - 1; i >= 0; i--) {
                this.characterData[i] = 0;
            };

            for (var i = 0; i < this.characterInfo.length; i++) {
                var info = this.characterInfo[i];
                var level = this.localData.characterLevel[i];
                var config = info.config;
                var field = info.field;

                if(i > 0 && this.localData.partnerUnlockStatus[info.cName] != 2){
                    continue;
                }

                if (info.baseHp) {
                    this.characterData[0] = this.characterData[0] + info.baseHp;
                };

                this.characterData[field[0]] = this.characterData[field[0]] + config[level][0];
            };
        },
        this.getCurLevel = function(){
            return this.localData.curLevel;
        },
        this.setCurLevel = function(v){
            this.localData.curLevel = v;
        },
        this.getUnlockLevel = function(){
            return this.localData.unlockLevel;
        },
        this.setUnlockLevel = function(v){
            this.localData.unlockLevel = v;
        },
        this.isPartnerUnlocked = function(v){
            return this.localData.partnerUnlockStatus[v] == 2 ? true : false;
        },
        this.getPartnerUnlockedStatus = function(v){
            return this.localData.partnerUnlockStatus[v];
        },
        this.setPartnerUnlockedStatus = function(n,v){
            this.localData.partnerUnlockStatus[n] = v;
        },
        this.unlockPartner = function(){
            var curLevel = this.localData.curLevel;
            for (var i = 0; i < this.characterInfo.length; i++) {
                var info = this.characterInfo[i];
                if (this.localData.partnerUnlockStatus[info.cName] == 0) {
                    if (info.unlockLevel && info.unlockLevel == curLevel) {
                        this.localData.partnerUnlockStatus[info.cName] = 1;
                    };
                };

            }
        },
        this.getSkillUnlockedStatus = function(v){
            return this.localData.skillUnlockStatus[v];
        },
        this.getUnlockSkillNum = function(){
            var num = 0;
            var skillUnlockStatus = this.localData.skillUnlockStatus;

            var arr = [
                "wukong",
                "jindouyun",
                "jingubang",
                "jingang",
            ];

            for (var i = 0; i < arr.length; i++) {
                var str = arr[i];

                if(skillUnlockStatus[str] == 0){

                    var ratingCondition = RatingConfig.condition;
                    var unlockSequence = RatingConfig.unlock;

                    var ratingUnlockNum = this.localData.ratingUnlockNum;
                    var unlockItem = unlockSequence[ratingUnlockNum];

                    for (var j = 0; j < unlockItem.length; j++) {
                        var cItem = unlockItem[j];

                        if (ratingCondition[cItem][0] == 2 && ratingCondition[cItem][1] == str) {
                            num = num + 1;
                            break;
                        }
                    };
                }else{
                    num = num + 1;
                }
            };
            return num;
        },
        this.getUnlockPartnerNum = function(){
            var num = 0;
            var partnerUnlockStatus = this.localData.partnerUnlockStatus;

            var arr = [
                "tangseng",
                "bajie",
                "shaseng",
            ];

            for (var i = 0; i < arr.length; i++) {
                var str = arr[i];

                if(partnerUnlockStatus[str] == 0 ){
                    var ratingCondition = RatingConfig.condition;
                    var unlockSequence = RatingConfig.unlock;

                    var ratingUnlockNum = this.localData.ratingUnlockNum;
                    var unlockItem = unlockSequence[ratingUnlockNum];

                    for (var j = 0; j < unlockItem.length; j++) {
                        var cItem = unlockItem[j];

                        if (ratingCondition[cItem][0] == 1 && ratingCondition[cItem][1] == str) {
                            num = num + 1;
                            break;
                        }
                    };
                }else{
                    num = num + 1;
                }
            };

             return num;
        },
        this.getSkillIndexByField = function(name,v){
            var index = 0;
            var field = this.skillInfo[name].field
            for (var i = 0; i < field.length; i++) {
                if(field[i] == v){
                    index = i;
                    break
                }
            };
            return index;
        },
        this.getSkillNeedGold = function(name){
            if (name == "wukong") {
                return this.getCharacterNeedGold(0);
            };
            var config = this.skillInfo[name].config;
            var lv = this.getSkillLv(name);
            var index = this.getSkillIndexByField(name,"gold");

            return config[lv][index];
        },
        this.getSkillLv = function(name){
            if (name == "wukong") {
                return this.getCharacterLevel(0);
            };
            var id =    this.skillInfo[name].id;

            return this.localData.skillLevel[id];
        },
        this.setSkillLv = function(name,v){
            if (name == "wukong") {
                return this.setCharacterLevel(0,v);
            };
            var id =    this.skillInfo[name].id;

            this.localData.skillLevel[id] = v;
        },
        this.getSkillRate = function(name){
            var lv = this.getSkillLv(name)

            return this.skillInfo[name].config[lv][0];
        },
        this.setSkillRate = function(name,v){
            if (name == "wukong") {
                return this.setCharacterLevel(0,v);
            };
            var id =    this.skillInfo[name].id;

            this.localData.skillLevel[id] = v;
        },
        this.getSkillUnlockedStatus = function(name){
            return this.localData.skillUnlockStatus[name];
        },
        this.setSkillUnlockedStatus = function(name,v){
            return this.localData.skillUnlockStatus[name] = v;
        },
        this.getStarNum = function(){
            return this.localData.ratingStar;
        },
        this.unlockSkillAndPartner = function(){
            var self = this;

            var ratingCondition = RatingConfig.condition;
            var unlockSequence = RatingConfig.unlock;

            var skillStatus = this.localData.skillUnlockStatus;
            var partnerStatus = this.localData.partnerUnlockStatus;
            var ratingStar = this.localData.ratingStar;

            function judge(){
                var ratingUnlockNum = self.localData.ratingUnlockNum;
                if (unlockSequence[ratingUnlockNum]) {
                    var unlockItem = unlockSequence[ratingUnlockNum];

                    var isAllUnlock = true;
                    var curStatus = null;
                    for (var j = 0; j < unlockItem.length; j++) {
                        var cItem = unlockItem[j];

                        if (ratingCondition[cItem][0] == 1) {
                            curStatus = partnerStatus
                        }else{
                            curStatus = skillStatus;
                        }

                        if(curStatus[ratingCondition[cItem][1]] < 2){

                            isAllUnlock = false;
                            if (ratingStar >= ratingCondition[cItem][2]) {
                                curStatus[ratingCondition[cItem][1]] = 1;
                            }else{
                                curStatus[ratingCondition[cItem][1]] = 0;
                            }
                        }
                    };

                    if (isAllUnlock) {
                        self.localData.ratingUnlockNum = self.localData.ratingUnlockNum + 1;
                        judge();
                    };
                };
            }
            judge();
        },
        //========[localstorage]===========

        // ==============[getter && setter]==============
        this.setHeroObj = function(heroObj) {
           this.heroObj = heroObj;
        };
        this.getHeroObj = function() {
             return this.heroObj;
        };
        this.setParallaxLayer = function(obj) {
            this.parallaxLayer = obj;
        };
        this.getParallaxLayer = function() {
            return this.parallaxLayer;
        };
        this.getMonsterVector = function() {
            return this.monsterVector;
        };
        this.getMonsterGroupVector = function() {
            return this.monsterGroupInfo;
        };
        this.setMonsterDisVector = function(obj) {
            this.monsterDisVector = obj;
        };
        this.getMonsterDisVector = function() {
            return this.monsterDisVector;
        };
        this.getCharacterInfo = function() {
            return this.characterInfo;
        };
        this.getMonsterInfo = function() {
            return this.monsterInfo;
        };
        this.getCharacterData = function(){
            return this.characterData;
        };
        this.getCharacterVector = function() {
            return this.characterVector;
        };
        this.getGold = function(){
            return this.localData.gold;
        };
        this.setGold = function(value){
            if (value < 0 ) {
                value = 0;
            };
            this.localData.gold = value;
        };
        this.getCharacterNeedGold = function(id){
            var level = this.localData.characterLevel[id];
            var config = this.characterInfo[id]["config"];
            return config[level + 1] ? config[level + 1][1] : 0;
        };
        this.getCharacterAddAttr = function(id){
            var level = this.localData.characterLevel[id];
            var info = this.characterInfo[id];
            var config = info.config;

            return config[level+1] ? (config[level+1][0] - config[level][0]) : 0;
        },
        this.getMonsterImageInfoByField = function(level,field){
            var imgIndex = GameManager.getInstance().getMonsterInfo()[level][2];
            var img = MonsterImageInfo[imgIndex][field];

            return img;
        },
        //检测升级界面两个切换按钮是否显示红点
        this.checkIsShowTips = function(){
            var ret = [false,false];

            var sArr = this.localData.skillUnlockStatus;

            for(var v in sArr){
                var status = sArr[v];
                if (status == 1) {
                    ret[0] = true;
                    break
                }else if (status == 2) {
                    var value = GameManager.getInstance().getSkillNeedGold(v);
                    var gold = GameManager.getInstance().getGold();

                    if (gold >= value) {
                        ret[0] = true;
                        break;
                    }
                };
            }

            var sArr = this.localData.partnerUnlockStatus;
            var strArr = [
                "bajie"    ,
                "tangseng" ,
                "shaseng"  ,  
            ];

            var num = 0;
            for (var i = 0; i < strArr.length; i++) {
                var str = strArr[i]
                var status = sArr[str];

                if (status == 1) {
                    ret[1] = true;
                    break
                }else if (status == 2) {
                    var value = GameManager.getInstance().getCharacterNeedGold(i);
                    var gold = GameManager.getInstance().getGold();

                    if (gold >= value) {
                        ret[1] = true;
                        break;
                    }
                };
            };

            return ret;
        },
        //计算星级显示信息
        this.getRatingParams = function(type,level){
            var params = {};
            params.type = type;

            var rating = this.localData.rating[level] ? this.localData.rating[level] : [false,false,false];

            params.rating = Common.deepCopy(rating);
            params.text = [];
            var ratingCondition = eval("Level" + level).rating;

            for (var i = 0; i < ratingCondition.length; i++) {
                var c1 = ratingCondition[i][0];
                var c2 = ratingCondition[i][1];

                if (RatingConfig.text[c1][0] == c2) {
                    params.text[i] = RatingConfig.text[c1][2];
                }else{
                    var num = c2;
                    if (c1 == 4) {
                        num = c2*100 + "%"
                    };
                    params.text[i] = RatingConfig.text[c1][1].format(num);
                }

                if (type == GC.RATING_TYPE.PAUSE) {
                    var ratingData = GPDataManager.getInstance().ratingData;
                    if (!params.rating[i]) {
                        if ( RatingConfig.text[c1][3] == "less") {
                            if (ratingData[c1] < c2) {
                                params.rating[i] = true;
                            };
                        }else if(RatingConfig.text[c1][3] == "more"){
                            if (ratingData[c1] > c2) {
                                params.rating[i] = true;
                            };
                        }else if (RatingConfig.text[c1][3] == "lessOrequal") {
                            if (ratingData[c1] <= c2) {
                                params.rating[i] = true;
                            };
                        };
                    };
                };

            };

            return params;
        }
	}

	//实例容器
    var instance;

    var _static = {
        name: 'GameManager',
        //获取实例的方法
        //返回Singleton的实例
        getInstance: function () {
            if (instance === undefined) {
                instance = new _GameManager();
            }
            return instance;
        }
    };
    return _static;
})();