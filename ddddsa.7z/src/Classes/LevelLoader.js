/**
 * Created by wangzhigang on 15/8/28.
 */

var LevelLoader = cc.Class.extend({
	levelConfig 	: null,
	characterVector : [],
	ctor : function(level) {
		this.loadConifg(level);
		this.loadLevelInfo();
	},
	loadConifg : function(level) {
		this.characterVector = [];

		this.levelConfig = eval("Level" + level);

		for (var i = 1; i <= 4; i++) {
			this.characterVector.push( eval("Character" + i) );
		};

		this.skillInfo = Skill;
	},
	loadLevelInfo : function() {
		// 将数据加入到GameManager单例对象中
		var instance = GameManager.getInstance();
		instance.clear();
		EffectManager.getInstance().init();

		instance.monsterGroupInfo = this.levelConfig.groups;
		instance.monsterInfo = this.levelConfig.monster;
		instance.mapInfo = this.levelConfig.mapInfo;
		instance.temple = this.levelConfig.temple;
		instance.adjustWidth = this.levelConfig.adjustWidth;
		instance.characterInfo = this.characterVector;
		instance.skillInfo = this.skillInfo;

		instance.resetRoleData();

		instance.tempWidth = [200,47*4,57*4,89*4,92*4]

	}
});
