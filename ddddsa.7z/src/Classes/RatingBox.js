

var RatingBox = cc.Sprite.extend({
	type : null,
	bg   : null,
	ctor : function(params){
		this._super();
		cc.director.getRunningScene().addChild(this,1000);

		this.type = params.type;
		this.bindListener();
		this.loadGrayLayer();
		this.loadBg();
		this.loadRatingInfo(params);

		if (this.type == GC.RATING_TYPE.INTRODUCE) {
			this.loadLevelTitle();
			this.loadFanHuiBtn();
		}else if (this.type == GC.RATING_TYPE.PAUSE) {
			this.loadLevelTitle();
			this.loadPauseBtn();
		}else if (this.type == GC.RATING_TYPE.SUCCED) {
			this.loadBgEffect();
			this.loadSucceedTitle();
			this.loadQueDingBtn();
			this.loadStarBg(params);

			this.setCascadeOpacityEnabled(true);

			this.setOpacity(0)
			var action = cc.fadeIn(2);
			this.runAction(action);
		};


	},
	onTouchBegan: function (touch, event) {
		var target = this.target;

		return true;
	},
	bindListener : function(){
		var listener = cc.EventListener.create({
		    event           : cc.EventListener.TOUCH_ONE_BY_ONE,
		    target          : this,
		    swallowTouches  : true,
		    onTouchBegan    : this.onTouchBegan,
		});
		cc.eventManager.addListener(listener, this);
	},
	loadGrayLayer : function(){
		var color = null;
		if (this.type == GC.RATING_TYPE.SUCCED) {
			color = cc.color(0,0,0,255);
		}else{
			color = cc.color(0,0,0,180);
		}
		var node = new cc.LayerColor(color, GC.w, GC.h);
		this.addChild(node,-2);

	},
	loadBg : function(){
		var node = new cc.Sprite(res.ui_tanchuangbg);
		this.addChild(node,0);
		node.x = GC.w2;
		node.y = GC.h2;

		this.bg = node;

	},
	loadLevelTitle : function(){
		var node = new cc.Sprite(res.ui_namebg01);
		this.addChild(node,1);
		node.x = GC.w2;
		node.y = GC.h2 + this.bg.getBoundingBox().height/2;
	},
	loadSucceedTitle : function(){
		var node = new cc.Sprite(res.font_victory);
		this.addChild(node,1);
		node.anchorY = 1;
		node.x = GC.w2;
		node.y = GC.h2 + this.bg.getBoundingBox().height/2;
	},
	loadRatingInfo : function(params){
		var text = params.text;
		var rating = params.rating;

		var type = params.type;

		var grayColor = cc.color(98,88,88);
		var whiteColor = cc.color(255,255,255);

		for (var i = 0; i < text.length; i++) {
			var isLighted = false;

			if (rating[i]) {
				isLighted = true;
			};

			var pNode = new cc.Node();
			this.addChild(pNode);
			pNode.setPosition(GC.w2-200,GC.h2 + 40 - i * 60);


			var resName = "";
			var fillStyle = null;
			if (isLighted) {
				resName = res.starbig_01;
				fillStyle = whiteColor;
			}else{
				resName = res.starbg_01;
				fillStyle = grayColor;
			}

			var node = new cc.Sprite(resName);
			pNode.addChild(node);
			node.anchorX = 0;
			node.anchorY = 0;

			var textdef = new cc.FontDefinition();
			textdef.fontName = "Arial";
			textdef.fontSize = 32;
			textdef.fillStyle = fillStyle;

			var labelText = text[i]
			node = new cc.LabelTTF(labelText);
			node.anchorX = 0;
			node.anchorY = 0;
			node.x = 80;

			node.setTextDefinition(textdef)
			pNode.addChild(node);

		};
	},
	loadQueDingBtn : function(){
		var nodeNormal    = new cc.Sprite(res.btn_qd01);
		var nodeSelected  = new cc.Sprite(res.btn_qd02);
		var nodeDisabled  = new cc.Sprite(res.btn_qd01);

		var node = new cc.MenuItemSprite(
		nodeNormal,
		nodeSelected,
		nodeDisabled,
		function(){
			var transitionScene = new cc.TransitionFade(0.1, new ChooseLevelScene());
			cc.director.runScene(transitionScene);		
		}.bind(this));

		node.x = GC.w2;
		node.y = GC.h2 - this.bg.getBoundingBox().height/2;

		var menu = new cc.Menu();
		menu.setPosition(0, 0);
		menu.addChild(node);
		this.addChild(menu);
	},
	loadPauseBtn : function(){
		var nodeNormal    = new cc.Sprite(res.btn_tc01);
		var nodeSelected  = new cc.Sprite(res.btn_tc02);
		var nodeDisabled  = new cc.Sprite(res.btn_tc01);

		var node1 = new cc.MenuItemSprite(
		nodeNormal,
		nodeSelected,
		nodeDisabled,
		function(){
			cc.director.runScene(new ChooseLevelScene());		
		}.bind(this));

		node1.x = GC.w2 - this.bg.getBoundingBox().width/4;
		node1.y = GC.h2 - this.bg.getBoundingBox().height/2;

		var nodeNormal    = new cc.Sprite(res.btn_jx01);
		var nodeSelected  = new cc.Sprite(res.btn_jx02);
		var nodeDisabled  = new cc.Sprite(res.btn_jx01);

		var node2 = new cc.MenuItemSprite(
		nodeNormal,
		nodeSelected,
		nodeDisabled,
		function(){
			this.removeFromParent(true);
			GameManager.getInstance().GPMainLayer.isPause = false;
		}.bind(this));

		node2.x = GC.w2 + this.bg.getBoundingBox().width/4;
		node2.y = GC.h2 - this.bg.getBoundingBox().height/2;

		var menu = new cc.Menu(node1,node2);
		menu.setPosition(0, 0);
		this.addChild(menu);
	},
	loadFanHuiBtn : function(){
		var nodeNormal    = new cc.Sprite(res.btn_fh01);
		var nodeSelected  = new cc.Sprite(res.btn_fh02);
		var nodeDisabled  = new cc.Sprite(res.btn_fh01);

		var node = new cc.MenuItemSprite(
		nodeNormal,
		nodeSelected,
		nodeDisabled,
		function(){
			this.removeFromParent(true);
		}.bind(this));

		node.x = GC.w2;
		node.y = GC.h2 - this.bg.getBoundingBox().height/2;
		var menu = new cc.Menu();
		menu.setPosition(0, 0);
		menu.addChild(node);
		this.addChild(menu);
	},
	loadBgEffect : function(){
		var node1 = new cc.Sprite(res.ef_bgLight01);
		node1.setPosition(GC.w2,GC.h2);
		this.addChild(node1,-1);
		node1.setScale(2);


		var node2 = new cc.Sprite(res.ef_bgLight02);
		node2.setPosition(GC.w2,GC.h2);
		this.addChild(node2,-1);
		node2.setScale(2);

		var action1 = cc.fadeOut(2);
		var action2 = cc.fadeIn(2);

		node1.runAction(cc.sequence(action1,action2).repeatForever() );
		node2.runAction(cc.sequence(action2.clone(),action1.clone()).repeatForever());


	},
	loadStarBg : function(params){
		var node = new cc.Sprite(res.victory_cloud);
		node.setPosition(GC.w2,GC.h2);
		this.addChild(node,-1);

		var rating = params.rating;

		var attrArr = [
			{
				x : GC.w2 - 150,
				y : GC.h2 + 190,
				rotation : 45,
			},
			{
				x : GC.w2,
				y : GC.h2 + 220,
				rotation : 0,
			},
			{
				x : GC.w2 + 150,
				y : GC.h2 + 190,
				rotation : -45,
			},
		]

		for (var i = 0; i < attrArr.length; i++) {
			var x = attrArr[i].x;
			var y = attrArr[i].y;
			var rotation = attrArr[i].rotation;

			var node = new cc.Sprite(res.starbg_02);
			node.setPosition(x,y);
			this.addChild(node,2);
			node.rotation = rotation;

			if (rating[i]) {
				var node = new cc.Sprite(res.starbig_02);
				node.setPosition(x,y);
				this.addChild(node,2);
				node.rotation = rotation;

				var node = new cc.Sprite(res.shengliguang);
				node.setPosition(x,y);
				this.addChild(node,2);
				node.rotation = rotation;

				node.setBlendFunc(cc.ONE, cc.DST_ALPHA);

				var action1 = cc.fadeOut(1);
				var action2 = cc.fadeIn(1);
				node.runAction(cc.sequence(action1,action2).repeatForever());
			};
		};


	}
});