

var Common = {
	createAnimateNode : function (frameNum,prefix,isRepeated,delayPerUnit){
		var delay = delayPerUnit ? delayPerUnit : GC.WEAPON_EFFECT_TIME;

		var node = new cc.Sprite();

		var animation = cc.Animation.create();  //利用动画保存每一帧的图片

		for (var i = 1; i <= frameNum; i++) {
			var tp = prefix
			if (i <= 9 ) {
				tp = tp + "0";
			}

			animation.addSpriteFrameWithFile(res[tp + i ]);
		};

		animation.setDelayPerUnit(delay);  //每一帧播放的间隔
		var animate = cc.animate(animation);
		var callBack = cc.callFunc(function(){
			this.removeFromParent(true);
		}.bind(node));
		if (!isRepeated) {
			node.runAction(cc.sequence(animate,callBack));
		}else{
			node.runAction(animate.repeatForever());
		}

		return node;
	},
	createFontNode : function(value,type){
		if (type < 10 ) {type = "0"+type};
		var pNode = new cc.Node();
		var node
		var strValue = value.toString();
		for (var i = 0; i < strValue.length; i++) {
			if (strValue[i] == '.') {
				 node = new cc.Sprite(res["f"+type.toString()+"_dot"]);
			}else{
				 node = new cc.Sprite(res["f"+ type.toString() + "_"+ strValue[i]]);
			};
			if (type == 7) {
				node.setPositionX(15*i)
			}else{
				node.setPositionX(8*i)
			}

			pNode.addChild(node);
		};
		pNode.setCascadeOpacityEnabled(true);

		return pNode;
	},
	registerFunction : function(){
		// cc.Menu.prototype.setSwallowTouches = function(b){
		// 	this._touchListener.setSwallowTouches(b);
		// }

		/**
		 * 替换所有匹配exp的字符串为指定字符串
		 * @param exp 被替换部分的正则
		 * @param newStr 替换成的字符串
		 */
		String.prototype.replaceAll = function (exp, newStr) {
		    return this.replace(new RegExp(exp, "gm"), newStr);
		};

		/**
		 * 原型：字符串格式化
		 * @param args 格式化参数值
		 */
		String.prototype.format = function(args) {
		    var result = this;
		    if (arguments.length < 1) {
		        return result;
		    }

		    var data = arguments; // 如果模板参数是数组
		    if (arguments.length == 1 && typeof (args) == "object") {
		        // 如果模板参数是对象
		        data = args;
		    }
		    for ( var key in data) {
		        var value = data[key];
		        if (undefined != value) {
		            result = result.replaceAll("\\{" + key + "\\}", value);
		        }
		    }
		    return result;
		}
	},
	deepCopy : function(obj){
	    // Handle the 3 simple types, and null or undefined
	    if (null == obj || "object" != typeof obj) return obj;

	    // Handle Date
	    if (obj instanceof Date) {
	        var copy = new Date();
	        copy.setTime(obj.getTime());
	        return copy;
	    }

	    // Handle Array
	    if (obj instanceof Array) {
	        var copy = [];
	        var len ;
	        for (var i = 0,len = obj.length; i < len; ++i) {
	            copy[i] = this.deepCopy(obj[i]);
	        }
	        return copy;
	    }

	    // Handle Object
	    if (obj instanceof Object) {
	        var copy = {};
	        for (var attr in obj) {
	            if (obj.hasOwnProperty(attr)) copy[attr] = this.deepCopy(obj[attr]);
	        }
	        return copy;
	    }
	},
	createTipNode : function(){
		var node = new cc.Sprite(res.ef_tips_bg_lighting);

		node.setScale(GC.SCALE_RATE/2);

		var action1 = cc.scaleTo(1, 2);
		var action2 = cc.scaleTo(1, 1);
		var action3 = cc.fadeIn(1);
		var action4 = cc.fadeOut(1);
		var action =  cc.sequence( cc.spawn(action1,action3),cc.spawn(action2,action4)).repeatForever();

		node.runAction(action);

		return node;
	},
	random : function(under,over) {
		switch(arguments.length){
		    case 1: return (Math.random()*under+1);
		    case 2: 

		    return (Math.random()*(over-under+1) + under);
		    default: 

		    return 0;
		}
	},
	randomInt : function(under, over){
		switch(arguments.length){
		    case 1: return parseInt(Math.random()*under+1);
		    case 2: 

		    return parseInt(Math.random()*(over-under+1) + under);
		    default: 

		    return 0;
		}
	},
	//转换为5进制
	converToQuinaryDigit : function(num,arr){
		if (num  >= 5) {
			var mo = num % 5;
			var shang = Math.floor(num / 5);

			arr.push(mo);
			this.converToQuinaryDigit(shang,arr);
		}else{
			arr.push(num);
		}

	},
	getTimeFromSeconds : function(totalSeconds) {
	    if (totalSeconds < 86400) {
	        var dt = new Date("01/01/2000 0:00");
	        dt.setSeconds(totalSeconds);
	        return this.formatTime(dt);
	    } else {
	        return null;
	    }
	},
	formatTime : function(dt) {
	    var h = dt.getHours(),
	        m = dt.getMinutes(),
	        s = dt.getSeconds(),
	        r = "";
	    if (h > 0) {
	        r += (h > 9 ? h.toString() : "0" + h.toString()) + ":";
	    }
	    r += (m > 9 ? m.toString() : "0" + m.toString()) + ":"
	    r += (s > 9 ? s.toString() : "0" + s.toString());
	    return r;
	},
	calculateAwardArr : function(totalNum,arr){
		var jin = [0,[]];
		var yin = [0,[]];
		var tong = [0,[]];

		var moneyNum = 0;
		var isBreak = false;
		for (var i = arr.length - 1; i >= 0; i--) {
			var item = arr[i];

			for (var j = 0; j < item; j++) {
				moneyNum = moneyNum + 1;

				if (moneyNum == 5) {
					var curValue = 0;

					for (var k = 0; k < jin[0]; k++) {
						curValue = curValue + jin[1][k];
					};


					for (var k = 0; k < yin[0]; k++) {
						curValue = curValue + yin[1][k];
					};

					for (var k = 0; k < tong[0]; k++) {
						curValue = curValue + tong[1][k];
					};

					var lessValue = totalNum - curValue;

					if (lessValue >= 25) {
						jin[0] = jin[0] + 1;
						jin[1].push(lessValue);
					}else if(lessValue >= 5 && lessValue < 25){
						yin[0] = yin[0] + 1;
						yin[1].push(lessValue);
					}else{
						tong[0] = tong[0] + 1;
						tong[1].push(lessValue);
					}

					isBreak = true;
					break
				}else{
					if (i >= 2) {
						jin[0] = jin[0] + 1;
						var value = Math.pow(5,i); 
						jin[1].push(value);
					}else if (i == 1) {
						yin[0] = yin[0] + 1;
						var value = Math.pow(5,i); 
						yin[1].push(value);
					}else if (i == 0) {
						tong[0] = tong[0] + 1;
						var value = Math.pow(5,i); 
						tong[1].push(value);
					};
				}
			};

			if (isBreak) {
				break
			};
		};

		return [jin,yin,tong];
	},
	//判断某个概率是否达成
	calculateProbability : function(rate){
		var under = 100*rate;

		var value = this.randomInt(1,100);
		var b = false;
		if (value <= under ) {
			b = true;
		};
		return b;
	},
	decimalRetain : function(num,decimalNum){
		num = num + "";
		var aNew;
		var re = eval("/([0-9]+\.[0-9]{" + decimalNum + "})[0-9]*/");
		aNew = num.replace(re,"$1");
		return aNew;
	}
};