/**
 * Created by wangzhigang on 15/8/28.
 */

 var Level5 = {
 	// 地图类型 该类型下的第几套图
 	mapInfo : ["type1","02"],
 	temple  : "t02",
 	groups : [
 		//1,2,3,4级怪以及boss数量
	 	[4,0,0,0,0], 
	 	[5,2,0,0,0],
	 	[5,3,0,0,0],
	 	[4,3,4,0,0],
	 	[2,3,3,3,0],
	 	[2,2,3,4,0],
	 	[2,2,4,4,1],

 	],
 	monster : [
		{hp : 38,attack : 6,gold : 5},
		{hp : 43,attack : 7,gold : 6},
		{hp : 50,attack : 7,gold : 7},
		{hp : 60,attack : 8,gold : 8},

 		// BOSS
		{hp : 150,attack : 7,gold : 40},

 	],
 	adjustWidth : [128,136,114,254,232],
 }