/**
 * Created by wangzhigang on 15/8/28.
 */

 var Level6 = {
 	// 地图类型 该类型下的第几套图
 	mapInfo : ["type1","02"],
 	temple  : "t02",
 	groups : [
 		//1,2,3,4级怪以及boss数量
	 	[4,0,0,0,0], 
	 	[5,2,0,0,0],
	 	[5,3,0,0,0],
	 	[4,3,4,0,0],
	 	[2,3,3,3,0],
	 	[2,2,3,4,0],
	 	[2,2,4,4,1],

 	],
 	monster : [
		{hp : 65,attack : 7,gold : 6},
		{hp : 70,attack : 8,gold : 7},
		{hp : 80,attack : 8,gold : 8},
		{hp : 90,attack : 9,gold : 9},

 		// BOSS
		{hp : 200,attack : 8,gold : 50},

 	],
 	adjustWidth : [128,136,114,254,232],
 }