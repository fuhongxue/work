/**
 * Created by wangzhigang on 15/8/28.
 */

 var Level3 = {
 	// 地图类型 该类型下的第几套图
 	mapInfo : ["type1","02"],
 	temple  : "t02",
 	groups : [
 		//1,2,3,4级怪以及boss数量
	 	[4,0,0,0,0], 
	 	[5,2,0,0,0],
	 	[5,3,0,0,0],
	 	[4,3,4,0,0],
	 	[2,3,3,3,0],
	 	[2,2,3,4,0],
	 	[2,2,4,4,1],

 	],
 	monster : [
		{hp : 17,attack : 4,gold : 3},
		{hp : 20,attack : 5,gold : 4},
		{hp : 23,attack : 5,gold : 5},
		{hp : 26,attack : 6,gold : 6},

 		// BOSS
		{hp : 40,attack : 9,gold : 25},

 	],
 	adjustWidth : [128,136,114,254,232],
 }