/**
 * Created by wangzhigang on 15/9/17.
 */


 var BgParallax = {
 	type1 : {
 		foreword : [
	 		{
	 			name : "cr1",
	 			ratio : 0.8,
	 			loop : "sigle",
	 			posVector : [-300,11780],
	 		},
	 		{
	 			name : "cr2",
	 			ratio : 1.0,
	 			loop : "sigle",
	 			posVector : [3860,18000],
	 		},
 		],
 		backward : [

	 		{
	 			name : "sky3",
	 			ratio : 0.1,
	 			loop : "multiple",
	 			amount :  7,
	 			height  : 400,
	 		},
	 		{
	 			name : "sky2",
	 			ratio : 0.5,
	 			loop : "multiple",
	 			amount :  7,
	 			height  : 420,
	 		},
	 		{
	 			name : "sky1",
	 			ratio : 1.0,
	 			loop : "multiple",
	 			amount :  5,
	 			height  : 450,
	 		},



 			{
	 			name : "ground3",
	 			ratio : 0.1,
	 			loop : "multiple",
	 			amount :  6,
	 			height  : 230,
	 			tree : [
	 				{
	 					name  : "tree4",
	 					pNode : 1,
	 					x : 25,
	 					y : 20,
	 					scaleRate : 0.20,
	 				},
	 				{
	 					name  : "reed2",
	 					pNode : 2,
	 					x : 3,
	 					y : 12,
	 					scaleRate : 0.20,
	 				},
	 				{
	 					name  : "tree4",
	 					pNode : 1,
	 					x : 10,
	 					y : 18,
	 					scaleRate : 0.30,
	 				},
	 				{
	 					name  : "tree4",
	 					pNode : 2,
	 					x : 10,
	 					y : 17,
	 					scaleRate : 0.25,
	 				},
	 				{
	 					name  : "tree4",
	 					pNode : 3,
	 					x : 10,
	 					y : 19,
	 					scaleRate : 0.25,
	 				},
	 			]
 			},
 			{
	 			name : "ground2",
	 			ratio : 0.6,
	 			loop : "multiple",
	 			amount :  5,
	 			height  : 200,
	 			tree : [
	 				{
	 					name  : "tree3",
	 					pNode : 0,
	 					x : 10,
	 					y : 5,
	 					scaleRate : 0.4,
	 				},
	 				{
	 					name  : "reed2",
	 					pNode : 3,
	 					x : 5,
	 					y : 5,
	 					scaleRate : 0.6,
	 				},
	 				{
	 					name  : "tree3",
	 					pNode : 0,
	 					x : 2,
	 					y : 8,
	 					scaleRate : 0.5,
	 				},
	 				{
	 					name  : "tree3",
	 					pNode : 2,
	 					x : 33,
	 					y : 9,
	 					scaleRate : 0.5,
	 				},
	 				{
	 					name  : "tree3",
	 					pNode : 3,
	 					x : 24,
	 					y : 11,
	 					scaleRate : 0.5,
	 				},
	 			]
 			},
	 		{
	 			name : "ground1",
	 			ratio : 1.0,
	 			loop : "multiple",
	 			amount :  4,
	 			height  : 150,
	 			tree : [
	 				{
	 					name  : "tree2",
	 					pNode : 0,
	 					x : 30,
	 					y : 0,
	 					scaleRate : 1,
	 				},
	 				{
	 					name  : "reed2",
	 					pNode : 0,
	 					x : 10,
	 					y : 5,
	 					scaleRate : 0.6,
	 				},
	 				{
	 					name  : "tree2",
	 					pNode : 0,
	 					x : 1,
	 					y : -15,
	 					scaleRate : 1,
	 				},
	 				{
	 					name  : "tree2",
	 					pNode : 1,
	 					x : 60,
	 					y : -20,
	 					scaleRate : 0.9,
	 				},
	 				{
	 					name  : "tree2",
	 					pNode : 2,
	 					x : 33,
	 					y : 3,
	 					scaleRate : 0.8,
	 				},
	 			]
	 		},

	 		{
	 			name : "road1",
	 			ratio : 1,
	 			loop : "multiple",
	 			amount :  4,
	 			height  : 100,
	 		},

 		],

 		
 	}
 }