/**
 * Created by wangzhigang on 15/9/16.
 */

 var GSMainLayer = cc.Layer.extend({
 	ctor : function(){
 		this._super();

 	}
 });