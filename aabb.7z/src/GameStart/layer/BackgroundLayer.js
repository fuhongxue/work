/**
 * Created by wangzhigang on 15/9/16.
 */

 var GSBackgroundLayer = cc.Layer.extend({

 	ctor : function(){
 		this._super();

 		this.loadBg();
 		this.loadMountain();
 		this.loadCharaterAnimaiton();
 		this.loadTitle();
 		this.loadStartBtn();
 	},
 	loadBg : function(){
 		var node = new cc.Sprite(res.bg);
 		this.addChild(node,0);
 		node.setScale(GC.SCALE_RATE);
 		node.x = GC.w2;
 		node.y = GC.h2;

 		var node = new cc.Sprite(res.zhezhao);
 		this.addChild(node,2);
 		node.setScale(GC.SCALE_RATE);
 		node.x = GC.w2;
 		node.y = GC.h2 + 90;
 	},
 	loadMountain : function(){
 		var node = new cc.Sprite(res.shan01);
 		this.addChild(node,1);
 		node.setScale(GC.SCALE_RATE);
 		node.x = node.getBoundingBox().width/2;
 		node.y = 280;

 		var node = new cc.Sprite(res.shan03);
 		this.addChild(node,1);
 		node.setScale(GC.SCALE_RATE);
 		node.x = node.getBoundingBox().width/2 + 330;
 		node.y = 280;

 		var node = new cc.Sprite(res.shan02);
 		this.addChild(node,1);
 		node.setScale(GC.SCALE_RATE);
 		node.x = node.getBoundingBox().width/2 + 730;
 		node.y = 280;
 	},
 	loadCharaterAnimaiton : function(){
 		var node = Common.createAnimateNode(4,"l01_run_r_",true,GC.START_CHARATER_EFFECT_TIME);
 		this.addChild(node,3);
 		node.setScale(GC.SCALE_RATE);
 		node.setAnchorPoint(0,0);
 		node.x = 730;
 		node.y = 140;

 		var node = Common.createAnimateNode(4,"bajie_run",true,GC.START_CHARATER_EFFECT_TIME);
 		this.addChild(node,3);
 		node.setAnchorPoint(0,0);
 		node.setScale(GC.SCALE_RATE);
 		node.x = 550;
 		node.y = 140;

 		var node = Common.createAnimateNode(4,"tangseng_run",true,GC.START_CHARATER_EFFECT_TIME);
 		this.addChild(node,3);
 		node.setAnchorPoint(0,0);
 		node.setScale(GC.SCALE_RATE);
 		node.x = 320;
 		node.y = 140;

 		var node = Common.createAnimateNode(4,"shaseng_run",true,GC.START_CHARATER_EFFECT_TIME);
 		this.addChild(node,3);
 		node.setAnchorPoint(0,0);
 		node.setScale(GC.SCALE_RATE);
 		node.x = 130;
 		node.y = 140;
 	},
 	loadTitle : function(){
 		var node = new cc.Sprite(res.gname);
 		this.addChild(node,3);
 		node.setScale(GC.SCALE_RATE);
 		node.x = GC.w2;
 		node.y = GC.h2 + 140;
 	},
 	loadStartBtn : function(){
        var nodeNormal    = new cc.Sprite(res.btn_sg01);
        var nodeSelected  = new cc.Sprite(res.btn_sg02);
        var nodeDisabled  = new cc.Sprite(res.btn_sg01);

        var node = new cc.MenuItemSprite(
        nodeNormal,
        nodeSelected,
        nodeDisabled,
        function(){
        	cc.director.runScene(new GamePlayScene());
    	}.bind(this));

 		node.setScale(GC.SCALE_RATE);
 		node.x = GC.w2;
 		node.y = node.getContentSize().width/2;

        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        menu.addChild(node);
   		this.addChild(menu);
 	},

 });