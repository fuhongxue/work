

var Common = {
	createAnimateNode : function (frameNum,prefix,isRepeated,delayPerUnit){
		var delay = delayPerUnit ? delayPerUnit : GC.WEAPON_EFFECT_TIME;

		var node = new cc.Sprite();

		var animation = cc.Animation.create();  //利用动画保存每一帧的图片

		for (var i = 1; i <= frameNum; i++) {
			var tp = prefix
			if (i <= 9 ) {
				tp = tp + "0";
			}

			animation.addSpriteFrameWithFile(res[tp + i ]);
		};

		animation.setDelayPerUnit(delay);  //每一帧播放的间隔
		var animate = cc.animate(animation);
		var callBack = cc.callFunc(function(){
			this.removeAllChildrenWithCleanup(true)
			this.removeFromParent(true);
		}.bind(node));
		if (!isRepeated) {
			node.runAction(cc.sequence(animate,callBack));
		}else{
			node.runAction(animate.repeatForever());
		}

		return node;
	},
	createFontNode : function(value,type){
		if (type < 10 ) {type = "0"+type};
		var pNode = new cc.Node();
		var node
		var strValue = value.toString();
		for (var i = 0; i < strValue.length; i++) {
			if (strValue[i] == '.') {
				 node = new cc.Sprite(res["f"+type.toString()+"_dot"]);
			}else{
				 node = new cc.Sprite(res["f"+ type.toString() + "_"+ strValue[i]]);
			};
			if (type == 7) {
				node.setPositionX(15*i)
			}else{
				node.setPositionX(8*i)
			}

			pNode.addChild(node);
		};
		pNode.setCascadeOpacityEnabled(true);

		return pNode;
	},
	bgRecycle : function(vector){
		var heroObj = GameManager.getInstance().getHeroObj();

		for (var i = 0; i < vector.length; i++) {
		    var node = vector[i]
		    var nodeX = node.getParent().convertToWorldSpace(node.getPosition()).x

		    if(nodeX <= -node.getBoundingBox().width ){
		        node.setPositionX(node.getPositionX() + node.getBoundingBox().width*node.totalNum);
		    }
		    if(nodeX >= node.getBoundingBox().width*(node.totalNum - 1)) {
		        node.setPositionX(node.getPositionX() - node.getBoundingBox().width*node.totalNum);
		    }

		};
	},
	registerFunction : function(){
		cc.Menu.prototype.setSwallowTouches = function(b){
			this._touchListener.setSwallowTouches(b);
		}
	},
	deepCopy : function(obj){
	    // Handle the 3 simple types, and null or undefined
	    if (null == obj || "object" != typeof obj) return obj;

	    // Handle Date
	    if (obj instanceof Date) {
	        var copy = new Date();
	        copy.setTime(obj.getTime());
	        return copy;
	    }

	    // Handle Array
	    if (obj instanceof Array) {
	        var copy = [];
	        var len ;
	        for (var i = 0,len = obj.length; i < len; ++i) {
	            copy[i] = this.deepCopy(obj[i]);
	        }
	        return copy;
	    }

	    // Handle Object
	    if (obj instanceof Object) {
	        var copy = {};
	        for (var attr in obj) {
	            if (obj.hasOwnProperty(attr)) copy[attr] = this.deepCopy(obj[attr]);
	        }
	        return copy;
	    }
	},
};