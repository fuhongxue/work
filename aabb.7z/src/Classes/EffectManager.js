
/**
 * Created by wangzhigang on 15/9/11.
 */

 var EffectManager = (function(){
 	function _EffectManager(){
 		this.playCommonAttFontEffect = function(value,monster){
 			var heroObj = GameManager.getInstance().getHeroObj();
 			var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;

 			var node = Common.createFontNode(value,1);
 			node.setScale(GC.SCALE_RATE*0.1)

 			var action5 = cc.scaleTo(0.1,GC.SCALE_RATE*0.8);
 			var action1 = cc.moveBy(0.1,cc.p(0,5));

 			var action2 = cc.fadeOut(2);
 			var action3 = cc.moveBy(2,cc.p(0,100));

 			var callBack = cc.callFunc(function(){
 				this.removeAllChildrenWithCleanup(true)
 				this. removeFromParent(true);
 			}.bind(node));

 			node.setCascadeOpacityEnabled(true);


 			node.runAction(cc.sequence(cc.sequence(action1,action5),cc.spawn(action2,action3) ,callBack));

 			var pos = GameManager.getInstance().GPMainLayer.convertToNodeSpace(cc.p(monster.getPositionX() + monster.getBoundingBox().width/2,heroObj.getPositionY()+ monster.getBoundingBox().height/2 ));
 			pos.x = pos.x + 20*GC.SCALE_RATE*dir;

 			node.setPosition(cc.p(pos.x,pos.y));

 			node.x = node.x - GameManager.getInstance().effectParallax.getPositionX();

 			var pnode = new cc.Node();
 			pnode.addChild(node);
 			GameManager.getInstance().effectParallax.addChild(pnode, 5, cc.p(1, 0), cc.p(0,0));

 		};
 		this.playHitMonsterEffect = function(){
 			var heroObj = GameManager.getInstance().getHeroObj();
 			var weapon = heroObj.getWeapon();

 			var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;

 			var node = Common.createAnimateNode(8,"efhita");
 			var posX = 0;
 			if(heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ){
 				posX = (heroObj.getContentSize().width+weapon.getContentSize().width)*dir
 			}else{
 				posX = (weapon.getContentSize().width)*dir
 			}

 			heroObj.addChild(node);
 			node.setPosition(cc.p(posX,15));
 		};
 		this.playMonsterDeathEffect = function(){
 			var heroObj = GameManager.getInstance().getHeroObj();
 			var weapon = heroObj.getWeapon();

 			var heroObj = GameManager.getInstance().getHeroObj();
 			var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;


 			var node = Common.createAnimateNode(8,"efdeidboom");

 			var pos = GameManager.getInstance().GPMainLayer.convertToNodeSpace(cc.p(heroObj.getPositionX() + heroObj.getBoundingBox().width/2,heroObj.getPositionY()+ heroObj.getBoundingBox().height/2 ));
 			pos.x = pos.x + 50*GC.SCALE_RATE*dir

 			node.setPosition(cc.p(pos.x,pos.y));
 			node.setScale(GC.SCALE_RATE)

 			node.x = node.x - GameManager.getInstance().effectParallax.getPositionX();

 			var pnode = new cc.Node();
 			pnode.addChild(node);
 			GameManager.getInstance().effectParallax.addChild(pnode, 5, cc.p(1, 0), cc.p(0,0));
 		};
 		this.playEatMoneyEffect = function(){
 			var heroObj = GameManager.getInstance().getHeroObj();
 			var weapon = heroObj.getWeapon();

 			var heroObj = GameManager.getInstance().getHeroObj();
 			var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;


 			var node = Common.createAnimateNode(6,"eat_moneyb");
 			var posX = 0;
 			if(heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ){
 				posX = (heroObj.getContentSize().width+weapon.getContentSize().width + 20)*dir
 			}else{
 				posX = (weapon.getContentSize().width + 20)*dir
 			}

 			heroObj.addChild(node);
 			node.setPosition(cc.p(posX,15));
 		};
 		this.playCreateAwardEffect = function(num,monster){
 			var heroObj = GameManager.getInstance().getHeroObj();
 			var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;

 			for (var i = 0; i < num; i++) {
 				var node = Common.createAnimateNode(12,"ui_coin_gold",true);

 				var pos = GameManager.getInstance().GPMainLayer.convertToNodeSpace(cc.p(monster.getPositionX() + monster.getBoundingBox().width/2,monster.getPositionY()+ monster.getBoundingBox().height/2 ));

 				node.anchorY = 0;
 				node.setPosition(cc.p(pos.x,pos.y));
 				node.setScale(GC.SCALE_RATE);

 				var a1_time = GC.CREATE_AWARD_EFFECT.A1_TIME();
 				var a1_x    = GC.CREATE_AWARD_EFFECT.A1_X();
				var a1_h    = GC.CREATE_AWARD_EFFECT.A1_H();
				var a1_num  = GC.CREATE_AWARD_EFFECT.A1_NUM();
				var a2_time = GC.CREATE_AWARD_EFFECT.A2_TIME();
				var a2_x    = GC.CREATE_AWARD_EFFECT.A2_X();
				var a2_h    = GC.CREATE_AWARD_EFFECT.A2_H();
				var a2_num  = GC.CREATE_AWARD_EFFECT.A2_NUM();


 				var action1 = cc.jumpBy(a1_time, cc.p( a1_x*dir, -(monster.getBoundingBox().height/2) ), a1_h, a1_num); 
 				var action2 = cc.jumpBy(a2_time, cc.p( a2_x*dir, 0 ), a2_h, a2_num); 

 				var callBack = cc.callFunc(function(){
 					this.isFinishAnimation = true;
 				}.bind(node));
 				node.isFinishAnimation = false;

 				GameManager.getInstance().GPMainLayer.addChild(node, 5, cc.p(1, 0), cc.p(0,0));
 				node.runAction(cc.sequence(action1,action2,callBack));
 				GameManager.getInstance().AwardEffArr.push(node);
 			};
 		};
 		this.playGetAwardEffect = function(node){
 			node.isFinishAnimation = false;

 			var pos = GameManager.getInstance().GPMainLayer.convertToWorldSpace(cc.p(GC.w2,GC.h-70));

 			var action1 = cc.jumpTo(0.5, pos, -100, 1); 
 			var callBack = cc.callFunc(function(){
 				this.setVisible(false);
 			}.bind(node));
 			node.runAction(cc.sequence(action1,callBack));
 		};
 		this.playLostAwardEffect = function(num){
 			var heroObj = GameManager.getInstance().getHeroObj();
 			var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;

 			for (var i = 0; i < num; i++) {
 				var node = Common.createAnimateNode(12,"ui_coin_gold",true);


 				var pos = GameManager.getInstance().GPMainLayer.convertToNodeSpace(cc.p(heroObj.getPositionX(),heroObj.getPositionY() + heroObj.getBoundingBox().height/2 ));

 				node.anchorY = 0;
 				node.setPosition(cc.p(pos.x,pos.y));
 				node.setScale(GC.SCALE_RATE);


 				var a1_time = GC.CREATE_AWARD_EFFECT.A1_TIME();
 				var a1_x    = GC.CREATE_AWARD_EFFECT.A1_X();
				var a1_h    = GC.CREATE_AWARD_EFFECT.A1_H();
				var a1_num  = GC.CREATE_AWARD_EFFECT.A1_NUM();
				var a2_time = GC.CREATE_AWARD_EFFECT.A2_TIME();
				var a2_x    = GC.CREATE_AWARD_EFFECT.A2_X();
				var a2_h    = GC.CREATE_AWARD_EFFECT.A2_H();
				var a2_num  = GC.CREATE_AWARD_EFFECT.A2_NUM();


				// cc.log("rand : " + )

				if (Math.ceil(Math.random()*2) == 1) {
					dir = 1;
				}else{
					dir = -1;
				}

				var action1 = cc.jumpBy(a1_time, cc.p( a1_x*dir, -(heroObj.getBoundingBox().height/2) ), a1_h, a1_num); 
				var action2 = cc.jumpBy(a2_time, cc.p( a2_x*dir, 0 ), a2_h, a2_num); 
				var action3 = cc.fadeOut(a2_time);

				var callBack = cc.callFunc(function(){
					// this.isFinishAnimation = true;
					this.setVisible(false);
				}.bind(node));
				// node.isFinishAnimation = false;

				GameManager.getInstance().GPMainLayer.addChild(node, 5, cc.p(1, 0), cc.p(0,0));
				node.runAction(cc.sequence(action1, cc.spawn(action2,action3) ));
	 		}
 		};
 		this.playBrakeEffect = function(){
 			var heroObj = GameManager.getInstance().getHeroObj();
 			// var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;

 			var node = Common.createAnimateNode(8,"ef_brake_smoke");
 			// node.y = 10
 			node.anchorY = 0;
 			node.anchorX = 1/5;

 			if (heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT) {
 				node.setRotationY(0);
 				node.x = 23;
 			}else{
 				node.setRotationY(180);
 				node.x = 10;
 			}
 			node.setScale(heroObj.getSpeedRate());
 			heroObj.addChild(node);
 		}
 	}

 	var instance;

 	var _static = {
 		name : "EffctManager",

 		getInstance: function(){
 			if (instance === undefined) {
 			    instance = new _EffectManager();
 			}
 			return instance;
 		}
 	};
 	return _static;
 })();