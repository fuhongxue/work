/**
 * Created by wangzhigang on 15/4/19.
 */

// 游戏管理对象，单例类
var GameManager = (function () {

    function _GameManager() {
	
        // 英雄对象
        this.heroObj = null;
        this.parallaxLayer = null;
        this.characterVector = [];


        // this.Tree2 = null;
        //二维数组 第一维表示第几波 第二维表示具体对象
        this.monsterVector = [];  
        //阶段间怪物的距离
        this.monsterDisVector = [];

        //配置信息
        this.monsterGroupInfo = [];
        this.monsterInfo = [];
        this.characterInfo = [];

        //角色对象信息 
        this.characterData = {
            // hp : 0,
            hpMax : 0,
            attack : 0,
            // needGold : 0,
        };

        // 游戏本地数据存储字段
        this.localData = {

            // 游戏金币
            gold : 0,
            // 当前停留在哪一个关卡
            curLevel : 1, 
            // 已解锁到哪一个关卡     
            unlockLevel : 1,   

            // 角色等级，依次 悟空，唐僧，八戒，沙僧
            characterLevel : [0,0,0,0],
            //角色伙伴解锁状态： 0: 未解锁 1：已解锁，未上阵 2：已上阵
            partnerUnlockStatus : {
                "bajie"     : 0,
                "tangseng"  : 0,
                "shaseng"   : 0,
            },  

            // 技能等级,依次为 筋斗云，金箍棒，分身
            skillLevel : [0,0,0],

            // 升级界面悟空栏 解锁状态：  0: 未解锁 1：已解锁，未上阵 2：已上阵
            skillUnlockStatus : {
                "wukong" : 2,
                "jindouyun" : 0,
                "jingubang" : 0,
                "fenshen"   : 0,
            },
        };

        this.clear = function(){
            this.monsterVector = [];
            this.characterVector = [];
        };

        //========[localstorage]===========
        this.clearLocalData = function(){
            this.localData = "";
            this.saveLocalData();
        },
        this.saveLocalData = function(){
            var localData = JSON.stringify(this.localData);  
            cc.sys.localStorage.setItem("localData", localData);  
        };
        this.loadLocalStorage = function(){
            var localData = cc.sys.localStorage.getItem("localData");  
            // localData = ""
            if (localData == null || localData == "") {
                this.saveLocalData();
                this.localData = JSON.parse(cc.sys.localStorage.getItem("localData"));
            }else{
                this.localData = JSON.parse(localData);
            }
            this.localData.partnerUnlockStatus["tangseng"] = 1;
            this.localData.partnerUnlockStatus["bajie"] = 1;
            this.localData.partnerUnlockStatus["shaseng"] = 1;

        };
        this.getCharacterLevel = function(id){
            return this.localData.characterLevel[id];
        },
        this.setCharacterLevel = function(id,value){
            this.localData.characterLevel[id] = value;
        },
        this.resetRoleData = function(){
            this.characterData.hpMax = 0;
            this.characterData.attack = 0;

            for (var i = 0; i < this.characterInfo.length; i++) {
                var info = this.characterInfo[i];
                var level = this.localData.characterLevel[i];
                var config = info.config;
                var field = info.field;

                if(i > 0 && this.localData.partnerUnlockStatus[info.cName] != 2){
                    continue;
                }

                if (info.baseHp) {
                    this.characterData.hpMax = this.characterData.hpMax + info.baseHp;
                };

                for (var j = 0; j <  field.length; j++) {
                    if(field[j] == "hp"){
                        this.characterData.hpMax     = this.characterData.hpMax + config[level][j];
                    }else if(field[j] == "attack"){
                        this.characterData.attack = this.characterData.attack +  config[level][j];
                    }
                };

            };
        },
        this.getCurLevel = function(){
            return this.localData.curLevel;
        },
        this.setCurLevel = function(v){
            this.localData.curLevel = v;
        },
        this.getUnlockLevel = function(){
            return this.localData.unlockLevel;
        },
        this.setUnlockLevel = function(v){
            this.localData.unlockLevel = v;
        },
        this.getUnlockPartnerNum = function(){
            var num = 0;
            var partnerUnlockStatus = this.localData.partnerUnlockStatus;

            var arr = [
                "tangseng",
                "bajie",
                "shaseng",
            ];

            for (var i = 0; i < arr.length; i++) {
                var str = arr[i];

                if(partnerUnlockStatus[str] == 0 || partnerUnlockStatus[str] == 1){
                    num = num + 1;
                    break
                }else{
                    num = num + 1;
                }
            };

             return num;
        },
        this.isPartnerUnlocked = function(v){
            return this.localData.partnerUnlockStatus[v] == 2 ? true : false;
        },
        this.getPartnerUnlockedStatus = function(v){
            return this.localData.partnerUnlockStatus[v];
        },
        this.setPartnerUnlockedStatus = function(n,v){
            this.localData.partnerUnlockStatus[n] = v;
        },
        this.unlockPartner = function(){
            var curLevel = this.localData.curLevel;
            for (var i = 0; i < this.characterInfo.length; i++) {
                var info = this.characterInfo[i];
                if (this.localData.partnerUnlockStatus[info.cName] == 0) {
                    if (info.unlockLevel && info.unlockLevel == curLevel) {
                        this.localData.partnerUnlockStatus[info.cName] = 1;
                    };
                };

            }
        },
        this.getSkillUnlockedStatus = function(v){
            return this.localData.skillUnlockStatus[v];
        },
        this.getUnlockSkillNum = function(){
            var num = 0;
            var skillUnlockStatus = this.localData.skillUnlockStatus;

            var arr = [
                "wukong",
                "jindouyun",
                "jingubang",
                "fenshen",
            ];

            for (var i = 0; i < arr.length; i++) {
                var str = arr[i];

                if(skillUnlockStatus[str] == 0){
                    num = num + 1;
                    break
                }else{
                    num = num + 1;
                }
            };

            return num;
        },
        this.getSkillIndexByField = function(name,v){
            var index = 0;
            var field = this.skillInfo[name].field
            for (var i = 0; i < field.length; i++) {
                if(field[i] == v){
                    index = i;
                    break
                }
            };
            return index;
        },
        this.getSkillNeedGold = function(name){
            if (name == "wukong") {
                return this.getCharacterNeedGold(0);
            };
            var config = this.skillInfo[name].config;
            var lv = this.getSkillLv(name);
            var index = this.getSkillIndexByField(name,"gold");

            return config[lv][index];
        },
        this.getSkillLv = function(name){
            if (name == "wukong") {
                return this.getCharacterLevel(0);
            };
            var id =    this.skillInfo[name].id;

            return this.localData.skillLevel[id];
        },
        this.setSkillLv = function(name,v){
            if (name == "wukong") {
                return this.setCharacterLevel(0,v);
            };
            var id =    this.skillInfo[name].id;

            this.localData.skillLevel[id] = v;
        },
        this.getSkillUnlockedStatus = function(name){
            return this.localData.skillUnlockStatus[name];
        },
        this.setSkillUnlockedStatus = function(name,v){
            return this.localData.skillUnlockStatus[name] = v;
        },
        this.unlockSkill = function(){
            var wLv = this.getCharacterLevel(0);
            var skillVector = this.skillInfo;
            for(p in skillVector){
                if (this.localData.skillUnlockStatus[p] == 0) {
                    if (skillVector[p].unlockLevel == wLv) {
                        this.localData.skillUnlockStatus[p] = 1;
                    };
                };
            }
        },
        //========[localstorage]===========

        // ==============[getter && setter]==============
        this.setHeroObj = function(heroObj) {
           this.heroObj = heroObj;
        };
        this.getHeroObj = function() {
             return this.heroObj;
        };
        this.setParallaxLayer = function(obj) {
            this.parallaxLayer = obj;
        };
        this.getParallaxLayer = function() {
            return this.parallaxLayer;
        };
        this.getMonsterVector = function() {
            return this.monsterVector;
        };
        this.getMonsterGroupVector = function() {
            return this.monsterGroupInfo;
        };
        this.setMonsterDisVector = function(obj) {
            this.monsterDisVector = obj;
        };
        this.getMonsterDisVector = function() {
            return this.monsterDisVector;
        };
        this.getCharacterInfo = function() {
            return this.characterInfo;
        };
        this.getMonsterInfo = function() {
            return this.monsterInfo;
        };
        this.getCharacterData = function(){
            return this.characterData;
        };
        this.getCharacterVector = function() {
            return this.characterVector;
        };
        this.getGold = function(){
            return this.localData.gold;
        };
        this.setGold = function(value){
            this.localData.gold = value;
        };
        this.getCharacterNeedGold = function(id){
            var level = this.localData.characterLevel[id];
            var config = this.characterInfo[id]["config"];
            return config[level + 1] ? config[level + 1][1] : 0;
        };
        this.getCharacterAddAttr = function(id){
            var level = this.localData.characterLevel[id];
            var info = this.characterInfo[id];
            var config = info.config;

            return config[level+1] ? (config[level+1][0] - config[level][0]) : 0;
        },
        this.getBgPath = function(){
            var mapInfo = GameManager.getInstance().mapInfo
            var prefix = mapInfo[0] + "_" + mapInfo[1];
            return prefix;
        };

	}

	//实例容器
    var instance;

    var _static = {
        name: 'GameManager',
        //获取实例的方法
        //返回Singleton的实例
        getInstance: function () {
            if (instance === undefined) {
                instance = new _GameManager();
            }
            return instance;
        }
    };
    return _static;
})();