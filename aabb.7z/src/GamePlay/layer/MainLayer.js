/**
 * Created by wangzhigang on 15/4/20.
 */

 var GPMainLayer = cc.Layer.extend({
 	gameManager     : null,     // 对象[游戏管理者]
 	totalOffset     : null,
 	temple          : null,
 	templeVector    : [],
 	btemple         : null,
 	goldNode        : null,
 	upgradeSite     : null,
 	quitLayer       : null,
 	isUnlocked      : null,
 	ctor:function() {
 		this._super();

 		this.temple = new cc.Node();
 		this.addChild(this.temple);

 		// 加载[配置]
 		this.loadConfig();
 		this.loadGoldUI();
 		this.loadMonster();
 		this.loadHero();
 		this.loadQuitBtn();
 		this.loadShopBtn();

 		this.showDPSAndHp();

 		// 绑定[事件][触摸]
 		this.bindTouchListener();
 		// 定时[更新游戏逻辑]
 		this.scheduleUpdate();

 		this.schedule(this.clockDPSAndHp, GC.HERO_HP_TIME);


 		return true;
 	},
 	clockDPSAndHp : function(){
 		this.fHpMax.removeFromParent();
 		var fNode = Common.createFontNode(GameManager.getInstance().getCharacterData().attack,7);
 		fNode.anchorX = 0;
 		fNode.anchorY = 0;
 		fNode.x = 150;
 		fNode.y = GC.h-100;
 		this.addChild(fNode);
 		this.fHpMax = fNode;

 		this.fAttack.removeFromParent();

 		var fNode = Common.createFontNode(GameManager.getInstance().getCharacterData().hpMax,7);
 		fNode.anchorX = 0;
 		fNode.anchorY = 0;
 		fNode.x = 150;
 		fNode.y = GC.h-130;
 		this.addChild(fNode);
 		this.fAttack = fNode;
	},
 	showDPSAndHp : function(){
 		var node = new cc.Sprite(res["f07_dps"]);
 		node.x = 100;
 		node.y = GC.h-100;
 		this.addChild(node);
 		this.dps = node;

 		var fNode = Common.createFontNode(GameManager.getInstance().getCharacterData().attack,7);
 		fNode.anchorX = 0;
 		fNode.anchorY = 0;
 		fNode.x = 150;
 		fNode.y = GC.h-100;
 		this.addChild(fNode);
 		this.fHpMax = fNode;

 		var node = new cc.Sprite(res["f07_hp"]);
 		node.x = 100;
 		node.y = GC.h-130;
 		this.addChild(node);

 		var fNode = Common.createFontNode(GameManager.getInstance().getCharacterData().hpMax,7);
 		fNode.anchorX = 0;
 		fNode.anchorY = 0;
 		fNode.x = 150;
 		fNode.y = GC.h-130;
 		this.addChild(fNode);
 		this.fAttack = fNode;

 	},
 	loadConfig : function() {
 		// 配置[游戏管理对象]
 		this.gameManager = GameManager.getInstance(); 	

 		this.totalOffset = 0;

 		var node = new cc.Node();

 		var layer = new GPUpgradeSiteLayer();

 		layer.setPosition(cc.p(GC.w2/4,GC.h2/4));
 		node.addChild(layer);

 		node.setScale(4)

 		this.addChild(node)

 	},
 	createGoldNode : function(value){
 		if (this.goldNode) {
 			this.goldNode.removeAllChildrenWithCleanup(true)
 			this.goldNode.removeFromParent(true);
 		};

 		var pNode = Common.createFontNode(value,3);

 		this.addChild(pNode)
 		pNode.setPosition(cc.p(GC.w2+30,GC.h-55));
 		pNode.setScale(4);

 		this.goldNode = pNode;
 	},
 	resetFontGold : function(){
 		this.createGoldNode(GameManager.getInstance().getGold());
 	},
 	loadGoldUI : function(){
 		var node = new cc.Sprite(res.ui_biggoldcoin);
 		this.addChild(node);
 		node.setScale(4);
 		node.setPosition(cc.p(GC.w2,GC.h-55));

 		this.resetFontGold();
 	},
 	loadQuitBtn : function(){

        var nodeNormal    = new cc.Sprite(res.btn_back01);
        var nodeSelected  = new cc.Sprite(res.btn_back02);
        var nodeDisabled  = new cc.Sprite(res.btn_back01);

        var node = new cc.MenuItemSprite(
        nodeNormal,
        nodeSelected,
        nodeDisabled,
        function(){
        	if (this.quitLayer) {
        		this.quitLayer.reload();
        	}else{
        		var layer = new GPQuitLayer();
        		this.addChild(layer)

        		this.quitLayer = layer;
        	}
    	}.bind(this));

        node.x = GC.w-node.getBoundingBox().width;
        node.y = GC.h - 50;

        // node.setScale(1/GC.SCALE_RATE);

        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        menu.addChild(node);

 		this.addChild(menu);
 	},
 	loadShopBtn : function(){
        var nodeNormal    = new cc.Sprite(res.btn_sc01);
        var nodeSelected  = new cc.Sprite(res.btn_sc02);
        var nodeDisabled  = new cc.Sprite(res.btn_sc01);

        var node = new cc.MenuItemSprite(
        nodeNormal,
        nodeSelected,
        nodeDisabled,
        function(){
        	// GameManager.getInstance().clearLocalData();
        	EffectManager.getInstance().playCreateAwardEffect(2);

    	}.bind(this));

        node.x = 50;
        node.y = GC.h - 50;

        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        menu.addChild(node);

 		this.addChild(menu);
 	},
 	loadMonster : function() {
 		var monsterGroupVector =  Common.deepCopy(this.gameManager.getMonsterGroupVector());
 		var monsterVector = this.gameManager.getMonsterVector();
 		
 		var groupWidth = 0;


 		for (var i = 0; i < monsterGroupVector.length; i++) {
 			monsterVector[i] = [];

 			var groupLen = monsterGroupVector[i].length;

 			var isAllZero = false;
 			while( !isAllZero ){
 				var randNum = Math.ceil( Math.random()*(groupLen) )-1;

 				if (monsterGroupVector[i][randNum] > 0) {
 					monsterGroupVector[i][randNum] = monsterGroupVector[i][randNum] - 1 ;

 					var level = randNum + 1;
 					var node = new Monster(level);

 					this.addChild(node);

 					node.setAnchorPoint(0,0);
 					node.setPosition( GC.w  + groupWidth, GC.landHeight);
 					groupWidth = groupWidth + node.getBoundingBox().width + GC.DISTANCE_BETTWEN_MONSTER;

 					monsterVector[i].push(node);

 					this.endPos = node;
 				}
 				isAllZero = true;

 				for (var j = monsterGroupVector[i].length - 1; j >= 0; j--) {
 					if (monsterGroupVector[i][j] != 0) {
 						isAllZero = false;
 						break;
 					};
 				};
 			}
			if(i <  monsterGroupVector.length-1){
	 			var node = new cc.Sprite(res[GameManager.getInstance().temple]);
	 			node.setScale(GC.SCALE_RATE);
	 			this.temple.addChild(node,-1-i);
	 			node.setAnchorPoint(0,0);
	 			node.tag = i
	 			node.setPosition( GC.w  + groupWidth  , GC.landHeight);

	 			this.templeVector.push(node);

	 			groupWidth = groupWidth + node.getBoundingBox().width+ GC.DISTANCE_BETTWEN_MONSTER;
 			}
 			if (i == 0 ) {
 				var layer = new GPUpgradeSiteLayer();
 				node.addChild(layer);

 				layer.setPosition(cc.p(node.getContentSize().width/2,65));
 				layer.originX = layer.getPositionX();
 				this.upgradeSite = layer;
 			};



 			// for (var j = 0; j < monsterGroupVector[i].length; j++) {
 			// 	var value = monsterGroupVector[i][j];


 			// 	for(var k = 0; k < value; k++){

				// 	var level = j + 1;
				// 	var node = new Monster(level);

				// 	this.addChild(node);

				// 	node.setAnchorPoint(0,0);
				// 	node.setPosition( GC.w  + groupWidth, GC.landHeight);
				// 	groupWidth = groupWidth + node.getBoundingBox().width + GC.DISTANCE_BETTWEN_MONSTER;

				// 	monsterVector[i].push(node);

				// 	// if( (i == monsterGroupVector.length-1) && (j == monsterGroupVector[i].length-1) && (k == value-1)){
				// 		this.endPos = node;
				// 	// }
 			// 	}

 			// 	if(j == monsterGroupVector[i].length - 1){
 			// 		if(i <  monsterGroupVector.length-1){
 			// 			var node = new cc.Sprite(res[GameManager.getInstance().temple]);
 			// 			node.setScale(GC.SCALE_RATE);
 			// 			this.temple.addChild(node,-1-i);
 			// 			node.setAnchorPoint(0,0);
 			// 			node.tag = i
 			// 			node.setPosition( GC.w  + groupWidth  , GC.landHeight);

 			// 			this.templeVector.push(node);

 			// 			groupWidth = groupWidth + node.getBoundingBox().width+ GC.DISTANCE_BETTWEN_MONSTER;

 			// 			if (i==0) {
 			// 				var layer = new GPUpgradeSiteLayer();
 			// 				node.addChild(layer);

 			// 				layer.setPosition(cc.p(node.getContentSize().width/2,65));
 			// 				layer.originX = layer.getPositionX();
 			// 				this.upgradeSite = layer;
 			// 			};
 			// 		}

 			// 	}
 			// };

 		};

 	},
 	loadPartner : function(isUnlock){
 		this.isUnlocked = isUnlock;
 		var heroObj = GameManager.getInstance().getHeroObj();

 		if (GameManager.getInstance().isPartnerUnlocked("tangseng") && !GameManager.getInstance().getCharacterVector()[1]) {
 			var node = new Partner(GC.PARTNER_TYPE.TANG_SENG);

 			if (!isUnlock) {
 				node.setPosition(GC.PARTNER_DIS.RIGHT[0], 0);
 			}else{
 				if (heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT) {
 					node.setPosition(-GC.w2/GC.SCALE_RATE, 0);
 				}else{
 					node.setPosition(GC.w2/GC.SCALE_RATE, 0);
 				}
 			}
 			node.setAnchorPoint(0.5,0);
 			heroObj.addChild(node,-2);
 			GameManager.getInstance().getCharacterVector()[1] = (node);
 		};

 		if (GameManager.getInstance().isPartnerUnlocked("bajie") && !GameManager.getInstance().getCharacterVector()[2]) {
 			var node = new Partner(GC.PARTNER_TYPE.ZHU_BA_JIE);
 		
 			if (!isUnlock) {
 				node.setPosition(GC.PARTNER_DIS.RIGHT[1], 0);
 			}else{
 				if (heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT) {
 					node.setPosition(-GC.w2/GC.SCALE_RATE, 0);
 				}else{
 					node.setPosition(GC.w2/GC.SCALE_RATE, 0);
 				}
 			} 			
 			node.setAnchorPoint(0.5,0);
 			heroObj.addChild(node,-3);
 			GameManager.getInstance().getCharacterVector()[2] = (node);
 		}

 		if (GameManager.getInstance().isPartnerUnlocked("shaseng") && !GameManager.getInstance().getCharacterVector()[3]) {
 			var node = new Partner(GC.PARTNER_TYPE.SHA_SENG);
 		
 			if (!isUnlock) {
 				node.setPosition(GC.PARTNER_DIS.RIGHT[2], 0);
 			}else{
 				if (heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT) {
 					node.setPosition(-GC.w2/GC.SCALE_RATE, 0);
 				}else{
 					node.setPosition(GC.w2/GC.SCALE_RATE, 0);
 				}
 			} 			
 			node.setAnchorPoint(0.5,0);
 			heroObj.addChild(node,-4);
 			GameManager.getInstance().getCharacterVector()[3] = (node);
 		}
 	},
 	loadHero : function() {
 		var posX = 0;

 		var heroObj = new Hero();

 		heroObj.setPosition(GC.w2-300, GC.landHeight);
 		heroObj.setAnchorPoint(0.5,0);
 		this.addChild(heroObj);

 		GameManager.getInstance().setHeroObj(heroObj);
 		GameManager.getInstance().getCharacterVector()[0] = (heroObj);

 		this.loadPartner();
 	},
 	bindTouchListener : function() {
 		var listener = cc.EventListener.create({
 		    event           : cc.EventListener.TOUCH_ONE_BY_ONE,
 		    target          : this,
 		    swallowTouches  : true,
 		    onTouchBegan    : this.onTouchBegan,
 		    onTouchMoved    : this.onTouchMoved,
 		    onTouchEnded    : this.onTouchEnded
 		});
 		cc.eventManager.addListener(listener, this);
 	},

 	// 事件[触摸开始]
 	onTouchBegan: function (touch, event) {
 		var target = this.target;

 		var location = touch.getLocation();
 		var p = GameManager.getInstance().getParallaxLayer();
 		var monsterVector = GameManager.getInstance().getMonsterVector();
 		var heroObj = GameManager.getInstance().getHeroObj();

 		if(heroObj.getIsDeath()){
 			if (heroObj.isDeathAnimationFinished) {
 				heroObj.isDeathAnimationFinished = false;
 				target.deathMoveToTemple();

 				// var action = cc.fadeOut(0.5);
 				// heroObj.runAction(action);
 				// heroObj.deathFadeOut();
 				var cVector = GameManager.getInstance().getCharacterVector();
 				for (var i = 0; i < cVector.length; i++) {
 					cVector[i].deathFadeOut();
 				};
 			};
 		}else{
 			heroObj.setIsMove(true);
 			var cVector = GameManager.getInstance().getCharacterVector();
 			for (var i = 0; i < cVector.length; i++) {
 				cVector[i].loadAnimation();
 			};


 			var CenterX = heroObj.x + heroObj.getBoundingBox().width/2;

 			if(location.x > CenterX){
 				heroObj.setDirection(GC.CHARACTER_DIRECTION.RIGHT);
 			}else {

 				heroObj.setDirection(GC.CHARACTER_DIRECTION.LEFT);

 			}

 			heroObj.resetSpeed();

 			// var dis = Math.abs(location.x - CenterX);
 			// var percent = (dis > GC.touchDistance  ? GC.touchDistance  : dis) /GC.touchDistance ;
 			// heroObj.setSpeed(percent);
 		}

 	    return true;
 	},

 	// 事件[触摸移动]
 	onTouchMoved: function (touch, event) {
 		var location = touch.getLocation();
 		var heroObj = GameManager.getInstance().getHeroObj();
 		var CenterX = heroObj.x + heroObj.getBoundingBox().width/2;

 		// var dis = Math.abs(location.x - CenterX);
 		// var percent = (dis >  GC.touchDistance  ?  GC.touchDistance  : dis) / GC.touchDistance ;
 		// heroObj.setSpeed(percent);

 		if(location.x > CenterX){
 			heroObj.setDirection(GC.CHARACTER_DIRECTION.RIGHT);
 		}else {
 			heroObj.setDirection(GC.CHARACTER_DIRECTION.LEFT);
 		}
 	},

 	// 事件[触摸结束]
 	onTouchEnded: function (touch, event) {
 	    var target = this.target;
 	    var heroObj = GameManager.getInstance().getHeroObj();
 	    var p = GameManager.getInstance().getParallaxLayer();
 	    var monsterVector = GameManager.getInstance().getMonsterVector();

 	    heroObj.setIsMove(false);
 	    var cVector = GameManager.getInstance().getCharacterVector();
 	    for (var i = 0; i < cVector.length; i++) {
 	    	cVector[i].loadAnimation();
 	    };

 	    if (!heroObj.getIsDeath()) {
 	    	EffectManager.getInstance().playBrakeEffect();
 	    };
 	},
 	GameSucceed : function(){
		GameManager.getInstance().unlockPartner();
		var curLevel = GameManager.getInstance().getCurLevel();
		if(GameManager.getInstance().getUnlockLevel() == curLevel ){
			GameManager.getInstance().setUnlockLevel(curLevel + 1);
		}
		GameManager.getInstance().setCurLevel(curLevel + 1);
		GameManager.getInstance().saveLocalData();

 		this.unscheduleUpdate();
 		var transitionScene = new cc.TransitionProgressInOut(1, new ChooseLevelScene());
 		cc.director.runScene(transitionScene);
 	},
 	//我方角色与怪物的碰撞检测
 	checkMonsterCollision : function(){
 		var heroObj = GameManager.getInstance().getHeroObj();
 		var monsterVector = GameManager.getInstance().getMonsterVector();

 		var heroRect = heroObj.getCollisionRect();

 		var isIntersect = false;

 		for (var j = 0; j < monsterVector.length; j++){

 			for (var k = 0; k < monsterVector[j].length; k++){
 				var monster = monsterVector[j][k];

 				if (!monster.getIsDeath())
 				{
 					var monsterRect = monster.getCollisionRect();
 					var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;

 					if(cc.rectIntersectsRect(heroRect,monsterRect)){
 					    // cc.log("Intersect!");
 					    var isDeath = monster.onHit(heroObj.getAttack(),dir);
 					    var hIsDeath = heroObj.onHit(monster.getAttack(),monster.getIsDeath());
 					    isIntersect = true;

 					    EffectManager.getInstance().playCommonAttFontEffect(heroObj.getAttack(),monster);
 					    EffectManager.getInstance().playHitMonsterEffect();
 					   // EffectManager.getInstance().playEatMoneyEffect();
 					   if (hIsDeath) {
 					   		var curGold = GameManager.getInstance().getGold();
 					   		GameManager.getInstance().setGold( Math.floor( (1 - GC.LOSTMONEY_RATE)*curGold) );
 					   		GameManager.getInstance().saveLocalData();

 					   		this.resetFontGold();

 					   		// cc.eventManager.removeListeners(this);  
 					   		this.unscheduleUpdate();


 					   		EffectManager.getInstance().playLostAwardEffect(5);

 					   		var cVector = GameManager.getInstance().getCharacterVector();
 					   		for (var i = 1; i < cVector.length; i++) {
 					   			cVector[i].loadDeathAnimaiton();
 					   		};

	 					   	var index = 0;
	 					   	for (var i = 0; i < this.templeVector.length; i++) {
	 					   		var temple = this.templeVector[i];
	 					   		var pos = temple.getParent().convertToWorldSpace(temple.getPosition())

	 					   		if (pos.x < GC.w2) {
	 					   			if (i > index) {
	 					   				index = i;
	 					   			};
	 					   		};
	 					   	};
	 					   	heroObj.resetSpeed(2*GC.HERO_SPEED);
	 					   	this.btemple = this.templeVector[index];
 					   };

 					   if (isDeath) {
 					   		EffectManager.getInstance().playMonsterDeathEffect();
 					   		EffectManager.getInstance().playCreateAwardEffect(5,monster);
 					   		this.resetFontGold();

 					   		if (this.endPos == monster) {
 					   			cc.log("gameOVER")
 					   			this.GameSucceed();
 					   		};
 					   };
 					   break;
 					}
 				}
 			}

 			if (isIntersect) { isIntersect = false; break};

 		}
 	},
 	deathMoveToTemple : function(){
 		this.scheduleUpdate();
 	},
 	checkTempleCollision : function(){
 		var heroObj = GameManager.getInstance().getHeroObj();
 		var monsterGroupVector = this.gameManager.getMonsterGroupVector();
 		var isIntersect = false;
 		for (var i = 0; i < monsterGroupVector.length-1; i++) {
 			var node = this.temple.getChildByTag(i);

 			var heroRect = heroObj.getCollisionRect();

 			// var nodePos = node.getPosition();
 			var nodePos = node.getParent().convertToWorldSpace(node.getPosition())

			var nodeRect = cc.rect(
			    nodePos.x ,
			    nodePos.y ,
			    node.getBoundingBox().width,
			    node.getBoundingBox().height
			);

 			if(cc.rectIntersectsRect(heroRect,nodeRect)){
 				// cc.log("Intersect")
 				isIntersect = true;
 				this.upgradeSite.setPositionX(this.upgradeSite.originX + ((node.getPositionX() - this.temple.getChildByTag(0).getPositionX())/GC.SCALE_RATE));

 				break
			}
		}


		this.upgradeSite.showEff(isIntersect);
 	},
 	checkCollision : function(){
 		this.checkMonsterCollision();
 		this.checkTempleCollision();

 		var heroObj = GameManager.getInstance().getHeroObj();
		var heroRect = heroObj.getCollisionRect();
		var arr = GameManager.getInstance().AwardEffArr;
		for (var i = arr.length - 1; i >= 0; i--) {
			var node = arr[i]

			if (node.isFinishAnimation) {
	 			var nodePos = node.getParent().convertToWorldSpace(node.getPosition())

				var nodeRect = cc.rect(
				    nodePos.x ,
				    nodePos.y ,
				    node.getBoundingBox().width,
				    node.getBoundingBox().height
				);

	 			if(cc.rectIntersectsRect(heroRect,nodeRect)){
	 				cc.log("checkCollision====")
	 				// node.setPositionY(node.getPositionY() + 200);
	 				EffectManager.getInstance().playGetAwardEffect(node);
	 				break
				}
			};


		};
 	},
 	// 唐僧 猪八戒 沙僧影子效果
 	partnerFollow  :function(dt){
 		var heroObj = GameManager.getInstance().getHeroObj();

 		if(heroObj.getIsMove() || this.isUnlocked){
 			// var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;

			var cVector = GameManager.getInstance().getCharacterVector();
			var unlockNum = 0;
			for (var i = 0; i < cVector.length; i++) {
				var node = cVector[i];
				if(i == 0){
				}else{
					var tmp = cVector[0].getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? "RIGHT": "LEFT";
					var pos = GC.PARTNER_DIS[tmp][i-1]

					if(node.getPositionX() != pos){
						var nodeDir = (node.getPositionX()>pos) ? -1 : 1;

						var direction = nodeDir==-1 ? GC.CHARACTER_DIRECTION.LEFT : GC.CHARACTER_DIRECTION.RIGHT;

						var dis = node.getPositionX() + heroObj.getSpeed() * dt*nodeDir*0.5;
						if( nodeDir > 0 && dis > pos){
							cc.log("dddsdf11111")
							dis = pos;
							node.setDirection(cVector[0].getDirection());

						}else if( nodeDir < 0 && dis < pos){
							cc.log("dddsdf2222")

							dis = pos;
							node.setDirection(cVector[0].getDirection());

						}else{
							cc.log("dddsdf3333")

							node.setDirection(direction);
						}
						node.setPositionX( dis);
					}else{
						unlockNum = unlockNum + 1;
					}
				}

				if (this.isUnlocked && unlockNum == cVector.length-1) {
					this.isUnlocked = false;
				};
			}
 		}
 	},
 	wukongRunning : function(dt){
 		var heroObj = GameManager.getInstance().getHeroObj();
 		var monsterVector = GameManager.getInstance().getMonsterVector();
 		var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;

 		if(heroObj.getIsMove() || heroObj.getIsDeath()){
 			var num =  heroObj.getSpeed() * dt*dir*0.5;

 			if (heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT) {
 				if ( (heroObj.getPositionX() + num) > GC.w2) {
 					heroObj.x = GC.w2
 				}else{
 					heroObj.x = heroObj.getPositionX() + num;
 				}
 			};


 			if (heroObj.getDirection() == GC.CHARACTER_DIRECTION.LEFT) {
 				var limitNum = GC.w2
 				if (monsterVector[0][0].getPositionX() >= GC.w ) {
 					limitNum = 0
 				}
 				if ( (heroObj.getPositionX() + num) < limitNum) {
 					heroObj.x = limitNum
 				}else{
 					heroObj.x = heroObj.getPositionX() + num;
 				}
 			};

 			if (heroObj.x < GC.w2 && monsterVector[0][0].getPositionX() >= GC.w) {
 				this.isMonsterCanRun = false
 			}else{
 				this.isMonsterCanRun = true
 			}
 		}
 	},
 	templeMoving : function(dt){
 		var heroObj = GameManager.getInstance().getHeroObj();

 		var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;
 		this.temple.setPositionX(this.temple.getPositionX() - heroObj.getSpeed() * dt*dir);
 	},
 	monstersRunning : function(dt){
 		var heroObj = GameManager.getInstance().getHeroObj();
 		var monsterVector = GameManager.getInstance().getMonsterVector();

		var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;
		for (var j = 0; j < monsterVector.length; j++){
			for (var k = 0; k < monsterVector[j].length; k++){
				var monster = monsterVector[j][k];
				monster.setPositionX( monster.getPositionX() -  heroObj.getSpeed() *dt*dir);

				if (!heroObj.getIsDeath()) {
					if(monster.getPositionX() >= (GC.w ) || monster.getPositionX() <= -monster.getBoundingBox().width ){
						if(monster.isVisible() == false) {
							if(monster.getPositionX() < heroObj.getPositionX()){
								monster.setDirection(GC.CHARACTER_DIRECTION.RIGHT);
							}else{
								monster.setDirection(GC.CHARACTER_DIRECTION.LEFT);
							}
							monster.reset();
						}	
					}
				}
			}
		}
 					
 	},
 	resetMonstersDirection : function(){
 		var heroObj = GameManager.getInstance().getHeroObj();
 		var monsterVector = GameManager.getInstance().getMonsterVector();

 		for (var j = 0; j < monsterVector.length; j++){
 			for (var k = 0; k < monsterVector[j].length; k++){
 				var monster = monsterVector[j][k];

				if(monster.getPositionX() < heroObj.getPositionX()){
					monster.setDirection(GC.CHARACTER_DIRECTION.RIGHT);
				}else{
					monster.setDirection(GC.CHARACTER_DIRECTION.LEFT);
				}
			}

 		}
 	},
 	monsterRunningAndBgMoving : function(dt){
 		var heroObj = GameManager.getInstance().getHeroObj();
 		var monsterVector = GameManager.getInstance().getMonsterVector();
 		var dir = heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;

 		if(this.isMonsterCanRun && (heroObj.getIsMove() || heroObj.getIsDeath()  ) ){

 			if (heroObj.getIsDeath()) {
 				var p = GameManager.getInstance().getParallaxLayer();
 				if(heroObj.getDirection() == GC.CHARACTER_DIRECTION.RIGHT){
 					dt = -dt;
 				}

 				var temple = this.btemple;
 				var pos = temple.getParent().convertToWorldSpace(temple.getPosition())


				if(pos.x >= GC.w2-temple.getBoundingBox().width/2){
					heroObj.reset();
					this.resetMonstersDirection();

					// heroObj.deathFadeIn();
					// this.bindTouchListener();

					var cVector = GameManager.getInstance().getCharacterVector();
					for (var i = 0; i < cVector.length; i++) {
						cVector[i].deathFadeIn();
					};
				}
 			};

 			// 寺庙的移动
 			this.templeMoving(dt);
 			//怪物的移动
 			this.monstersRunning(dt);
			// 前景视差
			GameManager.getInstance().foreParallaxLayer.update(dt);
			// 背景视差
			GameManager.getInstance().GPBackgroundLayer.update(dt);

			var heroRect = heroObj.getCollisionRect();
			var arr = GameManager.getInstance().AwardEffArr;
			for (var i = arr.length - 1; i >= 0; i--) {
				var node = arr[i]

				if (node.isFinishAnimation) {
					node.x = node.x - heroObj.getSpeed() *dt*dir;
				};
			};

 		}
 	},

 	// 更新[游戏逻辑]
 	update : function(dt){
 		var heroObj = GameManager.getInstance().getHeroObj();

 		if (heroObj.getIsMove()) {
 			heroObj.setSpeed(dt);
 		};

 		//检测碰撞
 		if (!heroObj.getIsDeath() ) {
 			this.checkCollision();
		}
 		// 唐僧 猪八戒 沙僧影子效果
 		this.partnerFollow(dt);
 		// 悟空奔跑
 		this.wukongRunning(dt);
 		// 怪物奔跑以及背景移动
 		this.monsterRunningAndBgMoving(dt);
 	}
 });